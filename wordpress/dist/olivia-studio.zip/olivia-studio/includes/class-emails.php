<?php
/**
 * Transactional emails in the site's look, with a calendar (.ics) attachment for bookings.
 * Use an SMTP / transactional mail plugin in production so these reach inboxes.
 */

defined( 'ABSPATH' ) || exit;

class OYS_Emails {

	/**
	 * Customer emails are written in the customer's language (the one they last used on the site):
	 * OYS_Emails::booking_confirmed( … ) etc. arrive here and run with that language switched on.
	 */
	public static function __callStatic( $name, $args ) {
		if ( ! method_exists( __CLASS__, $name ) ) {
			throw new BadMethodCallException( 'OYS_Emails::' . $name );
		}
		$user = self::recipient_of( $name, $args );
		$lang = $user ? OYS_I18n::lang_for( $user ) : OYS_I18n::current();
		return OYS_I18n::with( $lang, fn() => self::$name( ...$args ) );
	}

	/** The user (id or email) an email goes to, from the arguments it was called with. */
	private static function recipient_of( $name, array $args ) {
		$a   = $args[0] ?? null;
		$uid = fn( $row ) => $row ? (int) ( $row->user_id ?? 0 ) : 0;
		switch ( $name ) {
			case 'booking_confirmed':
			case 'booking_cancelled':
			case 'waitlist_promoted':
			case 'reminder':
			case 'join_reminder':
				return $uid( OYS_Bookings::get( $a ) );
			case 'session_changed':
			case 'minimum_nudge':
				return $uid( is_object( $a ) ? $a : OYS_Bookings::get( $a ) );
			case 'guest_invite':
				return is_object( $a ) && $a->guest_of ? $uid( OYS_Bookings::get( $a->guest_of ) ) : 0;
			case 'waitlist_spot_open':
			case 'welcome':
			case 'we_miss_you':
			case 'review_request':
			case 'weekly_digest':
			case 'birthday':
			case 'raffle_winner':
				return (int) $a;
			case 'pass_expiring':
				return $uid( OYS_Passes::get( $a ) );
			case 'held_online':
				return (int) ( OYS_Held::get( (string) $a )['user'] ?? 0 );
			case 'pass_purchased':
				return $uid( OYS_Orders::get( $a ) );
			case 'gift_card':
				$known = is_object( $a ) ? get_user_by( 'email', (string) $a->recipient_email ) : null;
				return $known ? (int) $known->ID : ( is_object( $a ) ? (int) $a->purchaser_id : 0 );
			case 'gift_receipt':
				return $uid( $args[1] ?? null );
			case 'private_request_received':
			case 'private_offer':
			case 'private_declined':
				return $uid( is_object( $a ) ? $a : OYS_Privates::get( $a ) );
			default:
				return $uid( OYS_Memberships::get( $a ) );
		}
	}

	public static function send( $to, $subject, $heading, $body_html, $attachments = array(), $cta = null ) {
		return self::send_raw( $to, $subject, self::wrap( $heading, $body_html, $cta ), array(), $attachments );
	}

	/** Send ready HTML (already wrapped) with the studio as the sender. */
	public static function send_raw( $to, $subject, $html, array $extra_headers = array(), $attachments = array() ) {
		$html    = self::recolor( $html );
		$headers = array_merge( array( 'Content-Type: text/html; charset=UTF-8' ), $extra_headers, OYS_Mailer::headers() );
		$sent    = wp_mail( $to, $subject, $html, $headers, $attachments );
		foreach ( $attachments as $file ) {
			if ( str_contains( $file, 'oys-tmp' ) ) {
				wp_delete_file( $file );
			}
		}
		do_action( 'oys_email_sent', $to, $subject, $html );
		return $sent;
	}

	/** A newsletter in the studio's email look, with a hidden preview line and an unsubscribe link. */
	public static function newsletter_html( $heading, $preheader, $body, $cta, $unsubscribe_url ) {
		$pre  = $preheader ? '<div style="display:none;max-height:0;overflow:hidden;opacity:0">' . esc_html( $preheader ) . '</div>' : '';
		$foot = '<br><a href="' . esc_url( $unsubscribe_url ) . '" style="color:#53635A">' . esc_html__( 'Unsubscribe from the newsletter', 'olivia-studio' ) . '</a>';
		return str_replace( '<body style="', '<body data-newsletter="1" style="', self::wrap( $heading, $body, $cta, $foot, $pre ) );
	}

	/** The studio's email frame around ready HTML (e.g. the sending test). */
	public static function wrap_public( $heading, $body, $cta = null ) {
		return self::wrap( $heading, $body, $cta );
	}

	/**
	 * The emails in the site's own colours (Áron, 19 November: „Az emailek színe igazodjon a jelenlegi oldal színeihez”): the
	 * emails are written in the studio's first palette; a site gives its palette as old colour => new (filter
	 * `oys_email_palette`) and every email – frame, buttons, boxes, gift codes – is recoloured in one pass.
	 */
	public static function recolor( $html ) {
		$map = array();
		foreach ( (array) apply_filters( 'oys_email_palette', array() ) as $old => $new ) {
			$map[ strtoupper( (string) $old ) ] = (string) $new;
			$map[ strtolower( (string) $old ) ] = (string) $new;
		}
		return $map ? strtr( (string) $html, $map ) : (string) $html;
	}

	private static function wrap( $heading, $body, $cta, $footer_extra = '', $preheader = '' ) {
		return self::recolor( self::frame( $heading, $body, $cta, $footer_extra, $preheader ) );
	}

	/** The emails' button ([ label, url ]), at the end of the email or inside the text. */
	public static function button_html( array $cta, $margin = '28px 0 8px' ) {
		return '<p style="margin:' . esc_attr( $margin ) . '"><a href="' . esc_url( $cta[1] ) . '" style="display:inline-block;background:#2B5036;color:#F3F2EC;text-decoration:none;font-weight:700;letter-spacing:.06em;text-transform:uppercase;font-size:13px;padding:14px 22px;border-radius:999px">' . esc_html( $cta[0] ) . '</a></p>';
	}

	private static function frame( $heading, $body, $cta, $footer_extra = '', $preheader = '' ) {
		$button = $cta ? self::button_html( $cta ) : '';
		return '<!doctype html><html><body style="margin:0;background:#F3F2EC;font-family:Arial,Helvetica,sans-serif;color:#26352B">' . $preheader
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F3F2EC;padding:24px 12px"><tr><td align="center">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#FBFBF8;border:2px solid #12231A">'
			. '<tr><td style="background:#2B5036;padding:18px 24px;color:#F3F2EC;font-weight:700;font-size:20px;letter-spacing:.04em;text-transform:uppercase">' . esc_html( OYS_Settings::get( 'email_from_name' ) ) . '</td></tr>'
			. '<tr><td style="height:8px;background:#C6A3EE;font-size:0;line-height:0">&nbsp;</td></tr>'
			. '<tr><td style="padding:28px 24px 30px;font-size:16px;line-height:1.55">'
			. '<h1 style="margin:0 0 16px;font-size:26px;line-height:1.1;text-transform:uppercase;color:#12231A">' . esc_html( $heading ) . '</h1>'
			. $body . $button
			. '</td></tr><tr><td style="padding:16px 24px;border-top:2px solid #12231A;font-size:12px;color:#53635A">'
			. esc_html( get_bloginfo( 'name' ) ) . ' · <a href="' . esc_url( home_url( '/' ) ) . '" style="color:#2B5036">' . esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) ) . '</a> · <a href="' . esc_url( oys_account_url() ) . '" style="color:#2B5036">' . esc_html__( 'My account', 'olivia-studio' ) . '</a>'
			. ( oys_fb_group_url() ? ' · <a href="' . esc_url( oys_fb_group_url() ) . '" style="color:#2B5036">' . esc_html__( 'Facebook group', 'olivia-studio' ) . '</a>' : '' )
			. $footer_extra
			. '</td></tr></table></td></tr></table></body></html>';
	}

	private static function session_block( $session ) {
		$rows = array(
			__( 'Class', 'olivia-studio' ) => oys_session_title( $session ),
			__( 'When', 'olivia-studio' )  => oys_date( $session->starts_at, 'l, F j · g:i a' ) . ' – ' . oys_time( $session->ends_at ),
		);
		if ( OYS_Teachers::name_for( $session ) ) {
			$rows[ __( 'Teacher', 'olivia-studio' ) ] = OYS_Teachers::name_for( $session );
		}
		if ( oys_is_online( $session ) ) {
			$rows[ __( 'Where', 'olivia-studio' ) ] = __( 'Online (live)', 'olivia-studio' );
		} elseif ( $session->location ) {
			$rows[ __( 'Where', 'olivia-studio' ) ] = $session->location;
		}
		$html = '<table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-top:2px solid #12231A;margin:18px 0">';
		foreach ( $rows as $k => $v ) {
			$html .= '<tr><td style="padding:9px 12px 9px 0;border-bottom:1px solid #d8d8d0;font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:#53635A;width:90px;vertical-align:top">' . esc_html( $k ) . '</td><td style="padding:9px 0;border-bottom:1px solid #d8d8d0;font-weight:700">' . esc_html( $v ) . '</td></tr>';
		}
		return $html . '</table>';
	}

	private static function user_email( $user_id ) {
		$u = get_userdata( $user_id );
		return $u ? $u->user_email : '';
	}

	private static function first_name( $user_id ) {
		$u = get_userdata( $user_id );
		return $u ? ( $u->first_name ?: $u->display_name ) : '';
	}

	/* ---------- Calendar file ---------- */

	public static function ics( $session, $booking_id ) {
		$esc   = fn( $s ) => str_replace( array( '\\', ';', ',', "\n" ), array( '\\\\', '\;', '\,', '\n' ), (string) $s );
		$desc  = oys_session_title( $session ) . ' with ' . OYS_Settings::get( 'email_from_name' );
		$b     = OYS_Bookings::get( $booking_id );
		$join  = $b ? OYS_Bookings::join_link( $b, $session ) : '';
		$live  = $b && 'online' === oys_mode_for( $session, $b->mode );
		if ( $join ) {
			$desc .= "\nJoin online: " . $join;
		}
		$desc .= "\nManage your booking: " . oys_account_url();
		$lines = array(
			'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Olivia Studio//Booking//EN', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH',
			'BEGIN:VEVENT',
			'UID:oys-booking-' . (int) $booking_id . '@' . wp_parse_url( home_url(), PHP_URL_HOST ),
			'DTSTAMP:' . gmdate( 'Ymd\THis\Z' ),
			'DTSTART:' . gmdate( 'Ymd\THis\Z', oys_ts( $session->starts_at ) ),
			'DTEND:' . gmdate( 'Ymd\THis\Z', oys_ts( $session->ends_at ) ),
			'SUMMARY:' . $esc( oys_session_title( $session ) . ' · ' . OYS_Settings::get( 'email_from_name' ) ),
			'LOCATION:' . $esc( $live ? ( $join ?: 'Online' ) : $session->location ),
			'DESCRIPTION:' . $esc( $desc ),
			'BEGIN:VALARM', 'TRIGGER:-PT2H', 'ACTION:DISPLAY', 'DESCRIPTION:Yoga in 2 hours', 'END:VALARM',
			'END:VEVENT', 'END:VCALENDAR',
		);
		return implode( "\r\n", $lines ) . "\r\n";
	}

	private static function ics_file( $session, $booking_id ) {
		$dir = trailingslashit( wp_upload_dir()['basedir'] ) . 'oys-tmp';
		wp_mkdir_p( $dir );
		if ( ! file_exists( $dir . '/index.html' ) ) {
			file_put_contents( $dir . '/index.html', '' );
		}
		$file = $dir . '/yoga-' . (int) $booking_id . '-' . wp_generate_password( 8, false ) . '.ics';
		file_put_contents( $file, self::ics( $session, $booking_id ) );
		return $file;
	}

	/** The join link (or a note that it's coming) for someone taking part online; '' in the studio. */
	/** The join button and link for an online booking; $tip adds the "join a few minutes early" line. */
	private static function join_html( $booking, $session, $tip = true ) {
		if ( ! $booking || 'online' !== oys_mode_for( $session, $booking->mode ) ) {
			return '';
		}
		$url = OYS_Bookings::join_link( $booking, $session );
		if ( ! $url ) {
			return '<p><b>' . esc_html__( 'You\'re joining online.', 'olivia-studio' ) . '</b> ' . esc_html__( 'The link to join comes in your reminder email and is in your account before the class.', 'olivia-studio' ) . '</p>';
		}
		$html = '<p style="margin:22px 0 6px"><a href="' . esc_url( $url ) . '" style="display:inline-block;background:#C6A3EE;color:#12231A;text-decoration:none;font-weight:700;letter-spacing:.06em;text-transform:uppercase;font-size:13px;padding:13px 20px;border-radius:999px;border:2px solid #12231A">' . esc_html__( 'Join the live class', 'olivia-studio' ) . '</a></p>'
			. '<p style="font-size:13px;color:#53635A;word-break:break-all">' . esc_html( $url ) . '</p>';
		if ( $session->zoom_password && ! str_contains( $url, 'pwd=' ) ) {
			$html .= '<p style="font-size:13px;color:#53635A">' . esc_html__( 'Passcode:', 'olivia-studio' ) . ' <b>' . esc_html( $session->zoom_password ) . '</b></p>';
		}
		$replay = OYS_Live::replay_text( $session );
		$html  .= $replay ? '<p style="margin:14px 0;padding:10px 14px;background:#FBEBDD;border-left:4px solid #C6A3EE;border-radius:8px;font-size:14px;color:#12231A"><b>' . esc_html( $replay ) . '</b></p>' : '';
		return $html . ( $tip ? '<p style="font-size:13px;color:#53635A">' . esc_html__( 'Charge your device, join a few minutes early, set up where the camera sees your mat (or leave it off), and keep your microphone muted.', 'olivia-studio' ) . '</p>' : '' );
	}

	/**
	 * What to have ready for the class, in the booking email (Olívia, 14 November: „az eszközöket, hogy mire lesz szükség …
	 * a visszaigazoló emailbe is írd!”). The site gives the list through the oys_session_kit filter – the theme takes it from
	 * the class's own page, so it is always what the page says: array( 'items' => [ [ name, note ], … ], 'note' => '' ).
	 */
	public static function kit_html( $session ) {
		$kit   = (array) apply_filters( 'oys_session_kit', array(), $session );
		$items = array_filter( (array) ( $kit['items'] ?? array() ), fn( $i ) => '' !== trim( (string) ( $i[0] ?? '' ) ) );
		if ( ! $items ) {
			return '';
		}
		$li = '';
		foreach ( $items as $i ) {
			$li .= '<li style="margin:0 0 4px"><b>' . esc_html( $i[0] ) . '</b>' . ( '' !== trim( (string) ( $i[1] ?? '' ) ) ? ' – ' . esc_html( $i[1] ) : '' ) . '</li>';
		}
		$note = trim( (string) ( $kit['note'] ?? '' ) );
		return '<div style="margin:18px 0;padding:14px 16px;background:#F3EDFB;border-radius:12px;color:#12231A">'
			. '<p style="margin:0 0 8px;font-weight:700">' . esc_html__( 'What to have ready for the class', 'olivia-studio' ) . '</p>'
			. '<ul style="margin:0;padding-left:18px;font-size:14px;line-height:1.55">' . $li . '</ul>'
			. ( '' !== $note ? '<p style="margin:10px 0 0;font-size:13px;color:#53635A">' . esc_html( $note ) . '</p>' : '' ) . '</div>';
	}

	/** "To pay at the studio: $25" for bookings that are paid on the day. */
	private static function due_html( array $rows ) {
		$due = array_sum( array_map( fn( $r ) => $r && 'door' === $r->paid_with && '' === $r->collected_with ? (int) $r->due_cents : 0, $rows ) );
		if ( ! $due ) {
			return '';
		}
		return '<p style="margin:18px 0;padding:12px 14px;background:#DEE7D6;border-left:4px solid #2B5036"><b>' . sprintf( esc_html__( 'To pay at the studio: %s', 'olivia-studio' ), esc_html( oys_money( $due ) ) ) . '</b><br>' . esc_html( OYS_Settings::get( 'pay_later_note' ) ) . '</p>';
	}

	/* ---------- Customer emails ---------- */

	/** "You + Bea, Cora" list for emails. */
	private static function guest_list_html( array $rows, $title ) {
		if ( ! $rows ) {
			return '';
		}
		$labels = OYS_Bookings::paid_with_labels();
		$html   = '<p style="margin:18px 0 6px;font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:#53635A">' . esc_html( $title ) . '</p><ul style="margin:0 0 12px;padding-left:18px">';
		foreach ( $rows as $g ) {
			$html .= '<li><b>' . esc_html( $g->guest_name ) . '</b> <span style="color:#53635A">· ' . esc_html( $labels[ $g->paid_with ] ?? $g->paid_with ) . '</span></li>';
		}
		return $html . '</ul>';
	}

	/**
	 * Send one of the editable emails (Studio → Emails): its message, then $blocks (the automatic
	 * details: class, guests, join link…), then its closing note, then $after. Nothing is sent when
	 * the email is switched off; attachments are removed either way.
	 */
	private static function compose( $key, $to, array $vars, $blocks = '', array $attachments = array(), $cta_url = '', $after = '', $closing = true ) {
		$t = OYS_Email_Templates::get( $key );
		if ( ! $t || ! $t['enabled'] || ! $to ) {
			foreach ( $attachments as $file ) {
				wp_delete_file( $file );
			}
			return false;
		}
		$body = OYS_Email_Templates::paragraphs( $t['message'], $vars ) . $blocks . ( $closing ? OYS_Email_Templates::paragraphs( $t['closing'], $vars ) : '' ) . $after;
		$cta  = $t['button'] && $cta_url ? array( OYS_Email_Templates::fill( $t['button'], $vars ), $cta_url ) : null;
		return self::send( $to, OYS_Email_Templates::fill( $t['subject'], $vars ), OYS_Email_Templates::fill( $t['heading'], $vars ), $body, $attachments, $cta );
	}

	/** The Hub: the studio answered a message (OYS_Hub; the language is switched on by the caller). */
	public static function message_reply_mail( $to, array $vars, $quote_html, $cta_url = '' ) {
		return self::compose( 'message_reply', $to, $vars, $quote_html, array(), $cta_url, '', (bool) $cta_url );
	}

	/** The Hub: the studio wrote in a class chat after the class. */
	public static function chat_reply_mail( $to, array $vars, $quote_html, $cta_url ) {
		return self::compose( 'chat_reply', $to, $vars, $quote_html, array(), $cta_url );
	}

	private static function policy_html() {
		return '<p style="font-size:14px;color:#53635A">' . esc_html( OYS_Settings::cancel_policy() ) . '</p>';
	}

	/**
	 * $ids = the rows just confirmed (the customer's own and/or guests'). When only guests were
	 * added, the email says so.
	 */
	protected static function booking_confirmed( $booking_id, array $ids = array() ) {
		$host = OYS_Bookings::get( $booking_id );
		if ( ! $host ) {
			return;
		}
		$s      = OYS_Schedule::get( $host->session_id );
		$ids    = $ids ?: array( (int) $host->id );
		$rows   = array_map( array( 'OYS_Bookings', 'get' ), $ids );
		$new_g  = array_values( array_filter( $rows, fn( $r ) => $r && $r->guest_of ) );
		$only_g = ! in_array( (int) $host->id, array_map( 'intval', $ids ), true );
		$all_g  = OYS_Bookings::guests_of( $host->id, array( 'confirmed' ) );
		$key    = $only_g ? 'guests_added' : 'booking_confirmed';
		$online = 'online' === oys_mode_for( $s, $host->mode );
		$blocks = self::session_block( $s )
			. self::kit_html( $s )
			. self::guest_list_html( $all_g, sprintf( _n( 'Your guest (%d)', 'Your guests (%d)', count( $all_g ), 'olivia-studio' ), count( $all_g ) ) )
			. self::due_html( array_merge( array( $host ), $all_g ) )
			. self::join_html( $host, $s );
		if ( OYS_Email_Templates::enabled( $key ) ) {
			self::compose( $key, self::user_email( $host->user_id ), OYS_Email_Templates::vars_for( $host->user_id, $s ), $blocks, array( self::ics_file( $s, $host->id ) ), oys_account_url(), self::policy_html(), ! $online && 'private' !== $s->kind );
		}
		foreach ( $new_g as $g ) {
			if ( $g->guest_email ) {
				self::guest_invite( $g, $s );
			}
		}
		self::teacher_notice( $s, sprintf( __( 'New booking: %s', 'olivia-studio' ), oys_session_title( $s ) . ', ' . oys_date( $s->starts_at, 'D M j, g:i a' ) ),
			sprintf( _n( '%1$s booked (%2$d person). %3$d of %4$d spots are taken.', '%1$s booked (%2$d people). %3$d of %4$d spots are taken.', count( $rows ), 'olivia-studio' ), OYS_Bookings::person_label( $host ), count( $rows ), (int) $s->booked, (int) $s->capacity ) );
	}

	/** A guest who gave an email gets the details and a calendar invite (no account needed). */
	protected static function guest_invite( $g, $s ) {
		if ( ! OYS_Email_Templates::enabled( 'guest_invite' ) ) {
			return;
		}
		$vars = array_merge( OYS_Email_Templates::vars_for( 0, $s ), array( 'guest_name' => $g->guest_name, 'host' => self::first_name( $g->user_id ), 'first_name' => $g->guest_name ) );
		$note = 'online' === oys_mode_for( $s, $g->mode ) ? '' : '<p>' . esc_html__( 'Please arrive 10 minutes early.', 'olivia-studio' ) . '</p>';
		self::compose( 'guest_invite', $g->guest_email, $vars, self::session_block( $s ) . self::kit_html( $s ) . self::join_html( $g, $s ) . $note, array( self::ics_file( $s, $g->id ) ), home_url( '/' ), '<p style="font-size:14px;color:#53635A">' . esc_html( OYS_Settings::get( 'waiver_text' ) ) . '</p>' );
	}

	/**
	 * $ids = every row cancelled together (the customer's own and their guests').
	 */
	protected static function booking_cancelled( $booking_id, $outcome, $by_studio = false, $reason = '', array $ids = array(), $key = '', $extra = '' ) {
		$b = OYS_Bookings::get( $booking_id );
		$s = OYS_Schedule::get( $b->session_id );
		$rows   = array_filter( array_map( array( 'OYS_Bookings', 'get' ), $ids ?: array( $booking_id ) ) );
		$guests = array_values( array_filter( $rows, fn( $r ) => $r->guest_of ) );
		$vars   = array_merge( OYS_Email_Templates::vars_for( $b->user_id, $s ), array( 'reason' => $reason ) );
		$blocks = '';
		if ( ! $by_studio && $b->guest_of ) {
			$blocks .= '<p>' . sprintf( esc_html__( 'Your guest %s has been removed from this class.', 'olivia-studio' ), '<b>' . esc_html( $b->guest_name ) . '</b>' ) . '</p>';
		}
		$blocks .= self::session_block( $s );
		if ( $guests && ! $b->guest_of ) {
			$blocks .= self::guest_list_html( $guests, __( 'Guests cancelled with you', 'olivia-studio' ) );
		}
		$messages = array(
			'returned'   => count( $rows ) > 1 ? __( 'The classes are back on your pass.', 'olivia-studio' ) : __( 'The class is back on your pass.', 'olivia-studio' ),
			'credit'     => sprintf( __( 'You have a class credit to use within %d days.', 'olivia-studio' ), (int) OYS_Settings::get( 'dropin_credit_days' ) ),
			'membership' => __( 'This class won\'t count towards your membership.', 'olivia-studio' ),
			'refunded'   => __( 'Your card payment is being refunded; it usually shows on your statement within 5–10 days.', 'olivia-studio' ),
			'late'       => __( 'Because this was inside the cancellation window, the class counts as used.', 'olivia-studio' ),
			'none'       => '',
		);
		if ( ! empty( $messages[ $outcome ] ) ) {
			$blocks .= '<p><b>' . esc_html( $messages[ $outcome ] ) . '</b></p>';
		}
		self::compose( $key ?: ( $by_studio ? 'class_cancelled' : 'booking_cancelled' ), self::user_email( $b->user_id ), $vars, $blocks . $extra, array(), oys_page_url( 'book' ) );
		foreach ( $rows as $r ) {
			if ( $r->guest_of && $r->guest_email ) {
				self::compose( 'guest_cancelled', $r->guest_email, array_merge( $vars, array( 'guest_name' => $r->guest_name, 'first_name' => $r->guest_name ) ), self::session_block( $s ) . $extra );
			}
		}
		if ( ! $by_studio ) {
			self::teacher_notice( $s, sprintf( __( 'Cancellation: %s', 'olivia-studio' ), oys_session_title( $s ) . ', ' . oys_date( $s->starts_at, 'D M j, g:i a' ) ), sprintf( _n( '%1$s cancelled (%2$d person).', '%1$s cancelled (%2$d people).', count( $rows ), 'olivia-studio' ), self::first_name( $b->user_id ), count( $rows ) ) );
			self::admin_notice( sprintf( __( 'Cancellation: %s', 'olivia-studio' ), oys_session_title( $s ) ), sprintf( '%s cancelled %s (%d %s, %s).', self::first_name( $b->user_id ), oys_session_title( $s ) . ' ' . oys_date( $s->starts_at ), count( $rows ), _n( 'person', 'people', count( $rows ), 'olivia-studio' ), $outcome ), 'studio_cancellation' );
		}
	}

	protected static function waitlist_promoted( $booking_id ) {
		if ( ! OYS_Email_Templates::enabled( 'waitlist_promoted' ) ) {
			return;
		}
		$b    = OYS_Bookings::get( $booking_id );
		$s    = OYS_Schedule::get( $b->session_id );
		$vars = array_merge( OYS_Email_Templates::vars_for( $b->user_id, $s ), array( 'how' => 'membership' === $b->paid_with ? __( 'It\'s covered by your membership.', 'olivia-studio' ) : __( 'One class was taken from your pass.', 'olivia-studio' ) ) );
		self::compose( 'waitlist_promoted', self::user_email( $b->user_id ), $vars, self::session_block( $s ) . self::join_html( $b, $s ), array( self::ics_file( $s, $booking_id ) ), oys_account_url() );
	}

	protected static function waitlist_spot_open( $user_id, $session ) {
		self::compose( 'waitlist_spot_open', self::user_email( $user_id ), OYS_Email_Templates::vars_for( $user_id, $session ), self::session_block( $session ), array(), oys_book_url( $session->id ) );
	}

	/** The studio moved a class (new time, day or place): to the person who booked, or to a guest with an email. */
	protected static function session_changed( $booking, $session, $before ) {
		if ( ! OYS_Email_Templates::enabled( 'session_changed' ) ) {
			return;
		}
		$guest  = (bool) $booking->guest_of;
		$to     = $guest ? $booking->guest_email : self::user_email( $booking->user_id );
		$vars   = OYS_Email_Templates::vars_for( $booking->user_id, $session );
		if ( $guest ) {
			$vars['first_name'] = $booking->guest_name;
		}
		$blocks = '<p style="color:#53635A">' . esc_html__( 'Before:', 'olivia-studio' ) . ' <s>' . esc_html( oys_date( $before->starts_at, 'l, F j · g:i a' ) . ( oys_is_online( $before ) ? ' · ' . __( 'Online', 'olivia-studio' ) : ( $before->location ? ' · ' . $before->location : '' ) ) ) . '</s></p>'
			. '<p><b>' . esc_html__( 'Now:', 'olivia-studio' ) . '</b></p>' . self::session_block( $session ) . self::join_html( $booking, $session );
		self::compose( 'session_changed', $to, $vars, $blocks, array( self::ics_file( $session, $booking->id ) ), $guest ? '' : oys_account_url(), '', ! $guest );
	}

	protected static function reminder( $booking_id ) {
		$b = OYS_Bookings::get( $booking_id );
		$s = OYS_Schedule::get( $b->session_id );
		$blocks = self::session_block( $s ) . self::guest_list_html( OYS_Bookings::guests_of( $b->id, array( 'confirmed' ) ), __( 'Coming with you', 'olivia-studio' ) ) . self::join_html( $b, $s );
		return self::compose( 'reminder', self::user_email( $b->user_id ), OYS_Email_Templates::vars_for( $b->user_id, $s ), $blocks, array(), oys_account_url() );
	}

	/** Shortly before an online or hybrid class: the join link, to the customer or a guest with an email. */
	protected static function join_reminder( $booking_id ) {
		$b = OYS_Bookings::get( $booking_id );
		$s = OYS_Schedule::get( $b->session_id );
		$link = OYS_Bookings::join_link( $b, $s );
		if ( ! $link ) {
			return false;
		}
		$vars = OYS_Email_Templates::vars_for( $b->user_id, $s );
		if ( $b->guest_of ) {
			$vars['first_name'] = $b->guest_name;
		}
		return self::compose( 'join_reminder', $b->guest_of ? $b->guest_email : self::user_email( $b->user_id ), $vars, self::join_html( $b, $s, false ), array(), '', '', true );
	}

	/** Unused classes on a pass are about to expire. */
	protected static function pass_expiring( $pass_id ) {
		$p = OYS_Passes::get( $pass_id );
		if ( ! $p ) {
			return false;
		}
		$vars = array_merge( OYS_Email_Templates::vars_for( $p->user_id ), array(
			'pass'         => oys_t( $p->name ),
			'classes_left' => sprintf( _n( '%d class', '%d classes', (int) $p->credits_left, 'olivia-studio' ), (int) $p->credits_left ),
			'expires'      => oys_date( $p->expires_at, get_option( 'date_format' ) ),
		) );
		return self::compose( 'pass_expiring', self::user_email( $p->user_id ), $vars, '', array(), home_url( '/schedule-pricing/' ) );
	}

	protected static function pass_purchased( $order_id, $pass_id ) {
		$o      = OYS_Orders::get( $order_id );
		$p      = OYS_Passes::get( $pass_id );
		$blocks = '<p><b>' . esc_html( oys_t( $p->name ) ) . '</b><br>' . sprintf( esc_html__( '%1$d classes · valid until %2$s', 'olivia-studio' ), (int) $p->credits_total, esc_html( $p->expires_at ? oys_date( $p->expires_at, get_option( 'date_format' ) ) : __( 'no expiry', 'olivia-studio' ) ) ) . '</p>'
			. '<p>' . sprintf( esc_html__( 'Paid: %s', 'olivia-studio' ), esc_html( oys_money( $o->amount_cents, $o->currency ) ) ) . ( $o->receipt_url ? ' · <a href="' . esc_url( $o->receipt_url ) . '">' . esc_html__( 'Receipt', 'olivia-studio' ) . '</a>' : '' ) . '</p>';
		self::compose( 'pass_purchased', self::user_email( $o->user_id ), array_merge( OYS_Email_Templates::vars_for( $o->user_id ), array( 'pass' => oys_t( $p->name ) ) ), $blocks, array(), home_url( '/schedule-pricing/' ) );
	}

	/**
	 * The guest's sessions from Motibro, bookable online (OYS_Held): to the guest, or with $test to the studio's own
	 * address – the same email with the guest's details, „[Test]” in the subject. $until: the last day (default: the one saved).
	 */
	protected static function held_online( $key, $test_to = '', $until = '' ) {
		$e = OYS_Held::get( (string) $key );
		$t = OYS_Email_Templates::get( 'held_online' );
		if ( ! $e || ! $t ) {
			return false;
		}
		$to = $test_to ?: self::user_email( (int) $e['user'] );
		if ( ! $to || ( ! $test_to && ! $t['enabled'] ) ) {
			return false;
		}
		// once online, the online pass itself says how many are left and until when (the passes moved by the import of
		// 26 November have no day of their own on the list)
		global $wpdb;
		$pass = 'online' === $e['status'] ? $wpdb->get_row( $wpdb->prepare( 'SELECT credits_left, expires_at FROM ' . OYS_Install::table( 'passes' ) . ' WHERE user_id = %d AND product_id = %s ORDER BY id DESC LIMIT 1', (int) $e['user'], (string) $key ) ) : null;
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $until ) ) {
			$day = max( (string) $until, (string) $e['expires'] );
		} elseif ( $pass && $pass->expires_at ) {
			$day = wp_date( 'Y-m-d', oys_ts( $pass->expires_at ) );
		} else {
			$day = max( (string) ( $e['until'] ?? '' ), (string) $e['expires'] );
		}
		$left = $pass ? (int) $pass->credits_left : (int) $e['left'];
		$vars = array_merge( OYS_Email_Templates::vars_for( (int) $e['user'] ), array(
			'pass'     => (string) $e['name'],
			'sessions' => sprintf( _n( '%d session', '%d sessions', $left, 'olivia-studio' ), $left ),
			// „2027. január 27.” – the sentence's own full stop follows, so not two
			'until'    => $day ? rtrim( wp_date( get_option( 'date_format' ), strtotime( $day . ' 12:00:00 UTC' ) ), '.' ) : '—',
			'email'    => self::user_email( (int) $e['user'] ),
			'account'  => oys_account_url(),
		) );
		// Áron, 26 November: „közvetlen legyen az a gomb, hogy elfelejtett jelszó” – the button opens the lost password page
		// (the guest types the address, the „New password” email comes), right under the first paragraph; the steps follow
		$button  = $t['button'] ? self::button_html( array( OYS_Email_Templates::fill( $t['button'], $vars ), wp_lostpassword_url() ), '20px 0 24px' ) : '';
		$body    = OYS_Email_Templates::paragraphs( $t['message'], $vars ) . $button . OYS_Email_Templates::paragraphs( $t['closing'], $vars );
		$cta     = null;
		$subject = ( $test_to ? __( '[Test]', 'olivia-studio' ) . ' ' : '' ) . OYS_Email_Templates::fill( $t['subject'], $vars );
		return self::send( $to, $subject, OYS_Email_Templates::fill( $t['heading'], $vars ), $body, array(), $cta );
	}

	/** Came regularly, not lately, nothing booked (OYS_Hub_Auto, Motibro's „emlékeztető lemorzsolódó vendégeknek”). */
	protected static function we_miss_you( $user_id ) {
		return self::compose( 'we_miss_you', self::user_email( $user_id ), OYS_Email_Templates::vars_for( $user_id ), self::upcoming_html(), array(), home_url( '/' ) );
	}

	/** After the first attended class: a few words about it (OYS_Reviews; the guest's own signed link). */
	protected static function review_request( $user_id, $url ) {
		return self::compose( 'review_request', self::user_email( $user_id ), OYS_Email_Templates::vars_for( $user_id ), '', array(), $url );
	}

	/** Saturday: the coming week's classes to the newsletter subscribers, with the unsubscribe link (Motibro's „heti kedvcsináló”). */
	protected static function weekly_digest( $user_id ) {
		$t = OYS_Email_Templates::get( 'weekly_digest' );
		$u = get_userdata( $user_id );
		if ( ! $t || ! $t['enabled'] || ! $u || '1' !== (string) get_user_meta( $user_id, 'oys_marketing', true ) ) {
			return false;
		}
		$week = self::week_html();
		if ( '' === $week ) {
			return false;
		}
		$vars  = OYS_Email_Templates::vars_for( $user_id );
		$unsub = OYS_Newsletter::unsubscribe_url( $user_id );
		$cta   = $t['button'] ? array( OYS_Email_Templates::fill( $t['button'], $vars ), home_url( '/' ) ) : null;
		$html  = self::newsletter_html( OYS_Email_Templates::fill( $t['heading'], $vars ), '', OYS_Email_Templates::paragraphs( $t['message'], $vars ) . $week . OYS_Email_Templates::paragraphs( $t['closing'], $vars ), $cta, $unsub );
		return self::send_raw( $u->user_email, OYS_Email_Templates::fill( $t['subject'], $vars ), $html, array( 'List-Unsubscribe: <' . $unsub . '>', 'List-Unsubscribe-Post: List-Unsubscribe=One-Click' ) );
	}

	/** Next Monday to Sunday's public classes as a table ('' when there are none). */
	public static function week_html() {
		$tz   = wp_timezone();
		$mon  = new DateTimeImmutable( 'monday next week', $tz );
		$utc  = new DateTimeZone( 'UTC' );
		$list = OYS_Schedule::query( array( 'kind' => array( 'group', 'event' ), 'from' => $mon->setTimezone( $utc )->format( 'Y-m-d H:i:s' ), 'to' => $mon->modify( '+7 days' )->setTimezone( $utc )->format( 'Y-m-d H:i:s' ), 'status' => 'scheduled', 'limit' => 30 ) );
		if ( ! $list ) {
			return '';
		}
		$rows = '';
		foreach ( $list as $s ) {
			$free  = OYS_Schedule::spots_left( $s );
			$rows .= '<tr><td style="padding:9px 12px 9px 0;border-bottom:1px solid #d8d8d0;vertical-align:top"><b>' . esc_html( oys_session_title( $s ) ) . '</b><br><span style="font-size:14px;color:#53635A">' . esc_html( oys_date( $s->starts_at, 'l, F j · g:i a' ) ) . ( $free <= 3 ? ' · ' . esc_html( $free ? sprintf( _n( '%d spot left', '%d spots left', $free, 'olivia-studio' ), $free ) : __( 'Full – waitlist open', 'olivia-studio' ) ) : '' ) . '</span></td>'
				. '<td style="padding:9px 0;border-bottom:1px solid #d8d8d0;text-align:right;vertical-align:middle;white-space:nowrap"><a href="' . esc_url( oys_book_url( $s->id ) ) . '" style="color:#2B5036;font-weight:700">' . esc_html__( 'Book', 'olivia-studio' ) . ' →</a></td></tr>';
		}
		return '<table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-top:2px solid #12231A;margin:18px 0">' . $rows . '</table>';
	}

	protected static function welcome( $user_id ) {
		self::compose( 'welcome', self::user_email( $user_id ), OYS_Email_Templates::vars_for( $user_id ), self::upcoming_html(), array(), oys_account_url() );
	}

	/** The next few public classes with a booking link – so a new account can book its first class from the email. */
	public static function upcoming_html( $limit = 3 ) {
		$list = OYS_Schedule::query( array( 'kind' => array( 'group', 'event' ), 'from' => oys_now(), 'to' => oys_utc_plus( 60 * DAY_IN_SECONDS ), 'status' => 'scheduled', 'limit' => $limit ) );
		if ( ! $list ) {
			return '';
		}
		$rows = '';
		foreach ( $list as $s ) {
			$rows .= '<tr><td style="padding:9px 12px 9px 0;border-bottom:1px solid #d8d8d0;vertical-align:top"><b>' . esc_html( oys_session_title( $s ) ) . '</b><br><span style="font-size:14px;color:#53635A">' . esc_html( oys_date( $s->starts_at, 'l, F j · g:i a' ) ) . '</span></td>'
				. '<td style="padding:9px 0;border-bottom:1px solid #d8d8d0;text-align:right;vertical-align:middle;white-space:nowrap"><a href="' . esc_url( oys_book_url( $s->id ) ) . '" style="color:#2B5036;font-weight:700">' . esc_html__( 'Book', 'olivia-studio' ) . ' →</a></td></tr>';
		}
		return '<p style="margin:22px 0 4px;font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:#53635A">' . esc_html__( 'Next classes', 'olivia-studio' ) . '</p>'
			. '<table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-top:2px solid #12231A;margin:0 0 18px">' . $rows . '</table>';
	}

	protected static function gift_card( $gift, $partner = '' ) {
		$product = OYS_Products::get( $gift->product_id );
		$pair    = $product && (int) ( $product['people'] ?? 1 ) > 1;
		$vars    = array_merge( OYS_Email_Templates::vars_for(), array(
			'recipient'  => $gift->recipient_name ?: __( 'there', 'olivia-studio' ),
			'first_name' => $gift->recipient_name ?: __( 'there', 'olivia-studio' ),
			'from'       => self::first_name( $gift->purchaser_id ),
			'gift'       => $product ? oys_product_name( $product ) : $gift->product_id,
		) );
		$blocks = ( $gift->message ? '<blockquote style="margin:18px 0;padding:14px 18px;background:#ECE1FA;border:2px solid #12231A">' . nl2br( esc_html( $gift->message ) ) . '</blockquote>' : '' )
			. '<p>' . esc_html__( 'Your gift code:', 'olivia-studio' ) . '</p><p style="font-size:26px;font-weight:700;letter-spacing:.12em;background:#FF72B6;display:inline-block;padding:8px 14px;border:2px solid #12231A">' . esc_html( $gift->code ) . '</p>'
			. ( $pair ? '<p style="margin:14px 0;padding:10px 14px;background:#ECE1FA;border-radius:8px">' . esc_html( '' !== $partner ? sprintf( __( 'This is a gift for two: you got it together with %s. One of you redeems the code in their account, and you book together.', 'olivia-studio' ), $partner ) : __( 'This is a gift for two: one of you redeems the code in their account, and you book together.', 'olivia-studio' ) ) . '</p>' : '' );
		self::compose( 'gift_card', $gift->recipient_email, $vars, $blocks, array(), oys_account_url( 'passes' ) );
	}

	protected static function gift_receipt( $gift, $order ) {
		$blocks = '<p>' . esc_html__( 'Code:', 'olivia-studio' ) . ' <b>' . esc_html( $gift->code ) . '</b> · ' . esc_html( oys_money( $order->amount_cents, $order->currency ) ) . ( $order->receipt_url ? ' · <a href="' . esc_url( $order->receipt_url ) . '">' . esc_html__( 'Receipt', 'olivia-studio' ) . '</a>' : '' ) . '</p>';
		$to = $gift->recipient_email . ( is_email( (string) ( $order->meta['recipient_email2'] ?? '' ) ) ? ', ' . $order->meta['recipient_email2'] : '' );
		self::compose( 'gift_receipt', self::user_email( $order->user_id ), array_merge( OYS_Email_Templates::vars_for( $order->user_id ), array( 'recipient_email' => $to ) ), $blocks );
	}

	protected static function private_request_received( $request ) {
		// what they asked for goes into both emails, not only the admin (Áron, 16 November)
		$what = '<p style="margin:0 0 6px;font-weight:700">' . esc_html__( 'Your request', 'olivia-studio' ) . '</p>' . OYS_Privates::summary_html( $request );
		self::compose( 'private_request_received', self::user_email( $request->user_id ), OYS_Email_Templates::vars_for( $request->user_id ), $what, array(), oys_account_url( 'private' ) );
		if ( ! OYS_Email_Templates::enabled( 'studio_private' ) ) {
			return;
		}
		$u     = get_userdata( $request->user_id );
		$name  = trim( $u->first_name . ' ' . $u->last_name ) ?: $u->display_name;
		$phone = (string) get_user_meta( $u->ID, 'oys_phone', true );
		$admin = '<p><b>' . esc_html( $name ) . '</b><br><a href="mailto:' . esc_attr( $u->user_email ) . '">' . esc_html( $u->user_email ) . '</a>' . ( '' !== $phone ? ' · <a href="tel:' . esc_attr( preg_replace( '/[^\d+]/', '', $phone ) ) . '">' . esc_html( $phone ) . '</a>' : '' ) . '</p>'
			. OYS_Privates::summary_html( $request );
		$subject = sprintf( __( 'New private request: %1$s – %2$s', 'olivia-studio' ), OYS_Privates::topic_label( $request->topic ?? '', (int) $request->people ) . ', ' . (int) $request->duration_min . ' ' . __( 'min', 'olivia-studio' ), $name );
		self::send( OYS_Settings::get( 'notify_email' ), $subject, __( 'New private request', 'olivia-studio' ), $admin, array(), array( __( 'Open in dashboard', 'olivia-studio' ), admin_url( 'admin.php?page=oys-private&request=' . (int) $request->id ) ) );
	}

	protected static function private_offer( $request, $session ) {
		$blocks = self::session_block( $session ) . '<p><b>' . esc_html( oys_money( $request->price_cents ) ) . '</b></p>'
			// Áron, 16 November: „Ebbe az e-mailbe rakd bele, hogyha kedvezménykódod van, akkor a fizetésnél érvényesíthető.”
			. ( (int) $request->price_cents > 0 ? '<p style="margin:0 0 16px;padding:12px 14px;border-radius:10px;background:#FFF4C2;color:#12231A;font-size:14px;line-height:1.5">' . esc_html__( 'If you have a discount code, you can use it when you pay: open “Have a discount code?” on the payment page.', 'olivia-studio' ) . '</p>' : '' )
			. ( $request->admin_message ? '<p>' . nl2br( esc_html( $request->admin_message ) ) . '</p>' : '' )
			. ( $session->note ? '<p><b>' . esc_html( $session->note ) . '</b></p>' : '' )
			. ( OYS_Settings::get( 'private_note' ) ? '<p style="font-size:14px;color:#53635A">' . esc_html( OYS_Settings::get( 'private_note' ) ) . '</p>' : '' );
		self::compose( 'private_offer', self::user_email( $request->user_id ), OYS_Email_Templates::vars_for( $request->user_id, $session ), $blocks, array(), oys_book_url( $session->id ) );
	}

	protected static function private_declined( $request, $message = '' ) {
		self::compose( 'private_declined', self::user_email( $request->user_id ), OYS_Email_Templates::vars_for( $request->user_id ), $message ? '<p>' . nl2br( esc_html( $message ) ) . '</p>' : '' );
	}

	/* ---------- Memberships ---------- */

	private static function membership_block( $m ) {
		$p     = OYS_Products::get( $m->product_id );
		$price = $p ? oys_money( $p['price_cents'] ) . ' ' . OYS_Products::period_label( $p ) : '';
		$what  = (int) $m->classes_per_period ? sprintf( _n( '%d group class per period', '%d group classes per period', (int) $m->classes_per_period, 'olivia-studio' ), (int) $m->classes_per_period ) : __( 'Unlimited group classes', 'olivia-studio' );
		return '<p><b>' . esc_html( $m->name ) . '</b><br>' . esc_html( $what ) . ( $price ? ' · ' . esc_html( $price ) : '' ) . '</p>';
	}

	protected static function membership_started( $membership_id ) {
		$m      = OYS_Memberships::get( $membership_id );
		$blocks = self::membership_block( $m ) . ( $m->current_period_end ? '<p>' . sprintf( esc_html__( 'Next renewal: %s.', 'olivia-studio' ), esc_html( oys_date( $m->current_period_end, get_option( 'date_format' ) ) ) ) . '</p>' : '' );
		self::compose( 'membership_started', self::user_email( $m->user_id ), OYS_Email_Templates::vars_for( $m->user_id ), $blocks, array(), oys_page_url( 'book' ) );
		self::admin_notice( __( 'New membership', 'olivia-studio' ), sprintf( '%s joined: %s', self::first_name( $m->user_id ), $m->name ), 'studio_membership' );
	}

	protected static function membership_cancel_scheduled( $membership_id ) {
		$m    = OYS_Memberships::get( $membership_id );
		$vars = array_merge( OYS_Email_Templates::vars_for( $m->user_id ), array( 'ends' => oys_date( $m->current_period_end, get_option( 'date_format' ) ) ) );
		self::compose( 'membership_cancel_scheduled', self::user_email( $m->user_id ), $vars, self::membership_block( $m ), array(), oys_account_url( 'membership' ) );
		self::admin_notice( __( 'Membership cancelled', 'olivia-studio' ), sprintf( '%s cancelled %s (ends %s).', self::first_name( $m->user_id ), $m->name, oys_date( $m->current_period_end ) ), 'studio_membership' );
	}

	protected static function membership_ended( $membership_id ) {
		$m = OYS_Memberships::get( $membership_id );
		self::compose( 'membership_ended', self::user_email( $m->user_id ), OYS_Email_Templates::vars_for( $m->user_id ), self::membership_block( $m ), array(), home_url( '/schedule-pricing/' ) );
	}

	protected static function membership_payment_failed( $membership_id, $invoice_url = '' ) {
		$m      = OYS_Memberships::get( $membership_id );
		$blocks = self::membership_block( $m ) . ( $invoice_url ? '<p><a href="' . esc_url( $invoice_url ) . '">' . esc_html__( 'Pay the invoice now', 'olivia-studio' ) . '</a></p>' : '' );
		self::compose( 'membership_payment_failed', self::user_email( $m->user_id ), OYS_Email_Templates::vars_for( $m->user_id ), $blocks, array(), oys_account_url( 'membership' ) );
		self::admin_notice( __( 'Membership payment failed', 'olivia-studio' ), sprintf( '%s — %s', self::first_name( $m->user_id ), $m->name ), 'studio_membership' );
	}

	/* ---------- Studio emails ---------- */

	/** A note to the studio; $type is its switch in Studio → Emails. */
	/** Birthday code (from the `birthday` template). */
	protected static function birthday( $user_id, $coupon ) {
		$vars   = array_merge( OYS_Email_Templates::vars_for( $user_id ), array(
			'percent' => (int) $coupon->value . '%',
			'code'    => $coupon->code,
			'expires' => $coupon->expires_at ? oys_date( $coupon->expires_at, 'F j' ) : '',
		) );
		$blocks = '<p style="margin:22px 0;padding:16px;text-align:center;background:#DEE7D6;border:2px dashed #2B5036;font-size:22px;font-weight:700;letter-spacing:.12em">' . esc_html( $coupon->code ) . '</p>'
			. '<p style="font-size:14px;color:#53635A">' . esc_html__( 'It\'s filled in for you when you buy a pass or pay for a class by card while logged in.', 'olivia-studio' ) . '</p>';
		return self::compose( 'birthday', self::user_email( $user_id ), $vars, $blocks, array(), oys_page_url( 'book' ) );
	}

	/** The loyalty draw's winner (from the `raffle_winner` template). */
	protected static function raffle_winner( $user_id, $product, $tickets, $period ) {
		$vars = array_merge( OYS_Email_Templates::vars_for( $user_id ), array(
			'prize'   => $product['name'] ?? __( 'a free pass', 'olivia-studio' ),
			'tickets' => $tickets,
			'period'  => $period,
		) );
		return self::compose( 'raffle_winner', self::user_email( $user_id ), $vars, '', array(), oys_account_url( 'passes' ) );
	}

	/** "Bring a friend": the class needs $missing more people by the decision time. */
	protected static function minimum_nudge( $booking, $session, $missing, $decide_at ) {
		$vars = array_merge( OYS_Email_Templates::vars_for( $booking->user_id, $session ), array(
			'missing'  => sprintf( _n( '%d more person', '%d more people', $missing, 'olivia-studio' ), $missing ),
			'deadline' => wp_date( oys_date_format( 'l, g:i a' ), $decide_at ),
		) );
		$blocks = self::session_block( $session ) . '<p style="font-size:14px;color:#53635A">' . esc_html__( 'Share this link with a friend, or add them as your guest from your booking:', 'olivia-studio' ) . '<br><a href="' . esc_url( oys_book_url( $session->id ) ) . '" style="color:#2B5036;word-break:break-all">' . esc_html( oys_book_url( $session->id ) ) . '</a></p>';
		return self::compose( 'minimum_nudge', self::user_email( $booking->user_id ), $vars, $blocks, array(), oys_book_url( $session->id ) );
	}

	/** A message the studio wrote to everyone in a class (roster → "Message everyone"). */
	public static function class_message( $to, $session, $subject, $body_html, $reply_to = '' ) {
		$headers = is_email( $reply_to ) ? array( 'Reply-To: ' . $reply_to ) : array();
		return self::send_raw( $to, $subject, self::wrap( $subject, $body_html . self::session_block( $session ), array( __( 'My bookings', 'olivia-studio' ), oys_account_url() ) ), $headers );
	}

	public static function admin_notice( $subject, $text, $type = 'studio_alerts' ) {
		if ( ! OYS_Email_Templates::enabled( $type ) ) {
			return false;
		}
		return self::send( OYS_Settings::get( 'notify_email' ), '[Studio] ' . $subject, $subject, '<p>' . esc_html( $text ) . '</p>' );
	}

	/** A short note to the teacher of a class (if it has one and they want these emails). */
	public static function teacher_notice( $session, $subject, $text ) {
		$t = OYS_Teachers::for_session( $session );
		if ( ! $t || ! (int) $t->notify || ! is_email( $t->email ) ) {
			return false;
		}
		return self::send( $t->email, '[' . OYS_Settings::get( 'email_from_name' ) . '] ' . $subject, $subject, '<p>' . esc_html( $text ) . '</p>' . self::session_block( $session ), array(), array( __( 'Open your classes', 'olivia-studio' ), admin_url( 'admin.php?page=oys-teach&session=' . (int) $session->id ) ) );
	}

	/** Welcome for a new teacher login: set a password, then Teaching in the dashboard. */
	public static function teacher_access( $t, $password_url ) {
		$studio = OYS_Settings::get( 'email_from_name' );
		$body   = '<p>' . sprintf( esc_html__( 'Hi %s,', 'olivia-studio' ), esc_html( strtok( $t->name, ' ' ) ) ) . '</p>'
			. '<p>' . sprintf( esc_html__( 'You now have a teacher login at %s. There you can see who is booked into your classes, write to them, keep your profile and photos up to date, connect your Stripe account for card payments and see your monthly statement.', 'olivia-studio' ), esc_html( $studio ) ) . '</p>'
			. '<p>' . esc_html__( 'Set your password with the button below, then log in. Your classes are under Teaching.', 'olivia-studio' ) . '</p>';
		return self::send( $t->email, sprintf( __( 'Your teacher login at %s', 'olivia-studio' ), $studio ), __( 'Welcome to the team', 'olivia-studio' ), $body, array(), array( __( 'Set your password', 'olivia-studio' ), $password_url ) );
	}

	public static function admin_new_order( $order_id ) {
		if ( ! OYS_Email_Templates::enabled( 'studio_payment' ) ) {
			return;
		}
		$o = OYS_Orders::get( $order_id );
		$u = get_userdata( $o->user_id );
		self::send( OYS_Settings::get( 'notify_email' ), sprintf( '[Studio] %s — %s', oys_money( $o->amount_cents, $o->currency ), $o->description ), __( 'New payment', 'olivia-studio' ),
			'<p><b>' . esc_html( $o->description ) . '</b><br>' . esc_html( $u ? $u->display_name . ' · ' . $u->user_email : '' ) . '<br>' . esc_html( oys_money( $o->amount_cents, $o->currency ) ) . '</p>'
			. ( ! empty( $o->meta['stripe_account'] ) ? '<p>' . esc_html( sprintf( __( 'Paid to the teacher\'s own Stripe account; your fee: %s.', 'olivia-studio' ), oys_money( (int) ( $o->meta['app_fee_cents'] ?? 0 ), $o->currency ) ) ) . '</p>' : '' ),
			array(), array( __( 'Open orders', 'olivia-studio' ), admin_url( 'admin.php?page=oys-orders' ) ) );
	}

	/* ---------- Preview and test (Studio → Emails) ---------- */

	/** Sample values for previews and test emails. */
	public static function sample_vars() {
		$user   = wp_get_current_user();
		$start  = gmdate( 'Y-m-d 17:00:00', time() + 2 * DAY_IN_SECONDS );
		$online = (int) OYS_Settings::get( 'online_only' );
		$pass   = '';
		foreach ( (array) OYS_Products::all() as $p ) {
			if ( 'pack' === $p['kind'] && ! empty( $p['active'] ) ) {
				$pass = oys_product_name( $p );
				break;
			}
		}
		$pass  = $pass ?: __( '5-class pass', 'olivia-studio' );
		$next  = OYS_Schedule::query( array( 'kind' => 'group', 'from' => oys_now(), 'status' => 'scheduled', 'limit' => 1 ) );
		$class = $next ? oys_session_title( $next[0] ) : 'Hatha Flow'; // the site's own class, not a made-up one
		return array(
			'first_name' => $user && $user->first_name ? $user->first_name : 'Emma', 'studio' => OYS_Settings::get( 'email_from_name' ),
			'class' => $class, 'date' => oys_date( $start, 'l, F j' ), 'date_short' => oys_date( $start, 'M j' ),
			'day' => oys_date( $start, 'D' ), 'time' => oys_time( $start ), 'location' => $online ? __( 'Online', 'olivia-studio' ) : 'Fort Myers', 'teacher' => OYS_Settings::get( 'owner_name' ), 'host' => 'Emma', 'guest_name' => 'Sofia',
			'reason' => __( 'Sorry, I am ill.', 'olivia-studio' ), 'how' => __( 'One class was taken from your pass.', 'olivia-studio' ), 'pass' => $pass, 'classes_left' => sprintf( _n( '%d class', '%d classes', 2, 'olivia-studio' ), 2 ),
			'expires' => wp_date( get_option( 'date_format' ), time() + 7 * DAY_IN_SECONDS ), 'recipient' => 'Sofia', 'from' => 'Emma', 'gift' => $pass,
			'recipient_email' => 'sofia@example.com', 'ends' => wp_date( get_option( 'date_format' ), time() + 20 * DAY_IN_SECONDS ),
			'missing' => sprintf( _n( '%d more person', '%d more people', 2, 'olivia-studio' ), 2 ), 'deadline' => oys_date( gmdate( 'Y-m-d 17:00:00', time() + DAY_IN_SECONDS ), 'l, g:i a' ),
			'sessions' => sprintf( _n( '%d session', '%d sessions', 3, 'olivia-studio' ), 3 ), 'until' => wp_date( get_option( 'date_format' ), time() + 60 * DAY_IN_SECONDS ),
			'percent' => '15%', 'prize' => __( 'a free class', 'olivia-studio' ), 'period' => wp_date( 'F' ), 'tickets' => 8, 'entrants' => 24, 'next_draw' => wp_date( get_option( 'date_format' ), time() + 30 * DAY_IN_SECONDS ),
		);
	}

	/** The full email with sample values: [ subject, html ]. $t overrides the saved texts (unsaved edits). */
	public static function preview( $key, array $t = array() ) {
		$t    = array_merge( OYS_Email_Templates::get( $key ), $t );
		$vars = self::sample_vars();
		$online = (int) OYS_Settings::get( 'online_only' );
		$demo   = (object) array( 'title' => $vars['class'], 'class_slug' => '', 'starts_at' => gmdate( 'Y-m-d 17:00:00', time() + 2 * DAY_IN_SECONDS ), 'ends_at' => gmdate( 'Y-m-d 18:30:00', time() + 2 * DAY_IN_SECONDS ), 'location' => $online ? '' : 'Fort Myers', 'format' => $online ? 'online' : 'studio', 'teacher_id' => 0, 'kind' => 'group' );
		$details = in_array( $key, array( 'booking_confirmed', 'guests_added', 'guest_invite', 'booking_cancelled', 'class_cancelled', 'guest_cancelled', 'session_changed', 'waitlist_promoted', 'waitlist_spot_open', 'reminder', 'private_offer' ), true )
			? self::session_block( $demo ) : '';
		if ( 'we_miss_you' === $key || 'welcome' === $key ) {
			$details = self::upcoming_html();
		} elseif ( 'weekly_digest' === $key ) {
			$details = self::week_html() ?: self::upcoming_html( 6 );
		}
		if ( 'join_reminder' === $key ) {
			$details = '<p style="margin:22px 0 6px"><a href="#" style="display:inline-block;background:#C6A3EE;color:#12231A;text-decoration:none;font-weight:700;letter-spacing:.06em;text-transform:uppercase;font-size:13px;padding:13px 20px;border-radius:999px;border:2px solid #12231A">' . esc_html__( 'Join the live class', 'olivia-studio' ) . '</a></p>';
		}
		$body = OYS_Email_Templates::paragraphs( $t['message'], $vars ) . $details . OYS_Email_Templates::paragraphs( $t['closing'], $vars );
		$cta  = $t['button'] ? array( OYS_Email_Templates::fill( $t['button'], $vars ), home_url( '/' ) ) : null;
		return array( OYS_Email_Templates::fill( $t['subject'], $vars ), self::wrap( OYS_Email_Templates::fill( $t['heading'], $vars ), $body, $cta ) );
	}

	public static function send_test( $key, $to ) {
		[ $subject, $html ] = self::preview( $key );
		$headers = array_merge( array( 'Content-Type: text/html; charset=UTF-8' ), OYS_Mailer::headers() );
		$subject = __( '[Test]', 'olivia-studio' ) . ' ' . $subject;
		$sent    = wp_mail( $to, $subject, $html, $headers );
		do_action( 'oys_email_sent', $to, $subject, $html );
		return $sent;
	}
}
