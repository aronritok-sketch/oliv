<?php
/**
 * Public side: shortcodes and form handlers.
 *
 *   [oys_schedule days="14" kind="group,event" class=""]  bookable timetable
 *   [oys_events]                                            upcoming workshops and events
 *   [oys_pricing]                                           prices with buy buttons
 *   [oys_book]                                              booking / checkout page
 *   [oys_account]                                           customer account (log in / sign up when logged out)
 *   [oys_gift_cards]                                        buy a gift card
 *   [oys_private_request]                                   private session request form
 */

defined( 'ABSPATH' ) || exit;

class OYS_Frontend {

	public static function init() {
		foreach ( array( 'schedule', 'calendar', 'events', 'pricing', 'book', 'account', 'gift_cards', 'private_request', 'private_box' ) as $sc ) {
			add_shortcode( 'oys_' . $sc, array( __CLASS__, 'sc_' . $sc ) );
		}
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_oys_checkout', array( __CLASS__, 'handle_checkout' ) );
		add_action( 'admin_post_nopriv_oys_checkout', array( __CLASS__, 'handle_checkout_guest' ) );
		add_action( 'admin_post_oys_buy', array( __CLASS__, 'handle_buy' ) );
		add_action( 'admin_post_nopriv_oys_buy', array( __CLASS__, 'handle_checkout_guest' ) );
		add_action( 'admin_post_oys_cancel', array( __CLASS__, 'handle_cancel' ) );
		add_action( 'admin_post_oys_waitlist', array( __CLASS__, 'handle_waitlist' ) );
		add_action( 'admin_post_oys_ics', array( __CLASS__, 'handle_ics' ) );
		add_action( 'template_redirect', array( __CLASS__, 'return_from_stripe' ) );
		add_filter( 'body_class', function ( $c ) {
			$c[] = is_user_logged_in() ? 'oys-logged-in' : 'oys-logged-out';
			return $c;
		} );
	}

	public static function assets() {
		wp_enqueue_style( 'olivia-studio', OYS_URL . 'assets/oys.css', array(), OYS_VERSION );
		// the price list's switches (length, „with a friend”) and the private request form
		wp_enqueue_script( 'olivia-studio', OYS_URL . 'assets/oys.js', array(), OYS_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	}

	private static function form_open( $action, $extra = '' ) {
		return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" ' . $extra . '>'
			. '<input type="hidden" name="action" value="' . esc_attr( $action ) . '">'
			. wp_nonce_field( $action, '_wpnonce', true, false );
	}

	private static function current_url() {
		return OYS_I18n::request_url();
	}

	/* ======================================================================
	   Timetable
	   ====================================================================== */

	/**
	 * [oys_calendar] – the classes as a real calendar, by month, paged with arrows (Áron, 16 November: „A naptár csúnya,
	 * legyen lapozható”); only the bookable weeks have classes (setting `booking_window_days`; „6 héttel előre
	 * foglalható, és csak annyira látszódjon a naptár is”). It opens on the month of the next class. Every class is a link
	 * to its booking; on a phone the days show dots and the month's classes are listed under it. Without JavaScript every
	 * month shows, one under the other.
	 */
	/**
	 * The next useful step for a class the visitor has booked: [url, label]. On the day of an online class it is the way in
	 * (their own link to the live room or the meeting), otherwise their bookings, where they can see and cancel it.
	 */
	public static function mine_action( $booking, $session ) {
		$join = OYS_Bookings::join_link( $booking, $session );
		$soon = oys_ts( $session->starts_at ) - time() < 12 * HOUR_IN_SECONDS && oys_ts( $session->ends_at ) > time();
		if ( $join && $soon ) {
			return array( $join, __( 'Join the class', 'olivia-studio' ) );
		}
		return array( oys_account_url(), __( 'My bookings', 'olivia-studio' ) );
	}

	public static function sc_calendar( $atts ) {
		$atts   = shortcode_atts( array( 'kind' => 'group,event', 'class' => '' ), $atts );
		$window = max( 7, (int) OYS_Settings::get( 'booking_window_days' ) );
		$tz     = wp_timezone();
		$today  = new DateTimeImmutable( 'today', $tz );
		$last   = $today->modify( '+' . ( $window - 1 ) . ' days' );
		$items  = OYS_Schedule::query( array(
			'kind'       => array_filter( array_map( 'trim', explode( ',', $atts['kind'] ) ) ),
			'from'       => oys_now(),
			'to'         => $last->modify( '+1 day' )->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' ),
			'status'     => 'scheduled',
			'class_slug' => sanitize_title( $atts['class'] ),
		) );
		$by_day = array();
		foreach ( $items as $s ) {
			$by_day[ wp_date( 'Y-m-d', oys_ts( $s->starts_at ) ) ][] = $s;
		}
		$user_id = get_current_user_id();
		// Olívia, 19 November (Áron: „Lehet privát időpontot kérni a naptárból”): any coming day can be chosen, and under the
		// calendar a quiet offer asks for a one-to-one session on it, with a time – only an offer, the calendar is about the
		// group classes
		$ask_on  = in_array( 'group', array_map( 'trim', explode( ',', $atts['kind'] ) ), true ) && ( OYS_Services::offered() || OYS_Products::has_plain_private() ) && (bool) apply_filters( 'oys_calendar_private', true );
		$link    = function ( $s ) use ( $user_id ) {
			$mine = $user_id ? OYS_Bookings::active_for( $user_id, $s->id ) : null;
			$left = OYS_Schedule::spots_left( $s );
			if ( $mine && 'pending' !== $mine->status ) {
				return array( 'is-mine', __( 'You\'re booked', 'olivia-studio' ), $mine );
			}
			if ( OYS_Schedule::closed_reason( $s ) ) {
				return array( 'is-closed', __( 'Booking closed', 'olivia-studio' ), null );
			}
			return $left < 1 ? array( 'is-full', __( 'Full, waitlist open', 'olivia-studio' ), null ) : array( '', sprintf( _n( '%d spot left', '%d spots left', min( $left, 99 ), 'olivia-studio' ), min( $left, 99 ) ), null );
		};
		$monday = fn( $d ) => $d->modify( '-' . ( (int) $d->format( 'N' ) - 1 ) . ' days' );
		$heads  = '';
		for ( $i = 0, $m0 = $monday( $today ); $i < 7; $i++ ) {
			$heads .= '<span class="oys-cal__dow" aria-hidden="true">' . esc_html( wp_date( 'D', $m0->modify( "+$i days" )->getTimestamp() ) ) . '</span>';
		}
		$months = array();
		for ( $m = $today->modify( 'first day of this month' ); $m <= $last; $m = $m->modify( 'first day of next month' ) ) {
			$months[] = $m;
		}
		$first_class = $items ? wp_date( 'Y-m', oys_ts( $items[0]->starts_at ) ) : $today->format( 'Y-m' );
		$panels      = '';
		foreach ( $months as $mi => $m ) {
			$from = $monday( $m );
			$end  = $m->modify( 'last day of this month' );
			$to   = $end->modify( '+' . ( 7 - (int) $end->format( 'N' ) ) . ' days' );
			$grid = '';
			$list = '';
			for ( $day = $from; $day <= $to; $day = $day->modify( '+1 day' ) ) {
				$key   = $day->format( 'Y-m-d' );
				$ts    = $day->getTimestamp();
				$other = $day->format( 'Y-m' ) !== $m->format( 'Y-m' );
				$state = $other ? ' is-other' : ( $day < $today ? ' is-past' : ( $day > $last ? ' is-after' : '' ) );
				$state .= ! $other && $key === $today->format( 'Y-m-d' ) ? ' is-today' : '';
				$day_s = $other ? array() : ( $by_day[ $key ] ?? array() );
				$chips = '';
				$states = array_map( $link, $day_s );
				foreach ( $day_s as $i => $s ) {
					list( $cls, $note, $mine ) = $states[ $i ];
					$title = (string) apply_filters( 'oys_card_title', oys_session_title( $s ), $s );
					// Áron, 16 November: „Foglalva vagy nem jo.” – it said so twice (a line and a grey pill). A booked class now
					// says it once, with a tick, and the button is the next useful step: on the day of an online class the
					// way in, otherwise the guest's bookings (where they can also cancel).
					$go = $mine ? self::mine_action( $mine, $s ) : null;
					$chips .= '<a class="oys-cal__chip ' . esc_attr( $cls ) . '" href="' . esc_url( $go ? $go[0] : oys_book_url( $s->id ) ) . '"><b>' . ( $mine ? oys_icon( 'check' ) : '' ) . esc_html( oys_time( $s->starts_at ) ) . '</b> <span>' . esc_html( $title ) . '</span></a>';
					if ( $mine ) {
						$state_line = '<small class="oys-cal__ok">' . oys_icon( 'check' ) . esc_html( $note ) . '</small>';
						$button     = '<a class="session__book session__book--mine oys-cal__go" href="' . esc_url( $go[0] ) . '">' . esc_html( $go[1] ) . oys_icon( 'arrow' ) . '</a>';
					} elseif ( 'is-closed' === $cls ) {
						$state_line = '';
						$button     = '<span class="session__status oys-cal__go">' . esc_html( $note ) . '</span>';
					} else {
						$state_line = '<small class="oys-cal__left">' . esc_html( $note ) . '</small>';
						$button     = '<a class="session__book oys-cal__go' . ( 'is-full' === $cls ? ' session__book--wait' : '' ) . '" href="' . esc_url( oys_book_url( $s->id ) ) . '">' . esc_html( 'is-full' === $cls ? __( 'Join the waitlist', 'olivia-studio' ) : __( 'Book', 'olivia-studio' ) ) . oys_icon( 'arrow' ) . '</a>';
					}
					$list .= '<li class="oys-cal__item ' . esc_attr( $cls ) . '" data-day="' . esc_attr( $key ) . '"><span class="oys-cal__when"><b>' . esc_html( wp_date( 'D', $ts ) ) . '</b>' . esc_html( wp_date( oys_date_format( 'M j' ), $ts ) ) . '</span>'
						. '<span class="oys-cal__what"><b>' . esc_html( $title ) . '</b><small>' . esc_html( oys_time( $s->starts_at ) . '–' . oys_time( $s->ends_at ) ) . '</small>' . $state_line . '</span>'
						. $button . '</li>';
				}
				$label = wp_date( oys_date_format( 'l, F j' ), $ts ) . ( $day_s ? ': ' . implode( ', ', array_map( fn( $s ) => oys_time( $s->starts_at ) . ' ' . apply_filters( 'oys_card_title', oys_session_title( $s ), $s ), $day_s ) ) : '' );
				$has_mine = in_array( 'is-mine', array_column( $states, 0 ), true );
				$free     = ! $day_s && ! $other && $ask_on && $day > $today;
				$pickable = ( $day_s && ! $other ) || $free;
				$grid .= '<div class="oys-cal__day' . esc_attr( $state ) . ( $day_s ? ' has-class' : '' ) . ( $free ? ' is-free' : '' ) . ( $has_mine ? ' has-mine' : '' ) . '" role="listitem"' . ( $other ? ' aria-hidden="true"' : ' aria-label="' . esc_attr( $label ) . '"' ) . ( $day_s || $free ? ' data-day="' . esc_attr( $key ) . '" data-label="' . esc_attr( wp_date( oys_date_format( 'l, F j' ), $ts ) ) . '" data-short="' . esc_attr( wp_date( oys_date_format( 'M j' ), $ts ) ) . '"' . ( $pickable ? ' tabindex="0"' : '' ) : '' ) . '>'
					. '<span class="oys-cal__num">' . esc_html( $day->format( 'j' ) ) . '</span>'
					. ( $day_s ? '<span class="oys-cal__dots" aria-hidden="true">' . implode( '', array_map( fn( $st ) => 'is-mine' === $st[0] ? '<i class="is-mine"></i>' : '<i></i>', array_slice( $states, 0, 3 ) ) ) . '</span><div class="oys-cal__chips">' . $chips . '</div>' : '' ) . '</div>';
			}
			$name    = wp_date( _x( 'F Y', 'calendar month', 'olivia-studio' ), $m->getTimestamp() );
			$prev    = $mi > 0 ? sprintf( __( 'Previous month: %s', 'olivia-studio' ), wp_date( _x( 'F Y', 'calendar month', 'olivia-studio' ), $months[ $mi - 1 ]->getTimestamp() ) ) : '';
			$next    = isset( $months[ $mi + 1 ] ) ? sprintf( __( 'Next month: %s', 'olivia-studio' ), wp_date( _x( 'F Y', 'calendar month', 'olivia-studio' ), $months[ $mi + 1 ]->getTimestamp() ) ) : '';
			$arrow   = fn( $dir, $label, $to ) => '<button type="button" class="oys-cal__arrow oys-cal__arrow--' . $dir . '" data-cal-go="' . $to . '"' . ( '' === $label ? ' disabled aria-hidden="true"' : ' aria-label="' . esc_attr( $label ) . '"' ) . '><svg viewBox="0 0 24 24" aria-hidden="true"><path d="' . ( 'prev' === $dir ? 'M15 5l-7 7 7 7' : 'M9 5l7 7-7 7' ) . '"/></svg></button>';
			$panels .= '<section class="oys-cal__month" data-month="' . esc_attr( $m->format( 'Y-m' ) ) . '"' . ( $m->format( 'Y-m' ) === $first_class ? ' data-start' : '' ) . ' aria-label="' . esc_attr( $name ) . '">'
				. '<header class="oys-cal__bar">' . $arrow( 'prev', $prev, $mi - 1 ) . '<h3 class="oys-cal__title">' . esc_html( $name ) . '</h3>' . $arrow( 'next', $next, $mi + 1 ) . '</header>'
				. '<div class="oys-cal__grid" role="list">' . $heads . $grid . '</div>'
				// only the day she taps shows under the calendar, not every class again (Olívia, 19 November: „a naptár alatt ne
				// legyen felsorolva az összes következő óra újra, csak amit kiválasztok a naptárban”)
				. ( $list
					// Olívia, 19 November: „…és foglald le a helyed!”; Áron, the same day: „az »itt látod az órát« vegyük ki”
					? '<p class="oys-cal__pick">' . esc_html__( 'Tap a day in the calendar and book your spot!', 'olivia-studio' ) . '</p><ol class="oys-cal__list">' . $list . '</ol>'
					: '<p class="oys-cal__empty">' . esc_html__( 'No group classes this month.', 'olivia-studio' ) . ( $ask_on ? ' ' . esc_html__( 'You can still ask for a one-to-one session: tap a day.', 'olivia-studio' ) : '' ) . '</p>' )
				// Áron, 19 November: „Ezen a napon nincs csoportos óra.” (not „Erre a napra …”)
				. ( $ask_on ? '<p class="oys-cal__none" hidden>' . esc_html__( 'No group class on this day.', 'olivia-studio' ) . '</p>' : '' )
				. '</section>';
		}
		$note = sprintf( _n( 'You can book up to %d week ahead.', 'You can book up to %d weeks ahead.', (int) round( $window / 7 ), 'olivia-studio' ), (int) round( $window / 7 ) );
		return '<div class="oys-cal" data-oys-cal>' . $panels . ( $ask_on ? self::calendar_ask() : '' ) . '<p class="oys-cal__note">' . esc_html( $note ) . '</p></div>';
	}

	/** Under the calendar, once a day is chosen: a one-to-one session on that day, at a time (or any time). */
	/**
	 * Under the calendar: a one-to-one session on the chosen day, the time chosen with a tap (Áron, 19 November: „nem
	 * tetszik, hogy ilyen legördülős az időpontválasztó … 14:00-től 21:00-ig lehessen időpontot választani” – his „A”:
	 * the half hours as buttons, by afternoon and evening, and „any time” among them).
	 */
	private static function calendar_ask() {
		$url   = oys_account_url( 'private' );
		$hours = array_values( array_map( 'intval', (array) apply_filters( 'oys_calendar_ask_hours', array( 14, 21 ) ) ) );
		$from  = max( 0, min( 23, $hours[0] ?? 14 ) );
		$to    = max( $from, min( 23, $hours[1] ?? 21 ) );
		$parts = array(
			'morning'   => array( __( 'Morning', 'olivia-studio' ), '' ),
			'afternoon' => array( __( 'Afternoon', 'olivia-studio' ), '' ),
			'evening'   => array( __( 'Evening', 'olivia-studio' ), '' ),
		);
		for ( $m = $from * 60; $m <= $to * 60; $m += 30 ) {
			$t    = sprintf( '%02d:%02d', intdiv( $m, 60 ), $m % 60 );
			$part = $m < 12 * 60 ? 'morning' : ( $m < 18 * 60 ? 'afternoon' : 'evening' );
			$parts[ $part ][1] .= '<button type="button" class="oys-time" data-ask-time="' . esc_attr( $t ) . '" aria-pressed="false">' . esc_html( oys_is_hu() ? $t : gmdate( 'g:i a', $m * 60 ) ) . '</button>';
		}
		$times = '';
		foreach ( $parts as $part ) {
			$times .= '' !== $part[1] ? '<span class="oys-times__part">' . esc_html( $part[0] ) . '</span><div class="oys-times__grid">' . $part[1] . '</div>' : '';
		}
		$hour = fn( $h ) => oys_is_hu() ? (string) $h : gmdate( 'g a', $h * HOUR_IN_SECONDS );
		return '<div class="oys-cal__ask" data-oys-cal-ask data-url="' . esc_url( $url ) . '" hidden>'
			. '<p><b>' . esc_html__( 'Another time would suit you?', 'olivia-studio' ) . '</b> ' . esc_html__( 'If you would come on your own or as a pair, ask for a one-to-one session on this day:', 'olivia-studio' ) . ' <b data-ask-day></b></p>'
			. '<div class="oys-times" role="group" aria-labelledby="oys-times-q"><p class="oys-times__q" id="oys-times-q">' . esc_html__( 'Which time would suit you?', 'olivia-studio' ) . '</p>' . $times
			. '<button type="button" class="oys-time oys-time--any" data-ask-time="" aria-pressed="true">' . esc_html( sprintf( __( 'Any time between %1$s and %2$s', 'olivia-studio' ), $hour( $from ), $hour( $to ) ) ) . '</button></div>'
			. '<a class="btn btn--primary oys-cal__ask-go" data-ask-go data-label="' . esc_attr__( 'Ask for a time: %s', 'olivia-studio' ) . '" href="' . esc_url( $url ) . '">' . esc_html__( 'Ask for this time', 'olivia-studio' ) . '</a></div>';
	}

	public static function sc_schedule( $atts ) {
		$atts  = shortcode_atts( array( 'days' => 14, 'kind' => 'group,event', 'class' => '', 'empty_days' => '', 'next' => 0 ), $atts );
		// Without days that have no class (setting `schedule_empty_days`), the timetable lists the next classes however
		// far they are (`next`, 6 by default), so a timetable never stands empty while the next class is weeks away.
		$atts['empty_days'] = in_array( $atts['empty_days'], array( 'yes', 'no' ), true ) ? $atts['empty_days'] : ( 'no' === OYS_Settings::get( 'schedule_empty_days' ) ? 'no' : 'yes' );
		// how many when not said: 6, or what the site wants (Olívia, 19 November: „itt mindig 3 következő óra látszon … minden
		// oldalon ahol van” – the rest is in the calendar, 6 weeks ahead)
		$next  = 'no' === $atts['empty_days'] ? ( (int) $atts['next'] ?: max( 1, (int) apply_filters( 'oys_schedule_next', 6, $atts ) ) ) : 0;
		$kinds = array_filter( array_map( 'trim', explode( ',', $atts['kind'] ) ) );
		$items = OYS_Schedule::query( array(
			'kind'       => $kinds,
			'from'       => oys_now(),
			'to'         => oys_utc_plus( ( $next ? max( 120, (int) $atts['days'] ) : (int) $atts['days'] ) * DAY_IN_SECONDS ),
			'status'     => 'scheduled',
			'class_slug' => sanitize_title( $atts['class'] ),
		) );
		if ( $next ) {
			$items        = array_slice( $items, 0, $next );
			$atts['days'] = $items ? (int) ceil( ( oys_ts( end( $items )->starts_at ) - strtotime( 'today', time() ) ) / DAY_IN_SECONDS ) + 2 : 0;
		}
		$by_day = array();
		foreach ( $items as $s ) {
			$by_day[ wp_date( 'Y-m-d', oys_ts( $s->starts_at ) ) ][] = $s;
		}
		$user_id = get_current_user_id();
		$tones   = array( 'lilac', 'pink', 'sun', 'sage' );
		$classes = array_keys( oys_class_options() );

		$out   = array( '<div class="schedule oys-schedule">' );
		$today = new DateTimeImmutable( 'today', wp_timezone() );
		for ( $d = 0; $d < (int) $atts['days']; $d++ ) {
			$day  = $today->modify( "+$d days" );
			$key  = $day->format( 'Y-m-d' );
			$list = $by_day[ $key ] ?? array();
			$head = '<h3><abbr title="' . esc_attr( wp_date( oys_date_format( 'l, F j' ), $day->getTimestamp() ) ) . '">' . esc_html( wp_date( 'D', $day->getTimestamp() ) ) . '</abbr><small>' . esc_html( wp_date( oys_date_format( 'M j' ), $day->getTimestamp() ) ) . '</small></h3>';
			if ( ! $list ) {
				if ( 'yes' === $atts['empty_days'] ) {
					$out[] = '<div class="day is-empty">' . $head . '<p>' . esc_html__( 'No group classes today. Private sessions are available on request.', 'olivia-studio' ) . '</p></div>';
				}
				continue;
			}
			$out[] = '<div class="day">' . $head . '<ul>';
			foreach ( $list as $s ) {
				$idx   = array_search( $s->class_slug, $classes, true );
				$tone  = 'event' === $s->kind ? 'pink' : $tones[ ( false === $idx ? 0 : $idx ) % 4 ];
				$left  = OYS_Schedule::spots_left( $s );
				$mine  = $user_id ? OYS_Bookings::active_for( $user_id, $s->id ) : null;
				$wait  = $user_id && ! $mine ? OYS_Bookings::waitlist_position( $user_id, $s->id ) : 0;
				$class_url = apply_filters( 'oys_class_url', '', $s->class_slug );
				// a site can shorten the card's title (oliviajoga.online: the „Online” tag says it, the title need not)
				$plain     = esc_html( (string) apply_filters( 'oys_card_title', oys_session_title( $s ), $s ) );
				$title     = $class_url && 'group' === $s->kind ? '<a href="' . esc_url( $class_url ) . '">' . $plain . '</a>' : $plain;

				if ( $mine && 'pending' !== $mine->status ) {
					$go     = self::mine_action( $mine, $s );
					$action = '<span class="session__status is-booked">' . oys_icon( 'check' ) . esc_html__( 'You\'re booked', 'olivia-studio' ) . '</span>'
						. '<a class="session__book session__book--mine" href="' . esc_url( $go[0] ) . '">' . esc_html( $go[1] ) . oys_icon( 'arrow' ) . '</a>';
				} elseif ( $wait ) {
					$action = '<span class="session__status">' . sprintf( esc_html__( 'Waitlist #%d', 'olivia-studio' ), $wait ) . '</span>';
				} elseif ( OYS_Schedule::closed_reason( $s ) ) {
					$action = '<span class="session__status">' . esc_html__( 'Booking closed', 'olivia-studio' ) . '</span>';
				} elseif ( $left < 1 ) {
					$action = '<a class="session__book session__book--wait" href="' . esc_url( oys_book_url( $s->id ) ) . '">' . esc_html__( 'Join the waitlist', 'olivia-studio' ) . oys_icon( 'arrow' ) . '</a>';
				} else {
					$action = '<a class="session__book" href="' . esc_url( oys_book_url( $s->id ) ) . '">' . esc_html__( 'Book', 'olivia-studio' ) . '<span class="sr-only"> ' . $plain . ', ' . esc_html( oys_date( $s->starts_at, 'l g:i a' ) ) . '</span>' . oys_icon( 'arrow' ) . '</a>';
				}
				$spots  = $left < 1 ? __( 'Full', 'olivia-studio' ) : ( $left <= 3 ? sprintf( _n( '%d spot left', '%d spots left', $left, 'olivia-studio' ), $left ) : '' );
				$online = oys_is_online( $s );
				$lang   = oys_valid_lang( $s->lang ?? 'en' );
				$tags   = ( $online ? '<span class="session__online">' . esc_html__( 'Online', 'olivia-studio' ) . '</span>' : '' )
					. ( oys_is_hybrid( $s ) ? '<span class="session__online">' . esc_html__( '+ Live online', 'olivia-studio' ) . '</span>' : '' )
					. ( oys_is_donation( $s ) ? '<span class="session__donation">' . esc_html__( 'By donation', 'olivia-studio' ) . '</span>' : '' )
					// one-language site (Olivia, 11.13: no language anywhere on oliviajoga.online): no language chip
					. ( count( OYS_I18n::languages() ) > 1 ? '<span class="session__lang" title="' . esc_attr( sprintf( __( 'Taught in %s', 'olivia-studio' ), translate( OYS_I18n::LANGS[ $lang ]['name'], 'olivia-studio' ) ) ) . '">' . esc_html( oys_lang_short( $lang ) ) . '</span>' : '' ) // phpcs:ignore WordPress.WP.I18n
					. ( $s->note ? '<span class="session__note">' . esc_html( oys_t( $s->note ) ) . '</span>' : '' );
				$minutes = (int) round( ( oys_ts( $s->ends_at ) - oys_ts( $s->starts_at ) ) / 60 );
				$out[]   = '<li class="session session--' . esc_attr( $tone ) . ( $online ? ' session--online' : '' ) . '">'
					. '<span class="session__time"><b>' . esc_html( oys_time( $s->starts_at ) ) . '</b><small>' . esc_html( sprintf( __( '%d min', 'olivia-studio' ), $minutes ) ) . '</small></span>'
					. '<span class="session__body"><span class="session__class">' . $title . OYS_Teachers::card_line( $s ) . '</span>'
					. '<span class="session__place">' . esc_html( $online ? ( $s->price_cents || oys_is_donation( $s ) ? oys_price_label( $s ) : '' ) : oys_t( $s->location ) ) . ' <span class="sr-only">' . esc_html( oys_time( $s->starts_at ) . ' – ' . oys_time( $s->ends_at ) ) . '</span></span>'
					. '<span class="session__tags">' . $tags . '</span></span>'
					. '<span class="session__actions">' . ( $spots ? '<span class="session__spots' . ( $left < 1 ? ' is-full' : '' ) . '">' . esc_html( $spots ) . '</span>' : '' ) . $action . '</span></li>';
			}
			$out[] = '</ul></div>';
		}
		if ( ! $items && 'yes' !== $atts['empty_days'] ) {
			$out[] = '<p class="oys-empty">' . esc_html__( 'New dates are coming soon.', 'olivia-studio' ) . '</p>';
		}
		$out[] = '</div>';
		return implode( '', $out );
	}

	public static function sc_events( $atts ) {
		$events = OYS_Schedule::query( array( 'kind' => 'event', 'from' => oys_now(), 'status' => 'scheduled', 'limit' => 12 ) );
		if ( ! $events ) {
			return '<p class="oys-empty">' . esc_html__( 'The next events will be announced here and on Instagram first.', 'olivia-studio' ) . '</p>';
		}
		$tones = array( 'pink', 'lilac', 'sun' );
		$out   = '<ul class="events oys-events">';
		foreach ( $events as $i => $s ) {
			$left = OYS_Schedule::spots_left( $s );
			$out .= '<li class="event"><a href="' . esc_url( oys_book_url( $s->id ) ) . '"><span class="event__date event__date--' . $tones[ $i % 3 ] . '"><span>' . esc_html( wp_date( 'M', oys_ts( $s->starts_at ) ) ) . '</span><b>' . esc_html( wp_date( 'j', oys_ts( $s->starts_at ) ) ) . '</b></span>'
				. '<span><span class="event__title">' . esc_html( oys_session_title( $s ) ) . '</span>'
				. '<span class="event__meta">' . esc_html( oys_date( $s->starts_at, 'l, g:i a' ) . ' – ' . oys_time( $s->ends_at ) . ( $s->location ? ' · ' . oys_t( $s->location ) : '' ) . ' · ' . oys_price_label( $s ) ) . ( $left < 1 ? ' · ' . __( 'Full, waitlist open', 'olivia-studio' ) : '' ) . '</span></span>'
				. '<span class="event__go" aria-hidden="true">' . oys_icon( 'arrow' ) . '</span></a></li>';
		}
		return $out . '</ul>';
	}

	/* ======================================================================
	   Pricing
	   ====================================================================== */


	public static function sc_pricing( $atts ) {
		$dropin = (int) apply_filters( 'oys_dropin_display_price', 2500 );
		$cards  = array();
		$online_price = (int) OYS_Settings::get( 'online_price_cents' );
		$ratio        = OYS_Passes::online_per_credit();
		$online_only  = (bool) OYS_Settings::get( 'online_only' );
		// Olivia, 13 November: „Az ajándékutalvány legyen látványosabb” – a site may show it as its own highlighted line
		$gift_line = (bool) apply_filters( 'oys_price_gift_line', false );
		if ( $online_only ) {
			// the one-class online pass at the drop-in price (the gift version of the drop-in) gives the card its length
			$single = null;
			foreach ( OYS_Products::all( true ) as $p ) {
				if ( 'online_pack' === $p['kind'] && 1 === (int) $p['credits'] && (int) $p['price_cents'] === $online_price ) {
					$single = $p;
				}
			}
			$minutes  = $single ? (int) $single['duration_min'] : 0;
			$features = apply_filters( 'oys_dropin_features', array( __( 'Any live online group class', 'olivia-studio' ), ( OYS_Zoom::enabled() ? __( 'Join from home on Zoom', 'olivia-studio' ) : __( 'Join from home in your browser, no app needed', 'olivia-studio' ) ), __( 'The link comes by email and is in your account', 'olivia-studio' ) ) );
			$cards[]  = array( 'tone' => 'paper', 'title' => (string) apply_filters( 'oys_price_card_title', __( 'Live online class', 'olivia-studio' ), $single ? $single : array( 'kind' => 'online_drop' ) ), 'price' => oys_money( $online_price ), 'unit' => $minutes ? sprintf( __( 'per session, %d minutes', 'olivia-studio' ), $minutes ) : __( 'per class', 'olivia-studio' ), 'features' => (array) $features, 'gift' => $gift_line && $single && ! empty( $single['giftable'] ), 'cta' => array( __( 'Book a class', 'olivia-studio' ), oys_page_url( 'book' ) ), 'featured' => false );
		} else {
			$cards[] = array( 'tone' => 'paper', 'title' => __( 'Drop-in class', 'olivia-studio' ), 'price' => oys_money( $dropin ), 'unit' => __( 'per class', 'olivia-studio' ), 'features' => array_filter( array( __( 'Any group class in person', 'olivia-studio' ), $online_price ? sprintf( __( 'Online classes: %s', 'olivia-studio' ), oys_money( $online_price ) ) : '', __( 'Bring friends: add guests when you book', 'olivia-studio' ), 'off' !== OYS_Settings::get( 'pay_later' ) ? __( 'Pay online or at the studio', 'olivia-studio' ) : '' ) ), 'cta' => array( __( 'Book a class', 'olivia-studio' ), oys_page_url( 'book' ) ), 'featured' => false );
		}
		$tones = array( 'lilac', 'sun', 'pink' );
		$i     = 0;
		$svc_products = array();
		foreach ( OYS_Products::all( true ) as $p ) {
			// private yoga's 75 and 90 minutes are lines on the 60-minute card; a service's single session has its own card
			if ( 'private_single' === $p['kind'] && '' === $p['service'] && 60 !== (int) $p['duration_min'] ) {
				continue;
			}
			// A one-class online pass at the drop-in price is there to be given as a gift: the drop-in card covers it.
			if ( $online_only && 'online_pack' === $p['kind'] && 1 === (int) $p['credits'] && (int) $p['price_cents'] === $online_price ) {
				continue;
			}
			$features = array_filter( array_map( 'trim', explode( "\n", $p['features'] ) ) );
			$svc = '' !== $p['service'] ? OYS_Services::get( $p['service'] ) : null;
			if ( $svc && in_array( $p['kind'], array( 'private_single', 'private_pack' ), true ) ) {
				$svc_products[ $svc['key'] ][] = $p; // a one-to-one service: its own cards, with a length and a „with a friend” switch
				continue;
			}
			if ( 'private_single' === $p['kind'] ) {
				$cta  = array( __( 'Request a private session', 'olivia-studio' ), oys_account_url( 'private' ) );
				$unit = sprintf( __( '%d minutes', 'olivia-studio' ), (int) $p['duration_min'] );
				foreach ( OYS_Products::all( true ) as $q ) {
					if ( 'private_single' === $q['kind'] && '' === $q['service'] && 60 !== (int) $q['duration_min'] ) {
						$features[] = sprintf( __( '%1$d minutes: %2$s', 'olivia-studio' ), (int) $q['duration_min'], oys_money( $q['price_cents'] ) );
					}
				}
				if ( (int) $p['online_price_cents'] && (int) $p['online_price_cents'] !== (int) $p['price_cents'] ) {
					$features[] = sprintf( __( 'Online: %s (60 minutes)', 'olivia-studio' ), oys_money( $p['online_price_cents'] ) );
				}
				if ( (int) OYS_Settings::get( 'private_first_extra_min' ) ) {
					$features[] = sprintf( __( 'First session: plan about %d extra minutes to talk through your goals', 'olivia-studio' ), (int) OYS_Settings::get( 'private_first_extra_min' ) );
				}
			} elseif ( 'membership' === $p['kind'] ) {
				$cta  = array( __( 'Join', 'olivia-studio' ), oys_page_url( 'book', array( 'product' => $p['id'] ) ) );
				$unit = OYS_Products::period_label( $p );
			} else {
				$cta  = array( 'intro' === $p['kind'] ? __( 'Claim the intro offer', 'olivia-studio' ) : __( 'Buy now', 'olivia-studio' ), oys_page_url( 'book', array( 'product' => $p['id'] ) ) );
				$unit = 'private_pack' === $p['kind'] ? __( 'per pack', 'olivia-studio' ) : sprintf( 'online_pack' === $p['kind'] ? _n( '%d online class', '%d online classes', (int) $p['credits'], 'olivia-studio' ) : _n( '%d class', '%d classes', (int) $p['credits'], 'olivia-studio' ), (int) $p['credits'] );
				if ( 'online_pack' === $p['kind'] && (int) $p['duration_min'] ) {
					$unit = sprintf( __( '%1$d sessions × %2$d minutes', 'olivia-studio' ), (int) $p['credits'], (int) $p['duration_min'] );
				}
				if ( in_array( $p['kind'], array( 'pack', 'intro' ), true ) && $ratio > 1 ) {
					$features[] = sprintf( __( 'Online classes: 1 class = %d online', 'olivia-studio' ), $ratio );
				}
			}
			$group   = 'membership' === $p['kind'] ? 'members' : ( in_array( $p['kind'], array( 'private_single', 'private_pack' ), true ) ? 'private' : 'classes' );
			// a site can name the service above the price instead of the pass (Olívia, 14 Nov: „Legyenek egységesek a bérletes boxok”)
			$cards[] = array( 'tone' => $p['featured'] ? 'forest' : $tones[ $i++ % 3 ], 'title' => (string) apply_filters( 'oys_price_card_title', oys_product_name( $p ), $p ), 'price' => oys_money( $p['price_cents'] ), 'unit' => $unit, 'per' => self::per_session( $p ), 'features' => array_map( 'oys_product_text', $features ), 'gift' => $gift_line && ! empty( $p['giftable'] ), 'cta' => $cta, 'featured' => (bool) $p['featured'], 'group' => $group );
		}
		$teams = $online_only ? null : array( 'tone' => 'pink', 'title' => __( 'Teams & companies', 'olivia-studio' ), 'price' => __( 'Custom', 'olivia-studio' ), 'unit' => __( 'quote', 'olivia-studio' ), 'features' => array( __( 'On-site, outdoors or online', 'olivia-studio' ), __( 'One-off or weekly', 'olivia-studio' ), __( 'Sports teams and clubs too', 'olivia-studio' ) ), 'cta' => array( __( 'Request a proposal', 'olivia-studio' ), apply_filters( 'oys_corporate_contact_url', home_url( '/contact/?topic=corporate#book' ) ) ), 'featured' => false, 'group' => 'private' );
		if ( $teams ) {
			$cards[] = $teams;
		}

		$groups = array(
			'classes' => array( __( 'Group classes', 'olivia-studio' ), $online_only ? __( 'Drop in to a live class, or save with an online pass.', 'olivia-studio' ) : __( 'Drop in, or save with a pass. Use passes in the studio or online.', 'olivia-studio' ), array() ),
			'members' => array( __( 'Memberships', 'olivia-studio' ), __( 'A monthly rhythm, billed automatically. Cancel any time.', 'olivia-studio' ), array() ),
			'private' => array( $online_only ? __( 'Private sessions', 'olivia-studio' ) : __( 'Private & teams', 'olivia-studio' ), $online_only ? __( 'One-on-one online sessions and packs, planned around you.', 'olivia-studio' ) : __( 'One-on-one sessions, packs, and classes for your team.', 'olivia-studio' ), array() ),
		);
		// each one-to-one service on its own, after the group classes (OYS_Services)
		$groups = array_slice( $groups, 0, 2, true ) + array_combine(
			array_map( fn( $k ) => 'svc-' . $k, array_keys( OYS_Services::offered() ) ),
			array_map( fn( $s ) => array( oys_t( $s['label'] ), oys_t( $s['description'] ), array() ), array_values( OYS_Services::offered() ) )
		) + array_slice( $groups, 2, null, true );
		/** Titles and leads of the price groups (key => [title, lead]), e.g. the length of the group class in its title. */
		$heads = (array) apply_filters( 'oys_pricing_groups', array() );
		foreach ( $heads as $key => $h ) {
			if ( isset( $groups[ $key ] ) ) {
				$groups[ $key ][0] = (string) ( $h[0] ?? $groups[ $key ][0] );
				$groups[ $key ][1] = (string) ( $h[1] ?? $groups[ $key ][1] );
			}
		}
		foreach ( $cards as $c ) {
			$groups[ $c['group'] ?? 'classes' ][2][] = $c;
		}
		$out = '<div class="pricing oys-pricing">';
		foreach ( $groups as $key => $g ) {
			$svc_key = str_starts_with( $key, 'svc-' ) ? substr( $key, 4 ) : '';
			if ( '' !== $svc_key && ! empty( $svc_products[ $svc_key ] ) ) {
				$out .= self::service_prices( $svc_key, $g, $svc_products[ $svc_key ], $gift_line );
				continue;
			}
			if ( ! $g[2] ) {
				continue;
			}
			$out .= '<section class="price-group price-group--' . esc_attr( $key ) . '"><header class="price-group__head"><h3>' . esc_html( $g[0] ) . '</h3><p>' . esc_html( $g[1] ) . '</p></header><div class="price-group__cards" style="--n:' . min( 3, count( $g[2] ) ) . '">';
			foreach ( $g[2] as $c ) {
				$out .= self::price_card( $c );
			}
			$out .= '</div></section>';
		}
		return $out . '</div>';
	}

	/**
	 * What one session of a pass comes to (Olívia, 14 November: „minden bérlethez legyen odaírva kiemelten, hogy milyen
	 * összegre jön ki egy óra”), for two also what it is each. Empty for a single session and for a membership.
	 */
	public static function per_session( array $p ) {
		$n = (int) ( $p['credits'] ?? 0 );
		if ( $n < 2 || ! in_array( $p['kind'] ?? '', array( 'pack', 'online_pack', 'intro', 'private_pack' ), true ) ) {
			return '';
		}
		$one = (int) round( (int) $p['price_cents'] / $n );
		return (int) ( $p['people'] ?? 1 ) > 1
			? sprintf( __( '%1$s per session (%2$s each)', 'olivia-studio' ), oys_money( $one ), oys_money( (int) round( $one / 2 ) ) )
			: sprintf( __( '%s per session', 'olivia-studio' ), oys_money( $one ) );
	}

	/** One card of the price list. */
	private static function price_card( array $c, $attrs = '' ) {
		$gift = ! empty( $c['gift'] ) ? '<li class="price__gift"><a href="' . esc_url( oys_page_url( 'gifts' ) ) . '">' . oys_icon( 'gift' ) . '<span>' . esc_html__( 'You can also give it as a gift card', 'olivia-studio' ) . '</span></a></li>' : '';
		return '<article class="price price--' . esc_attr( $c['tone'] ) . '"' . $attrs . '>'
			. ( $c['featured'] ? apply_filters( 'oys_featured_badge', '<span class="price__tag">' . esc_html__( 'Most popular', 'olivia-studio' ) . '</span>' ) : '' )
			. '<h4>' . esc_html( $c['title'] ) . '</h4><p class="price__amount">' . esc_html( $c['price'] ) . '</p><p class="price__unit">' . esc_html( $c['unit'] ) . '</p>'
			. ( ! empty( $c['per'] ) ? '<p class="price__per">' . esc_html( $c['per'] ) . '</p>' : '' )
			. ( ! empty( $c['each'] ) ? '<p class="price__each">' . esc_html( $c['each'] ) . '</p>' : '' )
			. '<ul>' . implode( '', array_map( fn( $f ) => '<li>' . esc_html( $f ) . '</li>', $c['features'] ) ) . $gift . '</ul>'
			. '<a class="btn ' . ( $c['featured'] ? 'btn--orchid' : 'btn--dark' ) . '" href="' . esc_url( $c['cta'][1] ) . '">' . esc_html( $c['cta'][0] ) . '</a></article>';
	}

	/**
	 * A one-to-one service on the price list (Olivia, 13 November): one session and the pass side by side, a switch
	 * for the length (60 or 90 minutes) when there is more than one, and „Párban olcsóbb” – the prices for two –
	 * when the service can be booked with a friend. Every variant is in the page (it works without JavaScript: then
	 * all are listed); assets/oys.js shows the chosen one.
	 */
	private static function service_prices( $key, array $g, array $products, $gift_line ) {
		$svc     = OYS_Services::get( $key );
		$lengths = array();
		$duo     = false;
		foreach ( $products as $p ) {
			$lengths[ OYS_Services::product_minutes( $p ) ] = true;
			$duo = $duo || (int) $p['people'] > 1;
		}
		$lengths = array_keys( $lengths );
		sort( $lengths );
		usort( $products, fn( $a, $b ) => array( (int) $a['people'], OYS_Services::product_minutes( $a ), 'private_pack' === $a['kind'] ) <=> array( (int) $b['people'], OYS_Services::product_minutes( $b ), 'private_pack' === $b['kind'] ) );
		$switch = '';
		if ( count( $lengths ) > 1 ) {
			$switch .= '<div class="oys-seg" role="group" aria-label="' . esc_attr__( 'Length of the session', 'olivia-studio' ) . '">';
			foreach ( $lengths as $n => $m ) {
				$switch .= '<button type="button" data-len="' . (int) $m . '" aria-pressed="' . ( 0 === $n ? 'true' : 'false' ) . '">' . esc_html( sprintf( __( '%d minutes', 'olivia-studio' ), $m ) ) . '</button>';
			}
			$switch .= '</div>';
		}
		if ( $duo ) {
			// Olivia, 14 November: „Jelöld látványosabban a párban olcsóbbat” – what it costs each of you, right on the switch
			$each = 0;
			foreach ( $products as $p ) {
				if ( (int) $p['people'] > 1 && 'private_single' === $p['kind'] ) {
					$each = $each ? min( $each, (int) round( $p['price_cents'] / 2 ) ) : (int) round( $p['price_cents'] / 2 );
				}
			}
			$switch .= '<label class="oys-pair"><input type="checkbox" data-duo><span class="oys-pair__track" aria-hidden="true"></span><span class="oys-pair__text"><b>' . esc_html__( 'Cheaper as a pair', 'olivia-studio' ) . '</b>'
				. ( $each ? '<small>' . esc_html( sprintf( __( 'from %s each', 'olivia-studio' ), oys_money( $each ) ) ) . '</small>' : '' ) . '</span></label>';
		}
		$tones = array( 'lilac', 'sun' );
		$cards = '';
		foreach ( $products as $p ) {
			$m     = OYS_Services::product_minutes( $p );
			$two   = (int) $p['people'] > 1;
			$pack  = 'private_pack' === $p['kind'];
			$unit  = $pack
				? sprintf( $two ? __( '%1$d sessions × %2$d minutes, for the two of you', 'olivia-studio' ) : __( '%1$d sessions × %2$d minutes', 'olivia-studio' ), (int) $p['credits'], $m )
				: sprintf( $two ? __( 'per session, %d minutes, for the two of you', 'olivia-studio' ) : __( 'per session, %d minutes', 'olivia-studio' ), $m );
			$cta   = $pack
				? array( __( 'Buy now', 'olivia-studio' ), oys_page_url( 'book', array( 'product' => $p['id'] ) ) )
				: array( __( 'Ask for a time', 'olivia-studio' ), add_query_arg( array_filter( array( 'topic' => $key, 'length' => count( $lengths ) > 1 ? $m : 0, 'people' => $two ? 2 : 0 ) ), oys_account_url( 'private' ) ) );
			$card  = array( 'tone' => $tones[ $pack ? 1 : 0 ], 'title' => oys_t( $svc['label'] ), 'price' => oys_money( $p['price_cents'] ), 'unit' => $unit, 'per' => self::per_session( $p ), 'each' => $two && ! $pack ? sprintf( __( '%s each', 'olivia-studio' ), oys_money( (int) round( $p['price_cents'] / 2 ) ) ) : '', 'features' => array_map( 'oys_product_text', array_filter( array_map( 'trim', explode( "\n", $p['features'] ) ) ) ), 'gift' => $gift_line && ! empty( $p['giftable'] ), 'cta' => $cta, 'featured' => false );
			$on    = (int) $m === (int) $lengths[0] && ! $two;
			$cards .= self::price_card( $card, ' data-len="' . (int) $m . '" data-people="' . ( $two ? 2 : 1 ) . '"' . ( $on ? ' data-on' : '' ) );
		}
		return '<section class="price-group price-group--svc-' . esc_attr( $key ) . ( $switch ? ' oys-variants' : '' ) . '"' . ( $switch ? ' data-oys-variants' : '' ) . '><header class="price-group__head"><h3>' . esc_html( $g[0] ) . '</h3>' . ( '' !== $g[1] ? '<p>' . esc_html( $g[1] ) . '</p>' : '' ) . ( $switch ? '<div class="oys-switches">' . $switch . '</div>' : '' ) . '</header>'
			. '<div class="price-group__cards" style="--n:2">' . $cards . '</div></section>';
	}

	/* ======================================================================
	   Booking / checkout page
	   ====================================================================== */

	/** Returning from Stripe: fulfil straight away if paid (the webhook may still be on its way). */
	public static function return_from_stripe() {
		if ( empty( $_GET['oys_order'] ) || empty( $_GET['oys_return'] ) ) {
			return;
		}
		$order_id = (int) $_GET['oys_order'];
		if ( ! hash_equals( OYS_Stripe::order_key( $order_id ), (string) ( $_GET['oys_key'] ?? '' ) ) ) {
			return;
		}
		$order = OYS_Orders::get( $order_id );
		if ( ! $order ) {
			return;
		}
		if ( 'success' === $_GET['oys_return'] && 'pending' === $order->status && $order->stripe_session_id ) {
			OYS_Stripe::sync_session( $order->stripe_session_id );
		}
		if ( 'cancel' === $_GET['oys_return'] && 'pending' === $order->status ) {
			// Close the Stripe page so it can't be paid later, and free the seat now.
			if ( $order->stripe_session_id ) {
				OYS_Stripe::expire_session( $order );
			}
			OYS_Orders::mark_unpaid( $order_id, 'expired' );
		}
	}

	public static function sc_book() {
		$out = oys_render_flash();
		if ( ! empty( $_GET['oys_order'] ) ) {
			return $out . self::render_return();
		}
		if ( ! empty( $_GET['session'] ) ) {
			return $out . self::render_session_checkout( (int) $_GET['session'] );
		}
		if ( ! empty( $_GET['product'] ) ) {
			return $out . self::render_product_checkout( sanitize_key( $_GET['product'] ) );
		}
		return $out . '<div class="oys-intro"><p class="lead">' . esc_html__( 'Joining a group class? Choose one from the timetable below.', 'olivia-studio' ) . '</p></div>' . self::sc_schedule( array( 'days' => 21 ) )
			. self::more_calendar()
			. ( 'no' === OYS_Settings::get( 'schedule_empty_days' ) ? self::sc_private_box() : '' );
	}

	/**
	 * Under the timetable of the booking page: „More classes in the calendar”, which opens the calendar of every bookable
	 * week right there (Olívia, 18 November: „a foglalás alá tedd be a további órák a naptárban cta-t, amire nyíljon le a
	 * naptár, alatta meg maradjon az egyéni órás szekció”).
	 */
	public static function more_calendar( array $atts = array() ) {
		$icon = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>';
		$chev = '<svg class="oys-more-cal__chev" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
		return '<details class="oys-more-cal" id="naptar"><summary class="btn btn--ghost">' . $icon . '<span>' . esc_html__( 'More classes in the calendar', 'olivia-studio' ) . '</span>' . $chev . '</summary>'
			. '<div class="oys-more-cal__body">' . self::sc_calendar( $atts ) . '</div></details>';
	}

	/**
	 * The one-to-one sessions in a box of their own, under the timetable (Olivia, 13 November: „legyen egy külön boxban
	 * az egyéni időpontfoglalás miatti kapcsolatfelvétel”). Shortcode [oys_private_box].
	 */
	public static function sc_private_box() {
		$offered = OYS_Services::offered();
		if ( ! $offered && ! OYS_Products::has_plain_private() ) {
			return '';
		}
		$items = '';
		foreach ( $offered as $k => $sv ) {
			$url    = apply_filters( 'oys_class_url', '', $sv['class'] );
			$label  = esc_html( OYS_Services::label( $k ) );
			$items .= '<li>' . ( $url ? '<a href="' . esc_url( $url ) . '">' . $label . '</a>' : $label ) . '</li>';
		}
		return '<aside class="oys-private-box" aria-labelledby="oys-private-box-title"><div><h3 id="oys-private-box-title">' . esc_html__( 'One-to-one sessions', 'olivia-studio' ) . '</h3>'
			. ( $items ? '<ul class="oys-private-box__list">' . $items . '</ul>' : '' )
			. '<p>' . esc_html__( 'We agree on a time that suits you: tell me when you are free, and I reply within a day.', 'olivia-studio' ) . '</p></div>'
			. '<a class="btn btn--dark" href="' . esc_url( oys_account_url( 'private' ) ) . '">' . esc_html__( 'Ask for a time', 'olivia-studio' ) . '</a></aside>';
	}

	private static function session_card( $s ) {
		$rows = array(
			array( 'calendar', oys_date( $s->starts_at, 'l, F j' ) ),
			array( 'clock', oys_time( $s->starts_at ) . ' – ' . oys_time( $s->ends_at ) ),
		);
		if ( oys_is_online( $s ) ) {
			$rows[] = array( 'pin', __( 'Online, live. The link is in your confirmation email and your account.', 'olivia-studio' ) );
		} elseif ( $s->location ) {
			$rows[] = array( 'pin', oys_t( $s->location ) );
		}
		if ( oys_is_hybrid( $s ) ) {
			$rows[] = array( 'screen', __( 'Also streamed live: join from home if you prefer.', 'olivia-studio' ) );
		}
		if ( 'private' !== $s->kind ) {
			$left   = OYS_Schedule::spots_left( $s );
			$rows[] = array( 'users', ( oys_is_hybrid( $s ) ? __( 'Studio:', 'olivia-studio' ) . ' ' : '' ) . ( $left < 1 ? __( 'Full', 'olivia-studio' ) : sprintf( _n( '%d spot left', '%d spots left', $left, 'olivia-studio' ), $left ) ) );
		}
		$html = '<div class="oys-card oys-summary"><p class="kicker">' . esc_html( ( OYS_Schedule::kinds()[ $s->kind ] ?? '' ) . ( oys_is_online( $s ) ? ' · ' . __( 'Online', 'olivia-studio' ) : ( oys_is_hybrid( $s ) ? ' · ' . __( 'Studio + live online', 'olivia-studio' ) : '' ) ) ) . '</p><h2>' . esc_html( oys_session_title( $s ) ) . '</h2><ul class="oys-facts">';
		foreach ( $rows as $r ) {
			$html .= '<li>' . oys_icon( $r[0] ) . '<span>' . esc_html( $r[1] ) . '</span></li>';
		}
		$html .= '</ul>';
		$teacher = OYS_Teachers::for_session( $s );
		if ( $teacher ) {
			$img   = OYS_Teachers::photo( $teacher, 'thumbnail' );
			$html .= '<div class="oys-teacher-mini">' . ( $img ? '<img src="' . esc_url( $img ) . '" alt="" width="56" height="56">' : '' ) . '<div><p class="oys-teacher-mini__name">' . esc_html( sprintf( __( 'with %s', 'olivia-studio' ), $teacher->name ) ) . '</p>'
				. ( $teacher->headline ? '<p class="oys-teacher-mini__headline">' . esc_html( $teacher->headline ) . '</p>' : '' )
				. ( $teacher->bio ? '<details class="oys-teacher-mini__bio"><summary>' . esc_html( sprintf( __( 'About %s', 'olivia-studio' ), strtok( $teacher->name, ' ' ) ) ) . '</summary>' . wpautop( esc_html( $teacher->bio ) ) . '</details>' : '' ) . '</div></div>';
		}
		if ( $s->description ) {
			$html .= '<div class="oys-desc">' . wpautop( esc_html( $s->description ) ) . '</div>';
		}
		if ( $s->note ) {
			$html .= '<p class="session__note">' . esc_html( oys_t( $s->note ) ) . '</p>';
		}
		$replay = OYS_Live::replay_text( $s );
		if ( $replay ) {
			$html .= '<p class="oys-replay-note">' . oys_icon( 'video' ) . '<span>' . esc_html( $replay ) . '</span></p>';
		}
		$min = OYS_Locations::notice( $s );
		if ( $min ) {
			$html .= '<p class="oys-min-note">' . oys_icon( 'users' ) . '<span>' . esc_html( $min ) . '</span></p>';
		}
		return $html . '</div>';
	}

	private static function auth_block( $redirect, $intro ) {
		return '<div class="oys-card oys-auth"><h2>' . esc_html__( 'Log in or create an account', 'olivia-studio' ) . '</h2><p>' . esc_html( $intro ) . '</p>' . self::auth_forms( $redirect ) . '</div>';
	}

	private static function waiver_field() {
		if ( is_user_logged_in() && OYS_Customers::has_waiver( get_current_user_id() ) ) {
			return '';
		}
		return '<details class="oys-waiver"><summary>' . esc_html__( 'Participation agreement', 'olivia-studio' ) . '</summary><p>' . esc_html( OYS_Settings::get( 'waiver_text' ) ) . '</p></details>'
			. '<label class="oys-check"><input type="checkbox" name="waiver" value="1" required> <span>' . esc_html__( 'I have read and accept the participation agreement.', 'olivia-studio' ) . '</span></label>';
	}


	/** Guest name/email rows. Visible rows = $open; the rest appear with "Add a guest". */
	private static function guest_fields( $max, $open = 0 ) {
		if ( $max < 1 ) {
			return '';
		}
		$rows = '';
		for ( $i = 0; $i < $max; $i++ ) {
			$rows .= '<div class="oys-guestrow" data-guest' . ( $i >= $open ? ' hidden' : '' ) . '><span class="oys-guestrow__n">' . sprintf( esc_html__( 'Guest %d', 'olivia-studio' ), $i + 1 ) . '</span>'
				. '<label class="field"><span>' . esc_html__( 'Name', 'olivia-studio' ) . '</span><input type="text" name="guest_name[]" id="oys-guest-name-' . $i . '" autocomplete="off"></label>'
				. '<label class="field"><span>' . esc_html__( 'Email (optional, for their invite)', 'olivia-studio' ) . '</span><input type="email" name="guest_email[]" id="oys-guest-email-' . $i . '" autocomplete="off"></label>'
				. '<button type="button" class="oys-guestrow__remove" data-guest-remove aria-label="' . esc_attr__( 'Remove guest', 'olivia-studio' ) . '">×</button></div>';
		}
		return '<fieldset class="oys-guests" data-guests data-max="' . (int) $max . '"><legend>' . esc_html__( 'Bringing friends?', 'olivia-studio' ) . '</legend>'
			. '<p class="oys-small">' . sprintf( esc_html__( 'Add up to %d guests. Each guest takes one spot and is paid the same way as your booking.', 'olivia-studio' ), (int) $max ) . '</p>'
			. $rows . '<button type="button" class="btn btn--ghost btn--sm" data-guest-add>' . esc_html__( '+ Add a guest', 'olivia-studio' ) . '</button></fieldset>';
	}

	/** Small script: show/hide guest rows and update the party size and card total on each option. */
	/**
	 * „By paying you accept the terms” under the pay buttons, when the site has terms of sale (the theme gives their
	 * address: filter oys_terms_url).
	 */
	public static function terms_note() {
		$url = (string) apply_filters( 'oys_terms_url', '' );
		return '' === $url ? '' : '<p class="oys-small oys-terms">' . wp_kses( sprintf( __( 'By paying you accept the <a href="%s" target="_blank">terms of sale</a>.', 'olivia-studio' ), esc_url( $url ) ), array( 'a' => array( 'href' => array(), 'target' => array() ) ) ) . '</p>';
	}

	private static function party_script() {
		$cur = strtoupper( (string) OYS_Settings::get( 'currency' ) );
		$fmt = 'HUF' === $cur
			? 'function money(c){return String(Math.round(c/100)).replace(/\\B(?=(\\d{3})+(?!\\d))/g,"\\u00a0")+"\\u00a0Ft";}'
			: 'function money(c){return ' . wp_json_encode( array( 'USD' => '$', 'EUR' => '€', 'GBP' => '£' )[ $cur ] ?? $cur . ' ' ) . '+(c/100).toFixed(c%100?2:0);}';
		return '<script>(function(){' . $fmt . 'document.querySelectorAll("[data-party]").forEach(function(f){var box=f.querySelector("[data-guests]");var rows=box?[].slice.call(box.querySelectorAll("[data-guest]")):[];var add=box&&box.querySelector("[data-guest-add]");var host=parseInt(f.getAttribute("data-host"),10);'
			. 'function count(){return rows.filter(function(r){return !r.hidden&&r.querySelector("input[type=text]").value.trim()!=="";}).length;}'
			. 'function amount(){var r=f.querySelector("input[name=amount_pick]:checked");if(!r)return 0;if(r.value==="other"){var o=f.querySelector("input[name=amount_other]");return Math.round(parseFloat(o.value||"0")*100)||0;}return parseInt(r.value,10);}'
			. 'function upd(){var n=count(),people=host+n;f.querySelectorAll("[data-each]").forEach(function(el){var a=el.getAttribute("data-each"),each=a==="donation"?amount():parseInt(a,10),fixed=parseInt(el.getAttribute("data-fixed")||"0",10),mult=el.getAttribute("data-guests-only")?n:people;el.textContent=money(fixed+each*mult);});'
			. 'f.querySelectorAll("[data-needs]").forEach(function(el){var need=el.getAttribute("data-guests-only")?n:people,have=parseInt(el.getAttribute("data-needs"),10),opt=el.closest(".oys-option"),inp=opt.querySelector("input");var ok=have>=need;opt.classList.toggle("is-disabled",!ok);inp.disabled=!ok;if(!ok&&inp.checked){var o=f.querySelector(".oys-option:not(.is-disabled) input");if(o)o.checked=true;}});'
			. 'var ps=f.querySelector("[data-party-size]");if(ps)ps.textContent=people;if(add)add.hidden=rows.every(function(r){return !r.hidden;});}'
			. 'if(add)add.addEventListener("click",function(){var r=rows.find(function(r){return r.hidden;});if(r){r.hidden=false;r.querySelector("input").focus();}upd();});'
			. 'rows.forEach(function(r){r.querySelector("[data-guest-remove]").addEventListener("click",function(){r.hidden=true;r.querySelectorAll("input").forEach(function(i){i.value="";});upd();});r.querySelectorAll("input").forEach(function(i){i.addEventListener("input",upd);});});'
			. 'f.querySelectorAll("[name=amount_pick],[name=amount_other]").forEach(function(i){i.addEventListener(i.type==="radio"?"change":"input",function(){if(i.name==="amount_other"){var o=f.querySelector("[name=amount_pick][value=other]");if(o)o.checked=true;}upd();});});upd();});})();</script>';
	}

	/** Donation classes: choose how much to give (suggested amounts or your own, from the minimum). */
	private static function donation_fields( $suggested ) {
		$min     = (int) OYS_Settings::get( 'donation_min_cents' );
		$amounts = oys_donation_amounts();
		$pick    = in_array( $suggested, $amounts, true ) ? $suggested : $amounts[ min( 1, count( $amounts ) - 1 ) ];
		$out     = '<fieldset class="oys-amounts"><legend>' . esc_html__( 'Pay what you like', 'olivia-studio' ) . '</legend><div class="oys-amounts__row">';
		foreach ( $amounts as $a ) {
			$out .= '<label class="oys-amount"><input type="radio" name="amount_pick" value="' . (int) $a . '"' . checked( $pick, $a, false ) . '><span>' . esc_html( oys_money( $a ) ) . '</span></label>';
		}
		$out .= '<label class="oys-amount oys-amount--other"><input type="radio" name="amount_pick" value="other"><span>' . esc_html__( 'Other', 'olivia-studio' ) . '</span></label>'
			. '<label class="oys-amount__custom"><span class="sr-only">' . esc_html__( 'Your amount', 'olivia-studio' ) . '</span>' . ( 'HUF' === strtoupper( (string) OYS_Settings::get( 'currency' ) ) ? '' : '$' ) . '<input type="number" name="amount_other" id="oys-amount-other" min="' . esc_attr( $min / 100 ) . '" step="1" inputmode="decimal" placeholder="' . esc_attr( $min / 100 ) . '"></label></div>'
			. '<p class="oys-small">' . sprintf( esc_html__( 'This class is by donation: give what feels right, from %s per person. Online by card or at the studio, whichever you prefer.', 'olivia-studio' ), esc_html( oys_money( $min ) ) ) . '</p></fieldset>';
		return $out;
	}

	/** Chosen donation per person in cents, or WP_Error below the minimum. */
	private static function donation_amount() {
		$min  = (int) OYS_Settings::get( 'donation_min_cents' );
		$pick = sanitize_text_field( wp_unslash( $_POST['amount_pick'] ?? '' ) );
		$c    = 'other' === $pick ? oys_cents_from_input( wp_unslash( $_POST['amount_other'] ?? '' ) ) : (int) $pick;
		if ( $c < max( 1, $min ) ) {
			return new WP_Error( 'oys_amount', sprintf( __( 'The minimum is %s per person.', 'olivia-studio' ), oys_money( $min ) ) );
		}
		return min( $c, 100000 );
	}

	/** "Pay at the studio" option for the booking form: [method, label, price html, note], ['note' => why not], or null. */
	private static function door_option( $user_id, $s, $mode, $price, $guests_only = false ) {
		$ok = OYS_Bookings::pay_later_allowed( $user_id, $s, $mode );
		if ( is_wp_error( $ok ) ) {
			return 'oys_pay_later_blocked' === $ok->get_error_code() ? array( 'note' => $ok->get_error_message() ) : null;
		}
		$donation = oys_is_donation( $s );
		$html     = '<span class="oys-option__price" data-each="' . ( $donation ? 'donation' : (int) $price ) . '"' . ( $guests_only ? ' data-guests-only="1"' : '' ) . '>' . esc_html( oys_money( $price ) ) . '</span>';
		return array( 'door', $donation ? __( 'Give at the studio', 'olivia-studio' ) : __( 'Pay at the studio', 'olivia-studio' ), $html, (string) OYS_Settings::get( 'pay_later_note' ) );
	}

	/** "Have a code?" for card payments; the customer's own gift code is filled in. */
	private static function coupon_field( $user_id ) {
		$mine  = $user_id ? OYS_Coupons::for_user( $user_id ) : array();
		$first = $mine[0] ?? null;
		$hint  = $first ? sprintf( __( 'Your gift: %1$s with code %2$s%3$s. It\'s filled in for you.', 'olivia-studio' ), OYS_Coupons::label( $first ), $first->code, $first->expires_at ? ' ' . sprintf( __( '(until %s)', 'olivia-studio' ), oys_date( $first->expires_at, 'M j' ) ) : '' ) : '';
		return '<details class="oys-coupon"' . ( $first ? ' open' : '' ) . '><summary>' . esc_html__( 'Have a discount code?', 'olivia-studio' ) . '</summary>'
			. '<label class="field"><span>' . esc_html__( 'Code (for card payments)', 'olivia-studio' ) . '</span><input type="text" name="coupon" id="oys-coupon" autocomplete="off" autocapitalize="characters" value="' . esc_attr( $first ? $first->code : '' ) . '"></label>'
			. ( $hint ? '<p class="oys-small">' . esc_html( $hint ) . '</p>' : '' ) . '</details>';
	}

	/** Still to pay at the studio for a booking and its guests, in cents. */
	private static function due_for( $booking ) {
		$rows = array_merge( array( $booking ), OYS_Bookings::guests_of( $booking->id, array( 'confirmed' ) ) );
		return array_sum( array_map( fn( $r ) => 'door' === $r->paid_with && '' === $r->collected_with ? (int) $r->due_cents : 0, $rows ) );
	}

	private static function render_session_checkout( $session_id ) {
		$s       = OYS_Schedule::get( $session_id );
		$user_id = get_current_user_id();
		$here    = $s ? oys_book_url( $s->id ) : '';
		if ( $s && 'private' === $s->kind && ! $user_id ) {
			// Private sessions show the customer's address: log in first, then check it's theirs.
			return self::auth_block( $here, __( 'Log in to see and confirm your private session.', 'olivia-studio' ) );
		}
		if ( ! $s || ! OYS_Privates::may_book( $user_id, $s ) ) {
			return '<p class="oys-notice oys-notice--error">' . esc_html__( 'This class could not be found. Please pick another from the timetable.', 'olivia-studio' ) . '</p>';
		}
		$out = '<div class="oys-checkout">' . self::session_card( $s ) . '<div class="oys-checkout__main">' . ( 'private' === $s->kind ? self::private_note() : '' );

		if ( ! $user_id ) {
			return $out . self::auth_block( $here, __( 'You need an account to book, so you can manage or cancel your spot, bring guests and keep track of your passes. It takes a minute.', 'olivia-studio' ) ) . '</div></div>';
		}
		$closed    = OYS_Schedule::closed_reason( $s );
		$mine      = OYS_Bookings::active_for( $user_id, $s->id );
		// Hybrid classes: in the studio or live online (?mode=online). A full studio offers online first.
		$asked     = sanitize_key( $_GET['mode'] ?? '' );
		$mode      = oys_mode_for( $s, $mine ? $mine->mode : ( $asked ?: 'studio' ) );
		if ( ! $mine && ! $asked && oys_is_hybrid( $s ) && OYS_Schedule::spots_left( $s, 'studio' ) < 1 && OYS_Schedule::spots_left( $s, 'online' ) > 0 ) {
			$mode = 'online';
		}
		$left      = OYS_Schedule::spots_left( $s, $mode );
		$held      = $mine ? array() : OYS_Bookings::unfinished_for( $user_id, $s->id );
		$left     += PHP_INT_MAX === $left ? 0 : count( $held ); // Seats held for this customer's own unfinished payment are theirs to use again.
		$kind      = OYS_Bookings::credit_kind( $s, $mode );
		$credits   = $s->credits_allowed ? OYS_Passes::available_for( $user_id, $s, $mode ) : 0;
		// Online class and no online credits yet: studio pass classes are converted (1 → online_per_credit).
		$converts  = 'online' === $kind && $credits > 0 && ! OYS_Passes::balance( $user_id, 'online' );
		$conv_note = $converts ? sprintf( __( 'Online classes cost less: one class from your pass covers %d online classes, and the rest stay on your account.', 'olivia-studio' ), OYS_Passes::online_per_credit() ) : '';
		$max_g     = 'private' === $s->kind ? 0 : (int) OYS_Settings::get( 'max_guests' );
		$ready     = OYS_Settings::payments_ready();
		$price     = OYS_Schedule::price_for( $s, $mode );
		$donation  = oys_is_donation( $s );
		if ( $donation ) {
			$price = max( $price, (int) OYS_Settings::get( 'donation_min_cents' ) ); // The suggested amount.
		}

		// Already booked: confirmation, guests, and "bring more guests".
		if ( $mine && 'pending' !== $mine->status ) {
			$guests = OYS_Bookings::guests_of( $mine->id, array( 'confirmed' ) );
			$out   .= '<div class="oys-card oys-done"><h2>' . esc_html__( 'You\'re booked', 'olivia-studio' ) . '</h2><p>' . ( 'online' === $mode ? esc_html__( 'You\'re joining live online. The link is here and in your account; it\'s also in your reminder email.', 'olivia-studio' ) : esc_html__( 'See you on the mat. You\'ll find this booking in your account.', 'olivia-studio' ) ) . '</p>';
			$join   = 'online' === $mode ? OYS_Bookings::join_link( $mine, $s ) : '';
			if ( $join ) {
				$out .= '<p><a class="btn btn--orchid oys-join" href="' . esc_url( $join ) . '" target="_blank" rel="noopener">' . esc_html__( 'Join the live class', 'olivia-studio' ) . '</a></p>';
			}
			if ( $guests ) {
				$out .= '<p><b>' . esc_html( sprintf( _n( 'Your guest: %s', 'Your guests: %s', count( $guests ), 'olivia-studio' ), implode( ', ', wp_list_pluck( $guests, 'guest_name' ) ) ) ) . '</b></p>';
			}
			$due = self::due_for( $mine );
			if ( $due ) {
				$out .= '<p class="oys-due">' . sprintf( esc_html__( 'To pay at the studio: %s.', 'olivia-studio' ), '<b>' . esc_html( oys_money( $due ) ) . '</b>' ) . ' ' . esc_html( OYS_Settings::get( 'pay_later_note' ) ) . '</p>';
			}
			$out .= '<p class="btn-row"><a class="btn btn--primary" href="' . esc_url( oys_account_url() ) . '">' . esc_html__( 'My bookings', 'olivia-studio' ) . '</a>' . self::ics_link( $mine->id ) . '</p>' . oys_fb_group_link() . '</div>';
			$room = min( $left, $max_g - count( $guests ) );
			if ( ! $closed && $room > 0 ) {
				$opts = array();
				if ( $credits > 0 ) {
					$opts[] = '<label class="oys-option"><input type="radio" name="method" value="credit" checked><span class="oys-option__label">' . esc_html__( 'From my pass', 'olivia-studio' ) . ' <small>' . sprintf( esc_html__( '(%d left)', 'olivia-studio' ), $credits ) . '</small></span><span class="oys-option__price" data-needs="' . (int) $credits . '" data-guests-only="1">' . esc_html__( '1 class each', 'olivia-studio' ) . '</span></label>';
				}
				if ( $price > 0 && $ready ) {
					$opts[] = '<label class="oys-option"><input type="radio" name="method" value="card"' . ( $credits > 0 ? '' : ' checked' ) . '><span class="oys-option__label">' . esc_html( $donation ? __( 'Give by card', 'olivia-studio' ) : __( 'Pay by card', 'olivia-studio' ) ) . '</span><span class="oys-option__price" data-each="' . ( $donation ? 'donation' : $price ) . '" data-guests-only="1">' . esc_html( oys_money( $price ) ) . '</span></label>';
				}
				$door = $price > 0 ? self::door_option( $user_id, $s, $mode, $price, true ) : null;
				if ( $door && isset( $door[0] ) ) {
					$opts[] = '<label class="oys-option"><input type="radio" name="method" value="door"' . ( $opts ? '' : ' checked' ) . '><span class="oys-option__label">' . esc_html( $door[1] ) . '<small>' . esc_html( $door[3] ) . '</small></span>' . $door[2] . '</label>';
				}
				if ( ! $price ) {
					$opts[] = '<label class="oys-option"><input type="radio" name="method" value="free" checked><span class="oys-option__label">' . esc_html__( 'Reserve spots', 'olivia-studio' ) . '</span><span class="oys-option__price">' . esc_html__( 'Free', 'olivia-studio' ) . '</span></label>';
				}
				if ( $opts ) {
					$out .= self::form_open( 'oys_checkout', 'class="oys-card oys-pay" data-party data-host="0"' ) . '<h2>' . esc_html__( 'Bring guests', 'olivia-studio' ) . '</h2>'
						. '<input type="hidden" name="session" value="' . (int) $s->id . '"><input type="hidden" name="add_guests" value="' . (int) $mine->id . '">'
						. self::guest_fields( $room, 1 )
						. ( $donation ? self::donation_fields( $price ) : '' )
						. '<fieldset class="oys-options"><legend class="sr-only">' . esc_html__( 'Payment option', 'olivia-studio' ) . '</legend>' . implode( '', $opts ) . '</fieldset>'
						. '<button class="btn btn--primary oys-submit" type="submit">' . esc_html__( 'Add guests', 'olivia-studio' ) . '</button></form>' . self::party_script();
				}
			}
			return $out . '</div></div>';
		}
		if ( $closed ) {
			return $out . '<p class="oys-notice oys-notice--error">' . esc_html( $closed ) . '</p></div></div>';
		}

		// A card payment was started but not finished: offer to continue it, or book again below.
		if ( $held ) {
			$order = OYS_Orders::get( (int) $held[0]->order_id );
			$url   = $order && 'pending' === $order->status ? (string) ( $order->meta['checkout_url'] ?? '' ) : '';
			$out  .= '<div class="oys-card oys-unfinished"><h2>' . esc_html__( 'Your payment wasn\'t finished', 'olivia-studio' ) . '</h2>'
				. '<p>' . esc_html__( 'You started paying for this class but didn\'t complete it, so you\'re not booked yet and nothing was charged.', 'olivia-studio' ) . '</p>'
				. ( $url ? '<p class="btn-row"><a class="btn btn--primary" href="' . esc_url( $url ) . '">' . esc_html__( 'Continue to payment', 'olivia-studio' ) . '</a></p>' : '' )
				. '<p class="oys-small">' . esc_html__( 'Or choose again below: the unfinished payment is cancelled automatically.', 'olivia-studio' ) . '</p></div>';
		}

		// Hybrid: choose between the studio and joining live online.
		if ( oys_is_hybrid( $s ) ) {
			$out .= '<div class="oys-modes" role="group" aria-label="' . esc_attr__( 'How would you like to join?', 'olivia-studio' ) . '">';
			foreach ( array( 'studio' => __( 'In the studio', 'olivia-studio' ), 'online' => __( 'Live online', 'olivia-studio' ) ) as $m => $label ) {
				$free  = OYS_Schedule::spots_left( $s, $m );
				$state = $free < 1 ? __( 'Full', 'olivia-studio' ) : ( PHP_INT_MAX === $free ? __( 'Open', 'olivia-studio' ) : sprintf( _n( '%d spot left', '%d spots left', $free, 'olivia-studio' ), $free ) );
				$cost  = OYS_Schedule::price_for( $s, $m );
				$out  .= '<a class="oys-mode' . ( $m === $mode ? ' is-active' : '' ) . '" href="' . esc_url( add_query_arg( 'mode', $m, $here ) ) . '"' . ( $m === $mode ? ' aria-current="true"' : '' ) . ' data-mode="' . esc_attr( $m ) . '"><b>' . esc_html( $label ) . '</b><span>' . esc_html( ( $cost ? oys_money( $cost ) : __( 'Free', 'olivia-studio' ) ) . ' · ' . $state ) . '</span></a>';
			}
			$out .= '</div>';
		}

		if ( $left < 1 && oys_is_hybrid( $s ) && 'online' === $mode ) {
			return $out . '<div class="oys-card"><h2>' . esc_html__( 'Online spots are taken', 'olivia-studio' ) . '</h2><p>' . esc_html__( 'All online spots for this class are booked.', 'olivia-studio' ) . '</p></div></div></div>';
		}
		if ( $left < 1 ) {
			$pos = OYS_Bookings::waitlist_position( $user_id, $s->id );
			$out .= '<div class="oys-card"><h2>' . esc_html( oys_is_hybrid( $s ) ? __( 'The studio is full', 'olivia-studio' ) : __( 'This class is full', 'olivia-studio' ) ) . '</h2>';
			if ( oys_is_hybrid( $s ) && OYS_Schedule::spots_left( $s, 'online' ) > 0 ) {
				$out .= '<p><a class="btn btn--orchid" href="' . esc_url( add_query_arg( 'mode', 'online', $here ) ) . '">' . esc_html__( 'Join live online instead', 'olivia-studio' ) . '</a></p>';
			}
			$auto = (int) OYS_Settings::get( 'waitlist_auto' );
			if ( $pos ) {
				$out .= '<p>' . sprintf( $auto ? esc_html__( 'You\'re number %d on the waitlist. If a spot opens and you have a pass or membership, you\'re booked in automatically and we email you. Otherwise we email you so you can book first.', 'olivia-studio' ) : esc_html__( 'You\'re number %d on the waitlist. When a spot opens, we email everyone on the waitlist straight away, and whoever books first gets it.', 'olivia-studio' ), $pos ) . '</p>'
					. self::form_open( 'oys_waitlist' ) . '<input type="hidden" name="session" value="' . (int) $s->id . '"><input type="hidden" name="do" value="leave"><button class="btn btn--ghost">' . esc_html__( 'Leave the waitlist', 'olivia-studio' ) . '</button></form>';
			} else {
				$out .= '<p>' . ( $auto ? esc_html__( 'Join the waitlist. If a spot opens and you have a pass or membership, you\'re booked in automatically. Otherwise we email you straight away.', 'olivia-studio' ) : esc_html__( 'Join the waitlist. When a spot opens, we email you straight away with a button to book, and whoever books first gets it.', 'olivia-studio' ) ) . '</p>'
					. self::form_open( 'oys_waitlist' ) . '<input type="hidden" name="session" value="' . (int) $s->id . '"><input type="hidden" name="do" value="join"><button class="btn btn--primary">' . esc_html__( 'Join the waitlist', 'olivia-studio' ) . '</button></form>';
			}
			return $out . '</div></div></div>';
		}

		// Payment options (prices update with the number of guests).
		$member  = OYS_Memberships::current_for( $user_id );
		$covered = $member && true === OYS_Memberships::covers( $member, $s, $mode );
		$options = array();
		if ( $covered ) {
			$note = (int) $member->classes_per_period ? sprintf( __( '%d left this period', 'olivia-studio' ), OYS_Memberships::remaining( $member ) ) : __( 'unlimited', 'olivia-studio' );
			$options[] = array( 'membership', sprintf( __( 'Use my membership (%s)', 'olivia-studio' ), $note ), '<span class="oys-option__price">' . esc_html__( 'Included', 'olivia-studio' ) . '</span>', __( 'Guests are paid from your pass if you have enough classes, otherwise by card.', 'olivia-studio' ) );
		}
		if ( $credits > 0 ) {
			$label     = 'online' === $kind
				? sprintf( _n( 'Use my pass (%d online class)', 'Use my pass (%d online classes)', $credits, 'olivia-studio' ), $credits )
				: sprintf( _n( 'Use my pass (%d class left)', 'Use my pass (%d classes left)', $credits, 'olivia-studio' ), $credits );
			$options[] = array( 'credit', $label, '<span class="oys-option__price" data-needs="' . (int) $credits . '">' . esc_html( 'online' === $kind ? __( '1 online class each', 'olivia-studio' ) : __( '1 class each', 'olivia-studio' ) ) . '</span>', $conv_note );
		}
		$door_note = '';
		if ( $price > 0 ) {
			$card_label = $donation ? __( 'Give by card', 'olivia-studio' ) : ( 'private' === $s->kind ? __( 'Pay for this session', 'olivia-studio' ) : ( 'online' === $mode ? __( 'Pay by card (online ticket)', 'olivia-studio' ) : __( 'Pay by card (drop-in)', 'olivia-studio' ) ) );
			$options[]  = array( 'card', $card_label, '<span class="oys-option__price" data-each="' . ( $donation ? 'donation' : $price ) . '">' . esc_html( oys_money( $price ) ) . '</span>', '' );
			$door       = self::door_option( $user_id, $s, $mode, $price );
			if ( $door && isset( $door[0] ) ) {
				$options[] = $door;
			} elseif ( $door ) {
				$door_note = $door['note'];
			}
		} elseif ( ! $credits || ! $s->credits_allowed ) {
			$options[] = array( 'free', __( 'Reserve my spot', 'olivia-studio' ), '<span class="oys-option__price">' . esc_html__( 'Free', 'olivia-studio' ) . '</span>', '' );
		}
		if ( 'private' !== $s->kind && $s->credits_allowed && $ready ) {
			foreach ( OYS_Products::purchasable() as $p ) {
				if ( $kind !== OYS_Products::credit_kind( $p ) || ( 'intro' === $p['kind'] && ! OYS_Orders::is_new_customer( $user_id ) ) ) {
					continue;
				}
				// a single-class ticket is just the card payment again (Olívia, 14 November: „Ez így ki is jöhet”)
				if ( $price > 0 && (int) $p['credits'] <= 1 && 'intro' !== $p['kind'] ) {
					continue;
				}
				$options[] = array( 'pack:' . $p['id'], sprintf( __( 'Buy %s and use it for this booking', 'olivia-studio' ), $p['name'] ), '<span class="oys-option__price" data-needs="' . (int) $p['credits'] . '">' . esc_html( oys_money( $p['price_cents'] ) ) . '</span>', '' );
			}
		}

		$out .= self::form_open( 'oys_checkout', 'class="oys-card oys-pay" data-party data-host="1"' ) . '<h2>' . esc_html__( 'How would you like to book?', 'olivia-studio' ) . '</h2>'
			. '<input type="hidden" name="session" value="' . (int) $s->id . '"><input type="hidden" name="mode" value="' . esc_attr( $mode ) . '">'
			. self::guest_fields( min( $max_g, $left - 1 ) )
			. ( $donation ? self::donation_fields( $price ) : '' )
			. '<p class="oys-party">' . esc_html__( 'People in this booking:', 'olivia-studio' ) . ' <b data-party-size>1</b></p>'
			. '<fieldset class="oys-options"><legend class="sr-only">' . esc_html__( 'Payment option', 'olivia-studio' ) . '</legend>';
		foreach ( $options as $i => $o ) {
			$needs_card = 'card' === $o[0] || str_starts_with( $o[0], 'pack:' );
			$disabled   = $needs_card && ! $ready;
			$out       .= '<label class="oys-option' . ( $disabled ? ' is-disabled' : '' ) . '"><input type="radio" name="method" value="' . esc_attr( $o[0] ) . '"' . checked( 0, $i, false ) . disabled( $disabled, true, false ) . '><span class="oys-option__label">' . esc_html( $o[1] ) . ( $o[3] ? '<small>' . esc_html( $o[3] ) . '</small>' : '' ) . '</span>' . $o[2] . '</label>';
		}
		$out .= '</fieldset>';
		if ( $door_note ) {
			$out .= '<p class="oys-small">' . esc_html( $door_note ) . '</p>';
		}
		if ( $price > 0 && $ready ) {
			$out .= self::coupon_field( $user_id );
		}
		if ( ! $ready && ! $credits && ! $covered ) {
			$out .= '<p class="oys-notice">' . esc_html__( 'Online payment is being set up. To book now, send a message and I\'ll hold your spot.', 'olivia-studio' ) . '</p>';
		}
		$out .= self::waiver_field()
			. '<p class="oys-policy">' . esc_html( OYS_Settings::cancel_policy() ) . '</p>'
			. '<button class="btn btn--primary oys-submit" type="submit">' . esc_html__( 'Continue', 'olivia-studio' ) . '</button>'
			. self::terms_note()
			. '<p class="oys-secure">' . esc_html__( 'Card payments are processed securely by Stripe. Apple Pay and Google Pay are accepted.', 'olivia-studio' ) . '</p></form>' . self::party_script();
		return $out . '</div></div>';
	}


	private static function render_product_checkout( $product_id ) {
		$p = OYS_Products::get( $product_id );
		if ( ! $p || empty( $p['active'] ) || ! in_array( $p['kind'], array( 'pack', 'intro', 'online_pack', 'private_pack', 'membership' ), true ) ) {
			return '<p class="oys-notice oys-notice--error">' . esc_html__( 'This pass is not available.', 'olivia-studio' ) . '</p>';
		}
		$is_member = 'membership' === $p['kind'];
		$here      = oys_page_url( 'book', array( 'product' => $p['id'] ) );
		$feat      = array_filter( array_map( 'trim', explode( "\n", $p['features'] ) ) );
		$card      = '<div class="oys-card oys-summary"><p class="kicker">' . esc_html( $is_member ? __( 'Membership', 'olivia-studio' ) : __( 'Pass', 'olivia-studio' ) ) . '</p><h2>' . esc_html( $p['name'] ) . '</h2>'
			. '<p class="oys-bigprice">' . esc_html( oys_money( $p['price_cents'] ) ) . ( $is_member ? '<small> ' . esc_html( OYS_Products::period_label( $p ) ) . '</small>' : '' ) . '</p>'
			. ( $p['description'] ? '<p>' . esc_html( $p['description'] ) . '</p>' : '' )
			. '<ul class="oys-facts">' . implode( '', array_map( fn( $f ) => '<li>' . oys_icon( 'check' ) . '<span>' . esc_html( $f ) . '</span></li>', $feat ) ) . '</ul></div>';
		$out = '<div class="oys-checkout">' . $card . '<div class="oys-checkout__main">';
		if ( ! is_user_logged_in() ) {
			return $out . self::auth_block( $here, $is_member ? __( 'Your membership lives in your account, where you book classes, see renewals and manage billing.', 'olivia-studio' ) : __( 'Your pass lives in your account, where you can see how many classes are left and book with one click.', 'olivia-studio' ) ) . '</div></div>';
		}
		if ( 'intro' === $p['kind'] && ! OYS_Orders::is_new_customer( get_current_user_id() ) ) {
			return $out . '<p class="oys-notice oys-notice--error">' . esc_html__( 'The intro offer is for first-time students. Have a look at the class passes instead.', 'olivia-studio' ) . '</p></div></div>';
		}
		if ( $is_member && OYS_Memberships::current_for( get_current_user_id() ) ) {
			return $out . '<p class="oys-notice">' . esc_html__( 'You already have an active membership.', 'olivia-studio' ) . ' <a class="text-link" href="' . esc_url( oys_account_url( 'membership' ) ) . '">' . esc_html__( 'Manage it in your account', 'olivia-studio' ) . '</a></p></div></div>';
		}
		if ( ! OYS_Settings::payments_ready() ) {
			return $out . '<p class="oys-notice">' . esc_html__( 'Online payment is being set up. Please send a message to buy a pass.', 'olivia-studio' ) . '</p></div></div>';
		}
		if ( $is_member ) {
			$out .= self::form_open( 'oys_join', 'class="oys-card oys-pay"' ) . '<h2>' . esc_html__( 'Join', 'olivia-studio' ) . '</h2><input type="hidden" name="product" value="' . esc_attr( $p['id'] ) . '">'
				. '<p>' . sprintf( esc_html__( 'You pay %1$s today, then %1$s %2$s until you cancel. Cancel any time in your account; you keep access until the end of the paid period.', 'olivia-studio' ), esc_html( oys_money( $p['price_cents'] ) ), esc_html( OYS_Products::period_label( $p ) ) ) . '</p>'
				. self::waiver_field()
				. '<button class="btn btn--primary oys-submit" type="submit">' . sprintf( esc_html__( 'Join for %s', 'olivia-studio' ), esc_html( oys_money( $p['price_cents'] ) ) ) . '</button>' . self::terms_note()
				. '<p class="oys-secure">' . esc_html__( 'Recurring payments are processed securely by Stripe. Update your card or cancel from your account.', 'olivia-studio' ) . '</p></form>';
			return $out . '</div></div>';
		}
		$out .= self::form_open( 'oys_buy', 'class="oys-card oys-pay"' ) . '<h2>' . esc_html__( 'Buy this pass', 'olivia-studio' ) . '</h2><input type="hidden" name="product" value="' . esc_attr( $p['id'] ) . '">'
			. '<p>' . esc_html__( 'After paying, book any class from the timetable in one click. You can use your pass for guests you bring, too.', 'olivia-studio' ) . '</p>'
			. self::coupon_field( get_current_user_id() )
			. self::waiver_field()
			. '<button class="btn btn--primary oys-submit" type="submit">' . sprintf( esc_html__( 'Pay %s', 'olivia-studio' ), esc_html( oys_money( $p['price_cents'] ) ) ) . '</button>' . self::terms_note()
			. '<p class="oys-secure">' . esc_html__( 'Card payments are processed securely by Stripe. Apple Pay and Google Pay are accepted.', 'olivia-studio' ) . '</p></form>';
		return $out . '</div></div>';
	}


	private static function render_return() {
		$order_id = (int) $_GET['oys_order'];
		if ( ! hash_equals( OYS_Stripe::order_key( $order_id ), (string) ( $_GET['oys_key'] ?? '' ) ) ) {
			return '<p class="oys-notice oys-notice--error">' . esc_html__( 'This link is not valid.', 'olivia-studio' ) . '</p>';
		}
		$order = OYS_Orders::get( $order_id );
		if ( ! $order ) {
			return '';
		}
		if ( 'cancel' === ( $_GET['oys_return'] ?? '' ) && 'paid' !== $order->status ) {
			$back = $order->session_id ? oys_book_url( $order->session_id ) : ( $order->product_id ? oys_page_url( 'book', array( 'product' => $order->product_id ) ) : oys_page_url( 'book' ) );
			return '<div class="oys-card oys-done"><h2>' . esc_html__( 'Payment cancelled', 'olivia-studio' ) . '</h2><p>' . esc_html__( 'Nothing was charged and your spot was released.', 'olivia-studio' ) . '</p><p class="btn-row"><a class="btn btn--primary" href="' . esc_url( $back ) . '">' . esc_html__( 'Try again', 'olivia-studio' ) . '</a></p></div>';
		}
		if ( 'paid' !== $order->status ) {
			return '<div class="oys-card oys-done"><h2>' . esc_html__( 'Payment processing', 'olivia-studio' ) . '</h2><p>' . esc_html__( 'Your payment is being confirmed. You\'ll get an email as soon as it goes through, and it will show in your account.', 'olivia-studio' ) . '</p><p class="btn-row"><a class="btn btn--primary" href="' . esc_url( oys_account_url() ) . '">' . esc_html__( 'My account', 'olivia-studio' ) . '</a></p></div>';
		}
		$html = '<div class="oys-card oys-done oys-done--paid">';
		if ( ! empty( $order->meta['app'] ) ) {
			// Paid from the mobile app: send them back to it.
			$html .= '<p class="btn-row"><a class="btn btn--orchid oys-back-to-app" href="' . esc_url( apply_filters( 'oys_app_return_url', 'oliviayoga://bookings' ), array( 'oliviayoga', 'https', 'http' ) ) . '">' . esc_html__( 'Back to the app', 'olivia-studio' ) . '</a></p>';
		}
		$rows = OYS_Bookings::for_order( $order->id, array( 'confirmed' ) );
		if ( $rows ) {
			$s      = OYS_Schedule::get( $rows[0]->session_id );
			$host   = $rows[0]->guest_of ? (int) $rows[0]->guest_of : (int) $rows[0]->id;
			$guests = array_filter( $rows, fn( $r ) => $r->guest_of );
			// Áron, 16 November („Nem tetszik”): a tick, the booking as a small ticket (class, when, where, guests), then the
			// buttons – not one long sentence. The date in the language of the page (Hungarian: „december 16., szerda, 18:30”).
			$mode   = oys_mode_for( $s, (string) ( $rows[0]->mode ?? 'studio' ) );
			$ticket = '<div><dt>' . esc_html__( 'Class', 'olivia-studio' ) . '</dt><dd>' . esc_html( oys_session_title( $s ) ) . '</dd></div>'
				. '<div><dt>' . esc_html__( 'When', 'olivia-studio' ) . '</dt><dd>' . esc_html( oys_date( $s->starts_at, 'l, F j \a\t g:i a' ) ) . '</dd></div>'
				. ( 'online' === $mode ? '<div><dt>' . esc_html__( 'Where', 'olivia-studio' ) . '</dt><dd>' . esc_html__( 'Live online, in your browser', 'olivia-studio' ) . '</dd></div>' : '' )
				. ( $guests ? '<div><dt>' . esc_html( 1 === count( $guests ) ? __( 'Guest', 'olivia-studio' ) : __( 'Guests', 'olivia-studio' ) ) . '</dt><dd>' . esc_html( implode( ', ', wp_list_pluck( $guests, 'guest_name' ) ) ) . '</dd></div>' : '' );
			$html  .= '<span class="oys-done__badge" aria-hidden="true">' . oys_icon( 'check' ) . '</span>'
				. '<h2>' . esc_html( count( $guests ) === count( $rows ) ? _n( 'Guest added!', 'Guests added!', count( $guests ), 'olivia-studio' ) : __( 'You\'re booked!', 'olivia-studio' ) ) . '</h2>'
				. '<dl class="oys-done__ticket">' . $ticket . '</dl>'
				. '<p class="oys-done__lead">' . esc_html__( 'A confirmation with a calendar invite is on its way to your inbox.', 'olivia-studio' ) . '</p>';
			$html .= '<p class="btn-row oys-done__actions"><a class="btn btn--primary" href="' . esc_url( oys_account_url() ) . '">' . esc_html__( 'My bookings', 'olivia-studio' ) . '</a>' . self::ics_link( $host ) . '</p>';
		} elseif ( 'gift' === $order->type ) {
			$html .= '<h2>' . esc_html__( 'Gift sent!', 'olivia-studio' ) . '</h2><p>' . sprintf( esc_html__( 'We emailed the gift card to %s and sent you a receipt.', 'olivia-studio' ), esc_html( $order->meta['recipient_email'] ?? '' ) ) . '</p>';
		} elseif ( 'membership' === $order->type ) {
			$html .= '<h2>' . esc_html__( 'Welcome, member!', 'olivia-studio' ) . '</h2><p>' . esc_html__( 'Your membership is active. Choose "Use my membership" when you book a class.', 'olivia-studio' ) . '</p><p class="btn-row"><a class="btn btn--primary" href="' . esc_url( oys_page_url( 'book' ) ) . '">' . esc_html__( 'Book a class', 'olivia-studio' ) . '</a><a class="btn btn--ghost" href="' . esc_url( oys_account_url( 'membership' ) ) . '">' . esc_html__( 'My membership', 'olivia-studio' ) . '</a></p>';
		} else {
			$html .= '<h2>' . esc_html__( 'Your pass is ready', 'olivia-studio' ) . '</h2><p>' . esc_html__( 'Book any class from the timetable in one click.', 'olivia-studio' ) . '</p><p class="btn-row"><a class="btn btn--primary" href="' . esc_url( oys_page_url( 'book' ) ) . '">' . esc_html__( 'Book a class', 'olivia-studio' ) . '</a></p>';
		}
		if ( $order->receipt_url ) {
			$html .= '<p class="oys-done__receipt"><a class="text-link" href="' . esc_url( $order->receipt_url ) . '" target="_blank" rel="noopener">' . oys_icon( 'ticket' ) . '<span>' . esc_html__( 'View receipt', 'olivia-studio' ) . '</span></a></p>';
		}
		return $html . oys_fb_group_link() . '</div>';
	}

	private static function ics_link( $booking_id ) {
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=oys_ics&booking=' . (int) $booking_id ), 'oys_ics_' . (int) $booking_id );
		return '<a class="btn btn--ghost" href="' . esc_url( $url ) . '">' . esc_html__( 'Add to calendar', 'olivia-studio' ) . '</a>';
	}

	/* ---------- Handlers ---------- */

	public static function handle_checkout_guest() {
		oys_redirect( wp_get_referer() ?: oys_page_url( 'book' ) );
	}

	private static function accept_waiver_or_back( $back ) {
		$user_id = get_current_user_id();
		if ( OYS_Customers::has_waiver( $user_id ) ) {
			return;
		}
		if ( empty( $_POST['waiver'] ) ) {
			oys_flash( __( 'Please accept the participation agreement to continue.', 'olivia-studio' ), 'error' );
			oys_redirect( $back );
		}
		OYS_Customers::record_waiver( $user_id );
	}


	public static function handle_checkout() {
		check_admin_referer( 'oys_checkout' );
		$user_id = get_current_user_id();
		$s       = OYS_Schedule::get( (int) ( $_POST['session'] ?? 0 ) );
		$back    = $s ? oys_book_url( $s->id ) : oys_page_url( 'book' );
		if ( ! $s || ! OYS_Privates::may_book( $user_id, $s ) ) {
			oys_flash( __( 'This class could not be found.', 'olivia-studio' ), 'error' );
			oys_redirect( oys_page_url( 'book' ) );
		}
		// Booking again replaces a card payment for this class that was started but not finished.
		if ( 'paid' === OYS_Bookings::abandon_unfinished( $user_id, $s->id ) ) {
			oys_flash( __( 'Your earlier payment for this class went through, so you\'re already booked.', 'olivia-studio' ) );
			oys_redirect( $back );
		}
		$method = sanitize_text_field( wp_unslash( $_POST['method'] ?? '' ) );
		$guests = 'private' === $s->kind ? array() : OYS_Bookings::clean_guests( $_POST['guest_name'] ?? array(), $_POST['guest_email'] ?? array() );
		$n      = count( $guests );
		// Hybrid classes: in the studio or live online (guests join the way their host does).
		$host_id = (int) ( $_POST['add_guests'] ?? 0 );
		$host    = $host_id ? OYS_Bookings::get( $host_id ) : null;
		$mode    = oys_mode_for( $s, $host ? $host->mode : sanitize_key( $_POST['mode'] ?? 'studio' ) );
		if ( oys_is_hybrid( $s ) && 'online' === $mode ) {
			$back = add_query_arg( 'mode', 'online', $back );
		}
		$kind   = OYS_Bookings::credit_kind( $s, $mode );
		$price  = OYS_Schedule::price_for( $s, $mode );
		$title  = oys_session_title( $s ) . ( oys_is_hybrid( $s ) && 'online' === $mode ? ' ' . __( '(live online)', 'olivia-studio' ) : '' );
		$fail   = function ( $res ) use ( $back ) {
			oys_flash( $res->get_error_message(), 'error' );
			oys_redirect( $back );
		};
		// Donation classes: the amount each person gives (card or at the studio).
		if ( oys_is_donation( $s ) && in_array( $method, array( 'card', 'door' ), true ) ) {
			$price = self::donation_amount();
			if ( is_wp_error( $price ) ) {
				$fail( $price );
			}
			$title .= ' ' . __( '(donation)', 'olivia-studio' );
		}
		// With a personal Zoom link for everyone, online guests need an email to receive theirs.
		if ( 'online' === $mode && $n && OYS_Zoom::personal_links() && array_filter( $guests, fn( $g ) => ! $g['email'] ) ) {
			$fail( new WP_Error( 'oys_guest_email', __( 'Add an email for each online guest, so they get their own link to join.', 'olivia-studio' ) ) );
		}

		// Adding guests to an existing booking.
		if ( $host_id ) {
			if ( ! $host || (int) $host->user_id !== $user_id || (int) $host->session_id !== (int) $s->id ) {
				oys_redirect( $back );
			}
			if ( ! $n ) {
				$fail( new WP_Error( 'oys_guests', __( 'Add at least one guest name.', 'olivia-studio' ) ) );
			}
			if ( 'card' === $method && $price > 0 ) {
				self::start_paid_booking( $user_id, $s, array(
					'type'         => 'dropin',
					'description'  => sprintf( _n( 'Guest ticket: %1$s, %2$s', 'Guest tickets (%3$d): %1$s, %2$s', $n, 'olivia-studio' ), $title, oys_date( $s->starts_at, 'M j, g:i a' ), $n ),
					'amount_cents' => $price * $n,
					'meta'         => array( 'guests' => wp_list_pluck( $guests, 'name' ) ),
				), array( array( sprintf( __( 'Guest ticket: %s', 'olivia-studio' ), $title ), implode( ', ', wp_list_pluck( $guests, 'name' ) ) . ' · ' . oys_date( $s->starts_at, 'l, F j · g:i a' ), $price, $n ) ), $back, $guests, false, $host_id, $mode );
			}
			$res = OYS_Bookings::book_party( $user_id, $s, array( 'method' => $method, 'guest_method' => 'door' === $method ? 'door' : ( 'free' === $method && ! $price ? 'free' : 'credit' ), 'guests' => $guests, 'host_booking' => $host_id, 'mode' => $mode, 'amount' => $price ) );
			if ( is_wp_error( $res ) ) {
				$fail( $res );
			}
			oys_flash( sprintf( _n( '%d guest added.', '%d guests added.', $n, 'olivia-studio' ), $n ) );
			oys_redirect( $back );
		}

		self::accept_waiver_or_back( $back );

		if ( 'door' === $method ) {
			$res = OYS_Bookings::book_party( $user_id, $s, array( 'method' => 'door', 'guests' => $guests, 'mode' => $mode, 'amount' => $price ) );
			if ( is_wp_error( $res ) ) {
				$fail( $res );
			}
			oys_redirect( $back );
		}

		if ( 'credit' === $method || ( 'free' === $method && ! $price ) ) {
			$res = OYS_Bookings::book_party( $user_id, $s, array( 'method' => $method, 'guests' => $guests, 'mode' => $mode ) );
			if ( is_wp_error( $res ) ) {
				$fail( $res );
			}
			oys_redirect( $back );
		}

		if ( 'membership' === $method ) {
			// The member is covered; guests use pass credits if there are enough, otherwise they are paid by card.
			$guest_credit = $n && OYS_Passes::available_for( $user_id, $s, $mode ) >= $n;
			$res          = OYS_Bookings::book_party( $user_id, $s, array( 'method' => 'membership', 'guests' => $guest_credit ? $guests : array(), 'guest_method' => 'credit', 'mode' => $mode ) );
			if ( is_wp_error( $res ) ) {
				$fail( $res );
			}
			if ( $n && ! $guest_credit ) {
				if ( $price < 1 ) {
					OYS_Bookings::book_party( $user_id, $s, array( 'method' => 'free', 'guests' => $guests, 'host_booking' => $res, 'mode' => $mode ) );
					oys_redirect( $back );
				}
				self::start_paid_booking( $user_id, $s, array(
					'type'         => 'dropin',
					'description'  => sprintf( _n( 'Guest ticket: %1$s, %2$s', 'Guest tickets (%3$d): %1$s, %2$s', $n, 'olivia-studio' ), $title, oys_date( $s->starts_at, 'M j, g:i a' ), $n ),
					'amount_cents' => $price * $n,
					'meta'         => array( 'guests' => wp_list_pluck( $guests, 'name' ) ),
				), array( array( sprintf( __( 'Guest ticket: %s', 'olivia-studio' ), $title ), implode( ', ', wp_list_pluck( $guests, 'name' ) ) . ' · ' . oys_date( $s->starts_at, 'l, F j · g:i a' ), $price, $n ) ), $back, $guests, false, $res, $mode );
			}
			oys_redirect( $back );
		}

		if ( 'card' === $method ) {
			if ( $price < 1 ) {
				oys_redirect( $back );
			}
			$type  = 'private' === $s->kind ? 'private' : 'dropin';
			$when  = oys_date( $s->starts_at, 'l, F j · g:i a' );
			$meta  = $n ? array( 'guests' => wp_list_pluck( $guests, 'name' ) ) : array();
			if ( 'private' === $s->kind ) {
				$r                  = OYS_Privates::for_session( $s->id );
				$meta['request_id'] = $r ? (int) $r->id : 0;
			}
			$lines = array( array( $title, $when, $price, 1 ) );
			if ( $n ) {
				$lines[] = array( sprintf( __( 'Guest ticket: %s', 'olivia-studio' ), $title ), implode( ', ', wp_list_pluck( $guests, 'name' ) ) . ' · ' . $when, $price, $n );
			}
			self::start_paid_booking( $user_id, $s, array(
				'type'         => $type,
				'description'  => $title . ', ' . oys_date( $s->starts_at, 'M j, g:i a' ) . ( $n ? ' ' . sprintf( _n( '(+%d guest)', '(+%d guests)', $n, 'olivia-studio' ), $n ) : '' ),
				'amount_cents' => $price * ( 1 + $n ),
				'meta'         => $meta,
			), $lines, $back, $guests, true, 0, $mode );
		}

		if ( str_starts_with( $method, 'pack:' ) ) {
			$p = OYS_Products::get( substr( $method, 5 ) );
			if ( ! $p || empty( $p['active'] ) || $kind !== OYS_Products::credit_kind( $p ) || ! in_array( $p['kind'], array( 'pack', 'intro', 'online_pack' ), true ) ) {
				oys_redirect( $back );
			}
			if ( 'intro' === $p['kind'] && ! OYS_Orders::is_new_customer( $user_id ) ) {
				$fail( new WP_Error( 'oys_intro', __( 'The intro offer is for first-time students.', 'olivia-studio' ) ) );
			}
			if ( (int) $p['credits'] < 1 + $n ) {
				$fail( new WP_Error( 'oys_pack', sprintf( __( '%1$s has %2$d classes, which isn\'t enough for %3$d people. Choose a bigger pass or pay by card.', 'olivia-studio' ), $p['name'], (int) $p['credits'], 1 + $n ) ) );
			}
			$desc = sprintf( __( 'Includes your spot in %s', 'olivia-studio' ), $title . ', ' . oys_date( $s->starts_at, 'M j, g:i a' ) ) . ( $n ? ' ' . sprintf( _n( 'and %d guest', 'and %d guests', $n, 'olivia-studio' ), $n ) : '' );
			self::start_paid_booking( $user_id, $s, array(
				'type'         => 'pack',
				'product_id'   => $p['id'],
				'description'  => $p['name'] . ' + ' . $title . ', ' . oys_date( $s->starts_at, 'M j' ) . ( $n ? ' ' . sprintf( _n( '(+%d guest)', '(+%d guests)', $n, 'olivia-studio' ), $n ) : '' ),
				'amount_cents' => (int) $p['price_cents'],
				'meta'         => $n ? array( 'guests' => wp_list_pluck( $guests, 'name' ) ) : array(),
			), array( array( $p['name'], $desc, (int) $p['price_cents'], 1 ) ), $back, $guests, true, 0, $mode );
		}
		oys_redirect( $back );
	}


	/** Hold the seats (customer and/or guests), create the order, send the customer to Stripe. */
	private static function start_paid_booking( $user_id, $s, array $order, array $lines, $back, array $guests = array(), $include_host = true, $host_booking = 0, $mode = 'studio' ) {
		$with_code = OYS_Coupons::for_checkout( wp_unslash( $_POST['coupon'] ?? '' ), $user_id, 'pack' === $order['type'] ? 'passes' : 'classes', $order, $lines );
		if ( is_wp_error( $with_code ) ) {
			oys_flash( $with_code->get_error_message(), 'error' );
			oys_redirect( $back );
		}
		[ $order, $lines ] = $with_code;
		$order_id = OYS_Orders::create( array_merge( array( 'user_id' => $user_id, 'session_id' => $s->id ), $order ) );
		$first    = OYS_Bookings::hold( $user_id, $s, $order_id, $guests, $include_host, $host_booking, $mode );
		if ( is_wp_error( $first ) ) {
			OYS_Orders::update( $order_id, array( 'status' => 'failed' ) );
			oys_flash( $first->get_error_message(), 'error' );
			oys_redirect( $back );
		}
		OYS_Orders::update( $order_id, array( 'booking_id' => $include_host ? $first : (int) $host_booking ) );
		$url = OYS_Stripe::start_checkout( $order_id, $lines[0][0], $lines[0][1], $lines );
		if ( is_wp_error( $url ) ) {
			OYS_Orders::mark_unpaid( $order_id, 'failed' );
			oys_flash( $url->get_error_message(), 'error' );
			oys_redirect( $back );
		}
		wp_redirect( $url );
		exit;
	}

	public static function handle_buy() {
		check_admin_referer( 'oys_buy' );
		$user_id = get_current_user_id();
		$p       = OYS_Products::get( sanitize_key( $_POST['product'] ?? '' ) );
		$back    = $p ? oys_page_url( 'book', array( 'product' => $p['id'] ) ) : oys_page_url( 'book' );
		if ( ! $p || empty( $p['active'] ) || ! in_array( $p['kind'], array( 'pack', 'intro', 'online_pack', 'private_pack' ), true ) ) {
			oys_redirect( $back );
		}
		if ( 'intro' === $p['kind'] && ! OYS_Orders::is_new_customer( $user_id ) ) {
			oys_flash( __( 'The intro offer is for first-time students.', 'olivia-studio' ), 'error' );
			oys_redirect( $back );
		}
		self::accept_waiver_or_back( $back );
		$with_code = OYS_Coupons::for_checkout( wp_unslash( $_POST['coupon'] ?? '' ), $user_id, 'passes', array(
			'user_id'      => $user_id,
			'type'         => 'pack',
			'product_id'   => $p['id'],
			'description'  => $p['name'],
			'amount_cents' => (int) $p['price_cents'],
		), array( array( $p['name'], $p['description'], (int) $p['price_cents'], 1 ) ) );
		if ( is_wp_error( $with_code ) ) {
			oys_flash( $with_code->get_error_message(), 'error' );
			oys_redirect( $back );
		}
		$order_id = OYS_Orders::create( $with_code[0] );
		$url = OYS_Stripe::start_checkout( $order_id, $p['name'], $p['description'], $with_code[1] );
		if ( is_wp_error( $url ) ) {
			OYS_Orders::update( $order_id, array( 'status' => 'failed' ) );
			oys_flash( $url->get_error_message(), 'error' );
			oys_redirect( $back );
		}
		wp_redirect( $url );
		exit;
	}

	public static function handle_cancel() {
		check_admin_referer( 'oys_cancel' );
		$b = OYS_Bookings::get( (int) ( $_POST['booking'] ?? 0 ) );
		if ( ! $b || (int) $b->user_id !== get_current_user_id() ) {
			oys_redirect( oys_account_url() );
		}
		$res = OYS_Bookings::cancel( $b->id );
		if ( is_wp_error( $res ) ) {
			oys_flash( $res->get_error_message(), 'error' );
		} else {
			$msg = array(
				'returned' => __( 'Cancelled. The class is back on your pass.', 'olivia-studio' ),
				'credit'   => __( 'Cancelled. You have a class credit to use for another class.', 'olivia-studio' ),
				'late'       => __( 'Cancelled. Because it was inside the cancellation window, the class counts as used.', 'olivia-studio' ),
				'membership' => __( 'Cancelled. It won\'t count towards your membership.', 'olivia-studio' ),
				'none'     => __( 'Cancelled.', 'olivia-studio' ),
			);
			oys_flash( $msg[ $res ] ?? $msg['none'] );
		}
		oys_redirect( oys_account_url() );
	}

	public static function handle_waitlist() {
		check_admin_referer( 'oys_waitlist' );
		$s = OYS_Schedule::get( (int) ( $_POST['session'] ?? 0 ) );
		if ( $s && get_current_user_id() ) {
			if ( 'leave' === ( $_POST['do'] ?? '' ) ) {
				OYS_Bookings::leave_waitlist( get_current_user_id(), $s->id );
				oys_flash( __( 'You left the waitlist.', 'olivia-studio' ) );
			} else {
				OYS_Bookings::join_waitlist( get_current_user_id(), $s->id );
				oys_flash( __( 'You\'re on the waitlist. We\'ll email you if a spot opens.', 'olivia-studio' ) );
			}
		}
		oys_redirect( wp_get_referer() ?: oys_account_url() );
	}

	public static function handle_ics() {
		$id = (int) ( $_GET['booking'] ?? 0 );
		check_admin_referer( 'oys_ics_' . $id );
		$b = OYS_Bookings::get( $id );
		if ( ! $b || ( (int) $b->user_id !== get_current_user_id() && ! current_user_can( 'oys_manage' ) ) ) {
			wp_die( esc_html__( 'Not found.', 'olivia-studio' ), 404 );
		}
		$s = OYS_Schedule::get( $b->session_id );
		nocache_headers();
		header( 'Content-Type: text/calendar; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="yoga-' . $id . '.ics"' );
		echo OYS_Emails::ics( $s, $id ); // phpcs:ignore WordPress.Security.EscapeOutput -- calendar file.
		exit;
	}

	/* ======================================================================
	   Account
	   ====================================================================== */

	public static function auth_forms( $redirect ) {
		$view  = sanitize_key( $_GET['oys_view'] ?? 'register' );
		$email = sanitize_email( wp_unslash( $_GET['oys_email'] ?? '' ) );
		$first = sanitize_text_field( wp_unslash( $_GET['oys_first'] ?? '' ) );
		$last  = sanitize_text_field( wp_unslash( $_GET['oys_last'] ?? '' ) );
		$phone = sanitize_text_field( wp_unslash( $_GET['oys_phone'] ?? '' ) );
		$area  = sanitize_text_field( wp_unslash( $_GET['oys_area'] ?? '' ) );
		$login = self::form_open( 'oys_login', 'class="oys-form" id="oys-login"' )
			. '<input type="hidden" name="redirect_to" value="' . esc_attr( $redirect ) . '">'
			. '<label class="field"><span>' . esc_html__( 'Email', 'olivia-studio' ) . '</span><input type="email" name="email" id="oys-login-email" required autocomplete="email" value="' . esc_attr( $email ) . '"></label>'
			. '<label class="field"><span>' . esc_html__( 'Password', 'olivia-studio' ) . '</span><input type="password" name="password" id="oys-login-password" required autocomplete="current-password"></label>'
			. '<button class="btn btn--primary" type="submit">' . esc_html__( 'Log in', 'olivia-studio' ) . '</button>'
			. '<p class="oys-small"><a href="' . esc_url( wp_lostpassword_url( $redirect ) ) . '">' . esc_html__( 'Forgot your password?', 'olivia-studio' ) . '</a></p></form>';
		$register = self::form_open( 'oys_register', 'class="oys-form" id="oys-register"' )
			. '<input type="hidden" name="redirect_to" value="' . esc_attr( $redirect ) . '">'
			. '<div class="oys-hp" aria-hidden="true"><label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>'
			. self::name_row( $first, $last, 'oys-reg' )
			. '<div class="form__row"><label class="field"><span>' . esc_html__( 'Email', 'olivia-studio' ) . '</span><input type="email" name="email" id="oys-reg-email" required autocomplete="email" value="' . esc_attr( $email ) . '"></label>'
			. '<label class="field"><span>' . esc_html__( 'Phone number', 'olivia-studio' ) . '</span><input type="tel" name="phone" id="oys-reg-phone" required autocomplete="tel" value="' . esc_attr( $phone ) . '"></label></div>'
			. '<label class="field"><span>' . esc_html__( 'Town or city', 'olivia-studio' ) . '</span><input type="text" name="area" id="oys-reg-area" required autocomplete="address-level2" value="' . esc_attr( $area ) . '"></label>'
			. '<label class="field"><span>' . esc_html__( 'Password (8+ characters)', 'olivia-studio' ) . '</span><input type="password" name="password" id="oys-reg-password" required minlength="8" autocomplete="new-password"></label>'
			. '<details class="oys-waiver"><summary>' . esc_html__( 'Participation agreement', 'olivia-studio' ) . '</summary><p>' . esc_html( OYS_Settings::get( 'waiver_text' ) ) . '</p></details>'
			. '<label class="oys-check"><input type="checkbox" name="waiver" value="1" required> <span>' . esc_html__( 'I have read and accept the participation agreement.', 'olivia-studio' ) . '</span></label>'
			. '<label class="oys-check"><input type="checkbox" name="marketing" value="1"> <span>' . esc_html__( 'Email me the newsletter: new classes and events (a few times a month at most).', 'olivia-studio' ) . '</span></label>'
			. oys_fb_group_link( __( 'And join our Facebook group', 'olivia-studio' ) )
			. '<button class="btn btn--primary" type="submit">' . esc_html__( 'Create account', 'olivia-studio' ) . '</button></form>';
		$is_login = 'login' === $view;
		return '<div class="oys-tabs" data-oys-tabs><div class="oys-tabs__nav" role="tablist">'
			. '<button type="button" role="tab" aria-selected="' . ( $is_login ? 'false' : 'true' ) . '" data-tab="oys-register">' . esc_html__( 'I\'m new here', 'olivia-studio' ) . '</button>'
			. '<button type="button" role="tab" aria-selected="' . ( $is_login ? 'true' : 'false' ) . '" data-tab="oys-login">' . esc_html__( 'I have an account', 'olivia-studio' ) . '</button></div>'
			. '<div class="oys-tabs__panel" data-panel="oys-register"' . ( $is_login ? ' hidden' : '' ) . '>' . $register . '</div>'
			. '<div class="oys-tabs__panel" data-panel="oys-login"' . ( $is_login ? '' : ' hidden' ) . '>' . $login . '</div></div>'
			. '<script>(function(){document.querySelectorAll("[data-oys-tabs]").forEach(function(t){t.querySelectorAll("[data-tab]").forEach(function(b){b.addEventListener("click",function(){t.querySelectorAll("[data-tab]").forEach(function(x){x.setAttribute("aria-selected",x===b?"true":"false")});t.querySelectorAll("[data-panel]").forEach(function(p){p.hidden=p.getAttribute("data-panel")!==b.getAttribute("data-tab")});});});});})();</script>';
	}


	public static function sc_account() {
		$flash = oys_render_flash();
		if ( isset( $_GET['live'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- the live page of a class (OYS_Live)
			return $flash . OYS_Live::page();
		}
		if ( ! is_user_logged_in() ) {
			return $flash . '<div class="oys-card oys-auth oys-auth--page"><p class="lead">' . esc_html__( 'Book and cancel classes, bring guests, see your passes, membership and receipts, and request private sessions.', 'olivia-studio' ) . '</p>' . self::auth_forms( oys_account_url() ) . '</div>';
		}
		$user_id = get_current_user_id();
		$user    = wp_get_current_user();
		$tabs    = array(
			'bookings'   => __( 'Bookings', 'olivia-studio' ),
			'passes'     => __( 'Passes', 'olivia-studio' ),
			'membership' => __( 'Membership', 'olivia-studio' ),
			'private'    => __( 'Private sessions', 'olivia-studio' ),
			'messages'   => __( 'Messages', 'olivia-studio' ),
			'history'    => __( 'History', 'olivia-studio' ),
			'payments'   => __( 'Payments', 'olivia-studio' ),
			'profile'    => __( 'Profile', 'olivia-studio' ),
		);
		if ( ! OYS_Products::memberships() && ! OYS_Memberships::for_user( $user_id ) ) {
			unset( $tabs['membership'] );
		}
		$tab = sanitize_key( $_GET['tab'] ?? 'bookings' );
		$tab = isset( $tabs[ $tab ] ) ? $tab : 'bookings';

		$credits = OYS_Passes::balance( $user_id, 'class' );
		$private = OYS_Passes::balance( $user_id, 'private' );
		$services = '';
		foreach ( OYS_Services::all() as $key => $s ) {
			foreach ( $s['durations'] as $m ) {
				$n = OYS_Passes::balance( $user_id, OYS_Services::credit_kind( $key, 1, $m ) ) + OYS_Passes::balance( $user_id, OYS_Services::credit_kind( $key, 2, $m ) );
				$services .= $n ? '<div class="oys-stat oys-stat--sun"><dt>' . esc_html( OYS_Services::label( $key, 1, $m ) ) . '</dt><dd>' . (int) $n . '</dd></div>' : '';
			}
		}
		$online  = OYS_Passes::balance( $user_id, 'online' );
		$member  = OYS_Memberships::current_for( $user_id );
		$next    = OYS_Bookings::for_user( $user_id, 'upcoming', array( 'confirmed' ) );
		// the greeting with „Log out” beside it (not as the last of the tabs: Áron, 16 November – „Ez így csúnya nagyon”)
		$out     = $flash . '<div class="oys-account"><header class="oys-account__head"><div class="oys-account__hello"><div class="oys-account__me"><a class="oys-avatar" href="' . esc_url( oys_account_url( 'profile' ) ) . '#oys-avatar" title="' . esc_attr__( 'Profile photo', 'olivia-studio' ) . '">' . self::avatar_html( $user_id ) . '</a><h2>' . sprintf( esc_html__( 'Hi, %s', 'olivia-studio' ), esc_html( $user->first_name ?: $user->display_name ) ) . '</h2></div><a href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '" class="oys-logout">' . esc_html__( 'Log out', 'olivia-studio' ) . '</a></div><dl class="oys-stats">';
		if ( $member ) {
			$left = (int) $member->classes_per_period ? OYS_Memberships::remaining( $member ) . ' / ' . (int) $member->classes_per_period : '∞';
			$out .= '<div class="oys-stat oys-stat--sun"><dt>' . esc_html__( 'Membership', 'olivia-studio' ) . '</dt><dd>' . esc_html( $left ) . '</dd></div>';
		}
		$out .= '<div class="oys-stat oys-stat--lilac"><dt>' . esc_html__( 'Classes on passes', 'olivia-studio' ) . '</dt><dd>' . (int) $credits . '</dd></div>'
			. ( $online ? '<div class="oys-stat oys-stat--lilac"><dt>' . esc_html__( 'Online classes', 'olivia-studio' ) . '</dt><dd>' . (int) $online . '</dd></div>' : '' )
			. ( $private ? '<div class="oys-stat oys-stat--sun"><dt>' . esc_html__( 'Private sessions', 'olivia-studio' ) . '</dt><dd>' . (int) $private . '</dd></div>' : '' )
			. $services
			. '<div class="oys-stat oys-stat--pink"><dt>' . esc_html__( 'Upcoming', 'olivia-studio' ) . '</dt><dd>' . count( $next ) . '</dd></div></dl></header>';
		$out .= '<nav class="oys-account__nav" data-tabs="' . count( $tabs ) . '" aria-label="' . esc_attr__( 'Account', 'olivia-studio' ) . '">';
		$unread = 'messages' !== $tab ? OYS_Hub::customer_unread( $user_id ) : 0;
		// Áron, 19 November: „a menü férjen bele minden kijelzőn egyben és legyen felhasználóbarát” – every tab with its
		// icon, all of them in view (tiles on a phone, one row on a wider screen), no sideways scrolling
		$icons = array( 'bookings' => 'calendar', 'passes' => 'ticket', 'membership' => 'heart', 'private' => 'users', 'messages' => 'chat', 'history' => 'history', 'payments' => 'card', 'profile' => 'user' );
		foreach ( $tabs as $k => $label ) {
			$badge = 'messages' === $k && $unread ? ' <span class="oys-badge" aria-label="' . esc_attr__( 'new', 'olivia-studio' ) . '">' . (int) $unread . '</span>' : '';
			$out  .= '<a href="' . esc_url( oys_account_url( $k ) ) . '"' . ( $k === $tab ? ' aria-current="page"' : '' ) . '><span class="oys-account__ico">' . oys_icon( $icons[ $k ] ?? 'check' ) . $badge . '</span><span class="oys-account__lbl">' . esc_html( $label ) . '</span></a>';
		}
		$out .= '</nav><div class="oys-account__body">';
		// Áron, 19 November: „az adatok kitöltése kötelező legyen” – until they are there, every tab says so
		$missing = OYS_Customers::missing( $user_id );
		if ( $missing ) {
			$out .= '<p class="oys-notice oys-notice--todo">' . esc_html( sprintf( __( 'Please fill in your details: %s.', 'olivia-studio' ), implode( ', ', $missing ) ) ) . ( 'profile' !== $tab ? ' <a class="text-link" href="' . esc_url( oys_account_url( 'profile' ) ) . '">' . esc_html__( 'Fill them in', 'olivia-studio' ) . '</a>' : '' ) . '</p>';
		}
		$out .= call_user_func( array( __CLASS__, 'tab_' . $tab ), $user_id );
		return $out . '</div>' . oys_fb_group_link() . '</div>';
	}


	private static function tab_bookings( $user_id ) {
		$items = OYS_Bookings::for_user( $user_id, 'upcoming', array( 'confirmed' ) );
		$paid  = OYS_Bookings::paid_with_labels();
		$out   = '<h3>' . esc_html__( 'Upcoming bookings', 'olivia-studio' ) . '</h3>';
		if ( ! $items ) {
			$out .= '<p class="oys-empty">' . esc_html__( 'No upcoming classes yet.', 'olivia-studio' ) . ' <a class="text-link" href="' . esc_url( oys_page_url( 'book' ) ) . '">' . esc_html__( 'See the timetable', 'olivia-studio' ) . '</a></p>';
		} else {
			$out .= '<ul class="oys-list">';
			foreach ( $items as $b ) {
				$s       = OYS_Schedule::get( $b->session_id );
				$in_time = OYS_Bookings::in_cancel_window( $b, $s );
				$msg     = $in_time ? __( 'Cancel this booking?', 'olivia-studio' ) : __( 'It\'s inside the cancellation window, so this class will count as used. Cancel anyway?', 'olivia-studio' );
				if ( $b->guests ) {
					$msg = $in_time ? __( 'Cancel your booking and your guests\' spots?', 'olivia-studio' ) : __( 'It\'s inside the cancellation window, so your and your guests\' classes count as used. Cancel anyway?', 'olivia-studio' );
				}
				$cancel = self::form_open( 'oys_cancel', 'class="oys-inline" onsubmit="return confirm(this.dataset.msg)" data-msg="' . esc_attr( $msg ) . '"' )
					. '<input type="hidden" name="booking" value="' . (int) $b->id . '"><button class="btn btn--ghost btn--sm" type="submit">' . esc_html__( 'Cancel', 'olivia-studio' ) . '</button></form>';
				$guests = '';
				if ( $b->guests ) {
					$guests = '<ul class="oys-guestlist">';
					foreach ( $b->guests as $g ) {
						$guests .= '<li><span>' . oys_icon( 'user' ) . esc_html( $g->guest_name ) . ' <small>' . esc_html( $paid[ $g->paid_with ] ?? $g->paid_with ) . '</small></span>'
							. self::form_open( 'oys_cancel', 'class="oys-inline" onsubmit="return confirm(this.dataset.msg)" data-msg="' . esc_attr( sprintf( __( 'Remove %s from this class?', 'olivia-studio' ), $g->guest_name ) ) . '"' )
							. '<input type="hidden" name="booking" value="' . (int) $g->id . '"><button class="oys-linkbtn" type="submit">' . esc_html__( 'Remove', 'olivia-studio' ) . '</button></form></li>';
					}
					$guests .= '</ul>';
				}
				$add = 'private' !== $b->kind && ! OYS_Schedule::closed_reason( $s ) && count( $b->guests ) < (int) OYS_Settings::get( 'max_guests' ) && OYS_Schedule::spots_left( $s ) > 0
					? '<a class="btn btn--ghost btn--sm" href="' . esc_url( oys_book_url( $b->session_id ) ) . '">' . esc_html__( '+ Guests', 'olivia-studio' ) . '</a>' : '';
				$out .= '<li class="oys-item"><div class="oys-item__when"><b>' . esc_html( wp_date( 'j', oys_ts( $b->starts_at ) ) ) . '</b><span>' . esc_html( wp_date( 'M', oys_ts( $b->starts_at ) ) ) . '</span></div>'
					. '<div class="oys-item__main"><h4>' . esc_html( oys_session_title( $s ) ) . ' <span class="badge">' . esc_html( $paid[ $b->paid_with ] ?? $b->paid_with ) . '</span>' . ( oys_is_hybrid( $s ) && 'online' === $b->mode ? ' <span class="badge badge--online">' . esc_html__( 'Online', 'olivia-studio' ) . '</span>' : '' ) . '</h4><p>' . esc_html( oys_date( $b->starts_at, 'l, g:i a' ) . ' – ' . oys_time( $b->ends_at ) . ( $b->location ? ' · ' . $b->location : '' ) ) . '</p>'
					. ( ( $join = OYS_Bookings::join_link( $b, $s ) ) ? '<p><a class="btn btn--orchid btn--sm oys-join" href="' . esc_url( $join ) . '" target="_blank" rel="noopener">' . esc_html__( 'Join live online', 'olivia-studio' ) . '</a></p>' : ( 'online' === $b->mode ? '<p class="oys-small">' . esc_html__( 'Joining online: the link arrives before the class.', 'olivia-studio' ) . '</p>' : '' ) )
					. $guests
					. ( ( $due = self::due_for( $b ) ) ? '<p class="oys-due">' . sprintf( esc_html__( 'To pay at the studio: %s', 'olivia-studio' ), '<b>' . esc_html( oys_money( $due ) ) . '</b>' ) . '</p>' : '' )
					. ( ! $in_time ? '<p class="oys-small">' . esc_html__( 'Inside the cancellation window', 'olivia-studio' ) . '</p>' : '' ) . '</div>'
					. '<div class="oys-item__actions">' . $add . self::ics_link( $b->id ) . $cancel . '</div></li>';
			}
			$out .= '</ul>';
		}
		$waits = OYS_Bookings::waitlists_for_user( $user_id );
		if ( $waits ) {
			$out .= '<h3>' . esc_html__( 'Waitlists', 'olivia-studio' ) . '</h3><ul class="oys-list">';
			foreach ( $waits as $w ) {
				$out .= '<li class="oys-item"><div class="oys-item__main"><h4>' . esc_html( $w->title ?: oys_class_title( $w->class_slug ) ) . '</h4><p>' . esc_html( oys_date( $w->starts_at, 'l, M j · g:i a' ) ) . ' · ' . sprintf( esc_html__( 'You\'re #%d', 'olivia-studio' ), OYS_Bookings::waitlist_position( $user_id, $w->session_id ) ) . '</p></div>'
					. '<div class="oys-item__actions">' . self::form_open( 'oys_waitlist', 'class="oys-inline"' ) . '<input type="hidden" name="session" value="' . (int) $w->session_id . '"><input type="hidden" name="do" value="leave"><button class="btn btn--ghost btn--sm">' . esc_html__( 'Leave', 'olivia-studio' ) . '</button></form></div></li>';
			}
			$out .= '</ul>';
		}
		$out .= '<p class="oys-policy">' . esc_html( OYS_Settings::cancel_policy() ) . '</p>';
		return $out;
	}

	private static function tab_membership( $user_id ) {
		$all = OYS_Memberships::for_user( $user_id );
		$st  = OYS_Memberships::statuses();
		$out = '';
		$cur = OYS_Memberships::current_for( $user_id );
		if ( $cur ) {
			$p     = OYS_Products::get( $cur->product_id );
			$used  = OYS_Memberships::used_in_period( $cur );
			$limit = (int) $cur->classes_per_period;
			$out  .= '<div class="oys-card oys-membership"><p class="kicker">' . esc_html__( 'Your membership', 'olivia-studio' ) . '</p><h3>' . esc_html( $cur->name ) . ' <span class="badge">' . esc_html( $st[ $cur->status ] ?? $cur->status ) . '</span></h3>';
			if ( 'past_due' === $cur->status ) {
				$out .= '<p class="oys-notice oys-notice--error">' . esc_html__( 'Your last payment didn\'t go through. Please update your card to keep your membership.', 'olivia-studio' ) . '</p>';
			}
			$out .= '<dl class="oys-dl"><div><dt>' . esc_html__( 'Classes this period', 'olivia-studio' ) . '</dt><dd>' . ( $limit ? sprintf( esc_html__( '%1$d of %2$d used', 'olivia-studio' ), $used, $limit ) : sprintf( esc_html__( '%d · unlimited', 'olivia-studio' ), $used ) ) . '</dd></div>'
				. '<div><dt>' . esc_html__( 'Current period', 'olivia-studio' ) . '</dt><dd>' . esc_html( oys_date( $cur->current_period_start, 'M j' ) . ' – ' . oys_date( $cur->current_period_end, 'M j, Y' ) ) . '</dd></div>'
				. '<div><dt>' . esc_html( $cur->cancel_at_period_end ? __( 'Ends on', 'olivia-studio' ) : __( 'Renews on', 'olivia-studio' ) ) . '</dt><dd>' . esc_html( oys_date( $cur->current_period_end, get_option( 'date_format' ) ) ) . ( $p && ! $cur->cancel_at_period_end ? ' · ' . esc_html( oys_money( $p['price_cents'] ) ) : '' ) . '</dd></div></dl>';
			if ( $limit ) {
				$out .= '<span class="oys-meter"><span style="width:' . (int) min( 100, round( 100 * $used / max( 1, $limit ) ) ) . '%"></span></span>';
			}
			$btn  = fn( $do, $label, $cls = 'btn--ghost', $confirm = '' ) => self::form_open( 'oys_membership', 'class="oys-inline"' . ( $confirm ? ' onsubmit="return confirm(this.dataset.msg)" data-msg="' . esc_attr( $confirm ) . '"' : '' ) ) . '<input type="hidden" name="membership" value="' . (int) $cur->id . '"><input type="hidden" name="do" value="' . esc_attr( $do ) . '"><button class="btn ' . $cls . ' btn--sm" type="submit">' . esc_html( $label ) . '</button></form>';
			$out .= '<p class="btn-row">' . $btn( 'portal', __( 'Update card & invoices', 'olivia-studio' ), 'btn--primary' )
				. ( $cur->cancel_at_period_end ? $btn( 'resume', __( 'Keep my membership', 'olivia-studio' ) ) : $btn( 'cancel', __( 'Cancel membership', 'olivia-studio' ), 'btn--ghost', sprintf( __( 'Your membership will end on %s and won\'t renew. Continue?', 'olivia-studio' ), oys_date( $cur->current_period_end, get_option( 'date_format' ) ) ) ) ) . '</p>'
				. '<p class="oys-small">' . esc_html__( 'Your membership covers you. Guests you bring are paid from your pass or by card.', 'olivia-studio' ) . '</p></div>';
		} else {
			$plans = OYS_Products::memberships();
			$out  .= '<h3>' . esc_html__( 'Become a member', 'olivia-studio' ) . '</h3>';
			if ( $plans ) {
				$out .= '<ul class="oys-buy">';
				foreach ( $plans as $p ) {
					$out .= '<li><span><b>' . esc_html( $p['name'] ) . '</b> ' . esc_html( $p['description'] ) . '</span><a class="btn btn--dark btn--sm" href="' . esc_url( oys_page_url( 'book', array( 'product' => $p['id'] ) ) ) . '">' . esc_html( oys_money( $p['price_cents'] ) . ' ' . OYS_Products::period_label( $p ) ) . '</a></li>';
				}
				$out .= '</ul>';
			} else {
				$out .= '<p class="oys-empty">' . esc_html__( 'Memberships are not available right now.', 'olivia-studio' ) . '</p>';
			}
		}
		$past = array_filter( $all, fn( $m ) => ! $cur || (int) $m->id !== (int) $cur->id );
		if ( $past ) {
			$out .= '<h3>' . esc_html__( 'Earlier memberships', 'olivia-studio' ) . '</h3><table class="oys-table"><thead><tr><th>' . esc_html__( 'Plan', 'olivia-studio' ) . '</th><th>' . esc_html__( 'Started', 'olivia-studio' ) . '</th><th>' . esc_html__( 'Ended', 'olivia-studio' ) . '</th></tr></thead><tbody>';
			foreach ( $past as $m ) {
				$out .= '<tr><td>' . esc_html( $m->name ) . '</td><td>' . esc_html( oys_date( $m->created_at, 'M j, Y' ) ) . '</td><td>' . esc_html( $m->ended_at ? oys_date( $m->ended_at, 'M j, Y' ) : ( $st[ $m->status ] ?? $m->status ) ) . '</td></tr>';
			}
			$out .= '</tbody></table>';
		}
		return $out;
	}

	private static function tab_history( $user_id ) {
		$items = OYS_Bookings::for_user( $user_id, 'past', array( 'confirmed', 'attended', 'no_show', 'late_cancelled' ) );
		$st    = OYS_Bookings::statuses();
		if ( ! $items ) {
			return '<h3>' . esc_html__( 'Class history', 'olivia-studio' ) . '</h3><p class="oys-empty">' . esc_html__( 'Your past classes will show here.', 'olivia-studio' ) . '</p>';
		}
		$out = '<h3>' . sprintf( esc_html__( 'Class history (%d)', 'olivia-studio' ), count( $items ) ) . '</h3><table class="oys-table"><thead><tr><th>' . esc_html__( 'Date', 'olivia-studio' ) . '</th><th>' . esc_html__( 'Class', 'olivia-studio' ) . '</th><th>' . esc_html__( 'Status', 'olivia-studio' ) . '</th></tr></thead><tbody>';
		foreach ( $items as $b ) {
			$label = 'confirmed' === $b->status ? __( 'Booked', 'olivia-studio' ) : ( $st[ $b->status ] ?? $b->status );
			$out  .= '<tr><td>' . esc_html( oys_date( $b->starts_at, 'M j, Y' ) ) . '</td><td>' . esc_html( $b->title ?: oys_class_title( $b->class_slug ) ) . '</td><td>' . esc_html( $label ) . '</td></tr>';
		}
		return $out . '</tbody></table>';
	}

	private static function tab_passes( $user_id ) {
		$passes = OYS_Passes::for_user( $user_id );
		$out    = '<h3>' . esc_html__( 'Passes and credits', 'olivia-studio' ) . '</h3>';
		if ( ! $passes ) {
			$out .= '<p class="oys-empty">' . esc_html__( 'No passes yet.', 'olivia-studio' ) . '</p>';
		} else {
			$out .= '<div class="oys-passes">';
			foreach ( $passes as $p ) {
				$expired = $p->expires_at && oys_ts( $p->expires_at ) < time();
				$state   = $expired ? __( 'Expired', 'olivia-studio' ) : ( $p->credits_left < 1 ? __( 'Used up', 'olivia-studio' ) : '' );
				$pct     = $p->credits_total ? round( 100 * $p->credits_left / $p->credits_total ) : 0;
				$out    .= '<article class="oys-pass' . ( $state ? ' is-done' : '' ) . ' oys-pass--' . esc_attr( $p->kind ) . '"><p class="kicker">' . esc_html( OYS_Passes::kinds()[ $p->kind ] ?? $p->kind ) . '</p>'
					. '<h4>' . esc_html( $p->name ) . '</h4><p class="oys-pass__count"><b>' . (int) $p->credits_left . '</b> / ' . (int) $p->credits_total . '</p>'
					. '<span class="oys-meter"><span style="width:' . (int) $pct . '%"></span></span>'
					. '<p class="oys-small">' . ( $state ? esc_html( $state ) : ( $p->expires_at ? sprintf( esc_html__( 'Use by %s', 'olivia-studio' ), esc_html( oys_date( $p->expires_at, get_option( 'date_format' ) ) ) ) : esc_html__( 'No expiry', 'olivia-studio' ) ) ) . '</p></article>';
			}
			$out .= '</div>';
		}
		$out .= self::rewards_html( $user_id );
		$out .= '<div class="oys-card oys-redeem"><h3>' . esc_html__( 'Redeem a gift card', 'olivia-studio' ) . '</h3>' . self::form_open( 'oys_gift_redeem', 'class="oys-form oys-form--row"' )
			. '<label class="field"><span>' . esc_html__( 'Gift code', 'olivia-studio' ) . '</span><input type="text" name="code" id="oys-gift-code" placeholder="OY-ABCD-EFGH" required autocapitalize="characters"></label>'
			. '<button class="btn btn--primary" type="submit">' . esc_html__( 'Redeem', 'olivia-studio' ) . '</button></form></div>';
		$buy = array_filter( OYS_Products::purchasable(), fn( $p ) => 'intro' !== $p['kind'] || OYS_Orders::is_new_customer( $user_id ) );
		if ( $buy ) {
			$out .= '<h3>' . esc_html__( 'Buy a pass', 'olivia-studio' ) . '</h3><ul class="oys-buy">';
			foreach ( $buy as $p ) {
				$out .= '<li><span><b>' . esc_html( $p['name'] ) . '</b> ' . esc_html( $p['description'] ) . '</span><a class="btn btn--dark btn--sm" href="' . esc_url( oys_page_url( 'book', array( 'product' => $p['id'] ) ) ) . '">' . esc_html( oys_money( $p['price_cents'] ) ) . '</a></li>';
			}
			$out .= '</ul>';
		}
		return $out;
	}

	/** Account: the loyalty draw (tickets this period) and the customer's own discount codes. */
	private static function rewards_html( $user_id ) {
		$out = '';
		foreach ( OYS_Coupons::for_user( $user_id ) as $c ) {
			$out .= '<div class="oys-card oys-gift-code"><p class="kicker">' . esc_html( 'birthday' === $c->source ? __( 'Birthday gift', 'olivia-studio' ) : __( 'Your code', 'olivia-studio' ) ) . '</p><p class="oys-gift-code__code">' . esc_html( $c->code ) . '</p><p>' . esc_html( OYS_Coupons::label( $c ) ) . ( $c->expires_at ? ' · ' . esc_html( oys_hu_suffix( sprintf( __( 'until %s', 'olivia-studio' ), oys_date( $c->expires_at, 'M j' ) ) ) ) : '' ) . ' · ' . esc_html__( 'filled in when you pay by card', 'olivia-studio' ) . '</p></div>';
		}
		$r = OYS_Rewards::status( $user_id );
		if ( $r ) {
			$out .= '<div class="oys-card oys-raffle"><p class="kicker">' . esc_html__( 'Loyalty draw', 'olivia-studio' ) . '</p>'
				. '<p class="oys-raffle__n"><b>' . (int) $r['tickets'] . '</b> ' . esc_html( _n( 'ticket', 'tickets', (int) $r['tickets'], 'olivia-studio' ) ) . '</p>'
				. '<p>' . sprintf( esc_html__( 'Every class you come to in %1$s is one ticket. On %2$s one ticket is drawn for %3$s.', 'olivia-studio' ), esc_html( $r['label'] ), esc_html( $r['draw'] ), '<b>' . esc_html( $r['prize'] ?: __( 'a free pass', 'olivia-studio' ) ) . '</b>' ) . '</p></div>';
		}
		return $out;
	}

	private static function tab_payments( $user_id ) {
		$orders = OYS_Orders::for_user( $user_id );
		if ( ! $orders ) {
			return '<h3>' . esc_html__( 'Payments', 'olivia-studio' ) . '</h3><p class="oys-empty">' . esc_html__( 'No payments yet.', 'olivia-studio' ) . '</p>';
		}
		$st  = OYS_Orders::statuses();
		$out = '<h3>' . esc_html__( 'Payments', 'olivia-studio' ) . '</h3><table class="oys-table"><thead><tr><th>' . esc_html__( 'Date', 'olivia-studio' ) . '</th><th>' . esc_html__( 'What', 'olivia-studio' ) . '</th><th>' . esc_html__( 'Amount', 'olivia-studio' ) . '</th><th>' . esc_html__( 'Receipt', 'olivia-studio' ) . '</th></tr></thead><tbody>';
		foreach ( $orders as $o ) {
			$out .= '<tr><td>' . esc_html( oys_date( $o->paid_at ?: $o->created_at, 'M j, Y' ) ) . '</td><td>' . esc_html( $o->description ) . ( 'paid' !== $o->status ? ' <span class="badge">' . esc_html( $st[ $o->status ] ?? $o->status ) . '</span>' : '' ) . '</td><td class="num">' . esc_html( oys_money( $o->amount_cents, $o->currency ) ) . '</td><td>' . ( $o->receipt_url ? '<a class="text-link" href="' . esc_url( $o->receipt_url ) . '" target="_blank" rel="noopener">' . esc_html__( 'Receipt', 'olivia-studio' ) . '</a>' : '' ) . '</td></tr>';
		}
		return $out . '</tbody></table>';
	}

	/**
	 * Messages with the studio (the Hub): Áron, 16 November – everything people write lands in one place. The studio's
	 * answers come by email too; a photo can go with a message. Studio notes (kind „note”) stay in the Hub.
	 */
	private static function tab_messages( $user_id ) {
		$threads = OYS_Hub::customer_threads( $user_id );
		if ( ! $threads ) {
			$threads = array( (object) array( 'id' => 0, 'teacher_id' => 0 ) );
		}
		$owner = (string) OYS_Settings::get( 'owner_name' ) ?: get_bloginfo( 'name' );
		$out   = '<section class="oys-msgs">';
		foreach ( $threads as $t ) {
			$with = (int) $t->teacher_id && OYS_Teachers::get( $t->teacher_id ) ? OYS_Teachers::get( $t->teacher_id )->name : $owner;
			$msgs = $t->id ? array_values( array_filter( OYS_Hub::messages( $t->id ), fn( $m ) => 'note' !== $m->kind ) ) : array();
			if ( $t->id && ! empty( $t->unread_customer ) ) {
				OYS_Hub::mark_read( $t->id, 'customer' );
			}
			$out .= '<div class="oys-msgs__thread"><h3 class="oys-msgs__with">' . esc_html( sprintf( __( 'Messages with %s', 'olivia-studio' ), $with ) ) . '</h3>';
			if ( ! $msgs ) {
				$out .= '<p class="oys-msgs__intro">' . esc_html( sprintf( __( 'Write to %s any time: a question, an injury, something before class. The answer comes here and by email.', 'olivia-studio' ), $with ) ) . '</p>';
			}
			$out .= '<ol class="oys-msgs__list">';
			foreach ( $msgs as $m ) {
				$who  = $m->from_studio ? $with : __( 'You', 'olivia-studio' );
				$body = 'request' === $m->kind ? '<b>' . esc_html( strtok( (string) $m->body, "\n" ) ) . '</b><br>' . nl2br( esc_html( trim( (string) substr( (string) $m->body, strlen( strtok( (string) $m->body, "\n" ) ) ) ) ) ) : nl2br( esc_html( (string) $m->body ) );
				$out .= '<li class="oys-msg ' . ( $m->from_studio ? 'oys-msg--them' : 'oys-msg--me' ) . ( 'request' === $m->kind ? ' oys-msg--request' : '' ) . '"><div class="oys-msg__bubble">' . $body
					. ( $m->image ? '<a href="' . esc_url( OYS_Hub::image_url( $m->image ) ) . '" target="_blank" rel="noopener"><img src="' . esc_url( OYS_Hub::image_url( $m->image ) ) . '" alt="' . esc_attr__( 'Photo', 'olivia-studio' ) . '" loading="lazy"></a>' : '' )
					. '</div><span class="oys-msg__meta">' . esc_html( $who . ' · ' . oys_date( $m->created_at, 'M j, g:i a' ) ) . '</span></li>';
			}
			$out .= '</ol><span id="oys-msg-end"></span>'
				. '<form class="oys-msgs__form" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="oys_msg">' . wp_nonce_field( 'oys_msg', '_wpnonce', true, false )
				. '<input type="hidden" name="teacher" value="' . (int) $t->teacher_id . '">'
				. '<label class="screen-reader-text" for="oys-msg-body-' . (int) $t->id . '">' . esc_html__( 'Your message', 'olivia-studio' ) . '</label>'
				. '<textarea id="oys-msg-body-' . (int) $t->id . '" name="body" rows="3" placeholder="' . esc_attr__( 'Write your message…', 'olivia-studio' ) . '"></textarea>'
				. '<div class="oys-msgs__actions"><label class="oys-msgs__photo">' . oys_icon( 'camera' ) . '<span>' . esc_html__( 'Add a photo', 'olivia-studio' ) . '</span><input type="file" name="image" accept="image/*" data-oys-photo></label>'
				. '<button class="btn btn--primary">' . esc_html__( 'Send', 'olivia-studio' ) . oys_icon( 'arrow' ) . '</button></div></form></div>';
		}
		return $out . '</section>';
	}

	private static function tab_private( $user_id ) {
		$out = '';
		$reqs = OYS_Privates::for_user( $user_id );
		$st   = OYS_Privates::statuses();
		$types = OYS_Privates::location_types();
		if ( $reqs ) {
			$out .= '<h3>' . esc_html__( 'Your requests', 'olivia-studio' ) . '</h3><ul class="oys-list">';
			foreach ( $reqs as $r ) {
				$s      = $r->session_id ? OYS_Schedule::get( $r->session_id ) : null;
				$detail = $s ? oys_date( $s->starts_at, 'l, M j · g:i a' ) . ' · ' . oys_money( $r->price_cents ) : sprintf( __( 'Requested %s', 'olivia-studio' ), oys_date( $r->created_at, get_option( 'date_format' ) ) );
				$action = '';
				if ( 'offered' === $r->status && $s && 'scheduled' === $s->status ) {
					$action = '<a class="btn btn--primary btn--sm" href="' . esc_url( oys_book_url( $s->id ) ) . '">' . esc_html__( 'Confirm and pay', 'olivia-studio' ) . '</a>';
				}
				$what  = OYS_Services::get( (string) ( $r->topic ?? '' ) ) ? esc_html( OYS_Services::label( $r->topic, (int) $r->people ) ) . ', ' . (int) $r->duration_min . ' ' . esc_html__( 'min', 'olivia-studio' ) : sprintf( esc_html__( 'Private session, %d min', 'olivia-studio' ), (int) $r->duration_min );
				$out .= '<li class="oys-item"><div class="oys-item__main"><h4>' . $what . ' <span class="badge">' . esc_html( $st[ $r->status ] ?? $r->status ) . '</span></h4>'
					. '<p>' . esc_html( ( $types[ $r->location_type ] ?? '' ) . ' · ' . $detail ) . '</p>'
					. ( ! $s && '' !== trim( (string) $r->preferred ) ? '<p class="oys-small">' . esc_html__( 'Preferred times', 'olivia-studio' ) . ': ' . esc_html( $r->preferred ) . '</p>' : '' )
					. ( $r->admin_message ? '<p class="oys-small">' . esc_html( $r->admin_message ) . '</p>' : '' ) . '</div><div class="oys-item__actions">' . $action . '</div></li>';
			}
			$out .= '</ul>';
		}
		return $out . '<h3>' . esc_html__( 'Request a private session', 'olivia-studio' ) . '</h3>' . self::private_form();
	}

	/** The studio's note about private sessions (first session takes a little longer). */
	public static function private_note() {
		$note = trim( (string) OYS_Settings::get( 'private_note' ) );
		return $note ? '<p class="oys-notice oys-private-note">' . oys_icon( 'clock' ) . '<span>' . esc_html( $note ) . '</span></p>' : '';
	}

	private static function private_form() {
		$types       = OYS_Privates::location_types();
		$online_only = (bool) OYS_Settings::get( 'online_only' );
		$opts  = '';
		foreach ( $types as $k => $v ) {
			$opts .= '<option value="' . esc_attr( $k ) . '">' . esc_html( $v ) . '</option>';
		}
		$dur = '';
		foreach ( array( 60, 75, 90 ) as $d ) {
			$price  = OYS_Products::private_price_for( $d );
			$oprice = OYS_Products::private_price_for( $d, true );
			$dur   .= '<option value="' . $d . '">' . sprintf( esc_html__( '%d minutes', 'olivia-studio' ), $d ) . ( $price ? ' · ' . esc_html( oys_money( $price ) ) : '' ) . ( $oprice && $oprice !== $price ? ' · ' . esc_html( sprintf( __( 'online %s', 'olivia-studio' ), oys_money( $oprice ) ) ) : '' ) . '</option>';
		}
		$topic   = '';
		$topics  = OYS_Privates::topics();
		$plain   = isset( $topics['yoga'] );
		$offered = OYS_Services::offered();
		if ( $offered ) {
			$want = sanitize_key( $_GET['topic'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification
			$want = isset( $topics[ $want ] ) ? $want : (string) array_key_first( $topics );
			$opt  = '';
			foreach ( $topics as $k => $v ) {
				$lens = isset( $offered[ $k ] ) ? OYS_Services::lengths( $k ) : array();
				// Olívia, 19 November, on the drop-down: „itt ez lehetne picit szebb?” – one card per class to tap instead of a
				// select; the chosen one is dark with a tick
				$opt .= '<label class="oys-topic"><input type="radio" name="topic" value="' . esc_attr( $k ) . '"' . checked( $want, $k, false ) . ' data-lengths="' . esc_attr( implode( ',', $lens ) ) . '" data-duo="' . ( ! empty( $offered[ $k ]['duo'] ) ? 1 : 0 ) . '"><span>' . esc_html( $v ) . '</span></label>';
			}
			// every length on a line of its own, then the 5-session passes (Olívia, 14 November: „frissítsd az árakat, nézd
			// át újra, pl. az egyéni jógánál nincs ott a 90 perc” – it was there, lost in one long line); two people are
			// „a pair”, for the prenatal class „with a friend”
			$info = '';
			foreach ( $offered as $k => $sv ) {
				$friend = 'prenatal' === $k;
				$rows   = array();
				$packs  = array();
				foreach ( OYS_Services::lengths( $k ) ?: array( $sv['duration'] ) as $m ) {
					$one = OYS_Services::price( $k, 1, $m );
					$two = $sv['duo'] ? OYS_Services::price( $k, 2, $m ) : 0;
					if ( $one || $two ) {
						$rows[] = esc_html( sprintf( __( '%1$d minutes: %2$s', 'olivia-studio' ), $m, $one ? oys_money( $one ) : '' ) )
							. ( $two ? esc_html( ', ' . sprintf( $friend ? __( 'with a friend %s for the two of you', 'olivia-studio' ) : __( 'as a pair %s for the two of you', 'olivia-studio' ), oys_money( $two ) ) ) : '' );
					}
					$p1 = OYS_Services::pack_price( $k, 1, $m );
					$p2 = $sv['duo'] ? OYS_Services::pack_price( $k, 2, $m ) : 0;
					if ( $p1 || $p2 ) {
						$packs[] = esc_html( sprintf( __( '%1$d minutes %2$s', 'olivia-studio' ), $m, $p1 ? oys_money( $p1 ) : '' ) )
							. ( $p2 ? esc_html( ' ' . sprintf( $friend ? __( '(with a friend %s)', 'olivia-studio' ) : __( '(as a pair %s)', 'olivia-studio' ), oys_money( $p2 ) ) ) : '' );
					}
				}
				if ( $packs ) {
					$rows[] = esc_html( __( '5-session pass:', 'olivia-studio' ) ) . ' ' . implode( ', ', $packs );
				}
				$info .= '<li data-topic="' . esc_attr( $k ) . '"><b>' . esc_html( OYS_Services::label( $k ) ) . '</b><ul>' . implode( '', array_map( fn( $r ) => '<li>' . $r . '</li>', $rows ) ) . '</ul></li>';
			}
			// under the cards only the prices of the chosen class (oys.js; all of them without JavaScript)
			$topic = '<fieldset class="oys-topics" id="oys-pr-topic"><legend>' . esc_html__( 'What would you like?', 'olivia-studio' ) . '</legend><div class="oys-topics__list">' . $opt . '</div></fieldset>'
				. '<ul class="oys-small oys-pr-services">' . $info . '</ul>';
		}
		$length = $plain ? '<label class="field"><span>' . esc_html__( 'Length', 'olivia-studio' ) . ( $offered ? ' (' . esc_html__( 'private yoga', 'olivia-studio' ) . ')' : '' ) . '</span><select name="duration_min" id="oys-pr-duration">' . $dur . '</select></label>' : '';
		// a service sold in more than one length (Olivia, 13 November: 60 or 90 minutes): choose it here
		$multi = array();
		foreach ( $offered as $k => $sv ) {
			if ( count( OYS_Services::lengths( $k ) ) > 1 ) {
				$multi = array_merge( $multi, OYS_Services::lengths( $k ) );
			}
		}
		if ( ! $plain && $multi ) {
			$multi = array_values( array_unique( $multi ) );
			sort( $multi );
			$pick  = (int) ( $_GET['length'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
			$length = '<label class="field" data-oys-length><span>' . esc_html__( 'Length', 'olivia-studio' ) . '</span><select name="duration_min" id="oys-pr-length">'
				. implode( '', array_map( fn( $m ) => '<option value="' . (int) $m . '"' . selected( $pick, $m, false ) . '>' . esc_html( sprintf( __( '%d minutes', 'olivia-studio' ), $m ) ) . '</option>', $multi ) ) . '</select></label>';
		}
		$people = $plain || array_filter( $offered, fn( $sv ) => $sv['duo'] )
			? '<label class="field" data-oys-people><span>' . esc_html__( 'How many people', 'olivia-studio' ) . '</span><input type="number" name="people" id="oys-pr-people" min="1" max="' . ( $plain ? 10 : 2 ) . '" value="' . max( 1, min( $plain ? 10 : 2, (int) ( $_GET['people'] ?? 1 ) ) ) . '"></label>' : ''; // phpcs:ignore WordPress.Security.NonceVerification
		// a pair: the partner's name and email (they get their own invite and link when the session is booked)
		$partner = $people ? '<fieldset class="oys-guests oys-partner" data-oys-partner><legend>' . esc_html__( 'Your partner', 'olivia-studio' ) . '</legend>'
			. '<p class="oys-small">' . esc_html__( 'When the session is booked, they get their own confirmation and their own link to join, like a guest at a group class.', 'olivia-studio' ) . '</p>'
			. '<div class="form__row"><label class="field"><span>' . esc_html__( 'Their name', 'olivia-studio' ) . '</span><input type="text" name="partner_name" id="oys-pr-pname" maxlength="100" autocomplete="off"></label>'
			. '<label class="field"><span>' . esc_html__( 'Their email', 'olivia-studio' ) . '</span><input type="email" name="partner_email" id="oys-pr-pemail" autocomplete="off"></label></div></fieldset>' : '';
		return self::form_open( 'oys_private_request', 'class="oys-form oys-card" data-oys-private' )
			. self::private_note() . $topic
			. ( $length || $people ? '<div class="form__row">' . $length . $people . '</div>' : '' )
			. $partner
			. ( $online_only ? '<input type="hidden" name="location_type" value="online"><input type="hidden" name="address" value="">' : '<div class="form__row"><label class="field"><span>' . esc_html__( 'Where', 'olivia-studio' ) . '</span><select name="location_type" id="oys-pr-type">' . $opts . '</select></label>'
			. '<label class="field"><span>' . esc_html__( 'Address or area', 'olivia-studio' ) . '</span><input type="text" name="address" id="oys-pr-address" placeholder="' . esc_attr__( 'e.g. McGregor Blvd, Fort Myers Beach', 'olivia-studio' ) . '"></label></div>' )
			. '<label class="field"><span>' . esc_html__( 'Days and times that suit you', 'olivia-studio' ) . '</span><textarea name="preferred" id="oys-pr-preferred" rows="3" required placeholder="' . esc_attr( $online_only ? __( 'e.g. weekday evenings after 6, or Saturday afternoon', 'olivia-studio' ) : __( 'e.g. Tuesday or Thursday mornings, or Saturday at sunrise', 'olivia-studio' ) ) . '">' . esc_textarea( self::preferred_from_calendar() ) . '</textarea></label>'
			. '<label class="field"><span>' . esc_html__( 'Anything I should know? (goals, injuries, experience)', 'olivia-studio' ) . '</span><textarea name="notes" id="oys-pr-notes" rows="4"></textarea></label>'
			. ( OYS_Settings::cancel_policy() ? '<p class="oys-policy">' . esc_html( OYS_Settings::cancel_policy() ) . '</p>' : '' ) // the rule before asking, too (Olívia, 14 November)
			. '<button class="btn btn--primary" type="submit">' . esc_html__( 'Send request', 'olivia-studio' ) . '</button>'
			. '<p class="oys-small">' . esc_html__( 'Nothing is charged now. You\'ll get a suggested time and price to confirm.', 'olivia-studio' ) . '</p></form>';
	}

	/**
	 * The day (and time) chosen in the calendar for a one-to-one session (?pday=Y-m-d&ptime=H:i), as the request's first line:
	 * „december 18., csütörtök, 18:00”. Olívia, 19 November: „a naptárba … kiválasztani napot, időpontot és úgy privát órát
	 * kérni”. '' without a day, or for a day in the past.
	 */
	public static function preferred_from_calendar() {
		// pday / ptime: „day” is WordPress's own date archive variable (?day=… on a page is a 404)
		$day  = sanitize_text_field( wp_unslash( $_GET['pday'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$time = sanitize_text_field( wp_unslash( $_GET['ptime'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$tz   = wp_timezone();
		$d    = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $day ) ? DateTimeImmutable::createFromFormat( '!Y-m-d', $day, $tz ) : false;
		if ( ! $d || $d < new DateTimeImmutable( 'today', $tz ) ) {
			return '';
		}
		$ts = $d->setTime( 12, 0 )->getTimestamp();
		return wp_date( oys_date_format( 'l, F j' ), $ts ) . ( preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $time ) ? ', ' . $time : '' );
	}

	/** First and last name, in the order of the language: „Vezetéknév, Keresztnév” in Hungarian. Both required. */
	private static function name_row( $first, $last, $id ) {
		$f = '<label class="field"><span>' . esc_html__( 'First name', 'olivia-studio' ) . '</span><input type="text" name="first_name" id="' . esc_attr( $id ) . '-first" required autocomplete="given-name" value="' . esc_attr( $first ) . '"></label>';
		$l = '<label class="field"><span>' . esc_html__( 'Last name', 'olivia-studio' ) . '</span><input type="text" name="last_name" id="' . esc_attr( $id ) . '-last" required autocomplete="family-name" value="' . esc_attr( $last ) . '"></label>';
		return '<div class="form__row">' . ( oys_is_hu() ? $l . $f : $f . $l ) . '</div>';
	}

	/** The customer's photo, or their initial in a circle. */
	public static function avatar_html( $user_id, $size = 96 ) {
		$aid = OYS_Customers::avatar_id( $user_id );
		if ( $aid ) {
			return wp_get_attachment_image( $aid, $size > 150 ? 'medium' : 'thumbnail', false, array( 'class' => 'oys-avatar__img', 'alt' => '', 'loading' => 'lazy' ) );
		}
		$u    = get_userdata( (int) $user_id );
		$name = $u ? ( $u->first_name ?: $u->display_name ) : '';
		return '<span class="oys-avatar__initial" aria-hidden="true">' . esc_html( mb_strtoupper( mb_substr( (string) $name, 0, 1 ) ) ?: '·' ) . '</span>';
	}

	/** Optional birthday (month and day), for the birthday gift. */
	private static function birthday_field( $user_id ) {
		[ $m, $d ] = array_map( 'intval', array_pad( explode( '-', OYS_Rewards::birthday( $user_id ) ), 2, 0 ) );
		$months    = '<option value="">' . esc_html__( 'Month', 'olivia-studio' ) . '</option>';
		for ( $i = 1; $i <= 12; $i++ ) {
			$months .= '<option value="' . $i . '"' . selected( $m, $i, false ) . '>' . esc_html( wp_date( 'F', gmmktime( 12, 0, 0, $i, 1, 2024 ), new DateTimeZone( 'UTC' ) ) ) . '</option>';
		}
		$days = '<option value="">' . esc_html__( 'Day', 'olivia-studio' ) . '</option>';
		for ( $i = 1; $i <= 31; $i++ ) {
			$days .= '<option value="' . $i . '"' . selected( $d, $i, false ) . '>' . $i . '</option>';
		}
		$gift = (int) OYS_Settings::get( 'birthday_on' ) ? sprintf( __( 'Optional. On your birthday you get a %d%% gift code.', 'olivia-studio' ), (int) OYS_Settings::get( 'birthday_percent' ) ) : __( 'Optional.', 'olivia-studio' );
		$gift = (string) apply_filters( 'oys_birthday_note', $gift ); // a site can say it in its own words
		return '<fieldset class="oys-birthday"><legend>' . esc_html__( 'Birthday', 'olivia-studio' ) . '</legend><div class="form__row"><label class="field"><span class="sr-only">' . esc_html__( 'Month', 'olivia-studio' ) . '</span><select name="bday_month" id="oys-p-bmonth">' . $months . '</select></label>'
			. '<label class="field"><span class="sr-only">' . esc_html__( 'Day', 'olivia-studio' ) . '</span><select name="bday_day" id="oys-p-bday">' . $days . '</select></label></div><p class="oys-small">' . esc_html( $gift ) . '</p></fieldset>';
	}

	private static function tab_profile( $user_id ) {
		$u   = get_userdata( $user_id );
		$m   = fn( $k ) => esc_attr( get_user_meta( $user_id, $k, true ) );
		$out = self::form_open( 'oys_profile', 'class="oys-form oys-card" enctype="multipart/form-data"' ) . '<h3>' . esc_html__( 'Your details', 'olivia-studio' ) . '</h3>'
			// Áron, 19 November: „lehessen profilképet feltölteni”
			. '<div class="oys-avatar-field" id="oys-avatar"><span class="oys-avatar oys-avatar--lg" data-oys-avatar-preview>' . self::avatar_html( $user_id, 160 ) . '</span><div class="oys-avatar-field__do">'
			. '<label class="btn btn--ghost oys-avatar-pick"><input type="file" name="oys_avatar" id="oys-p-avatar" accept="image/jpeg,image/png,image/webp" class="oys-avatar-input" data-oys-avatar><span>' . esc_html( OYS_Customers::avatar_id( $user_id ) ? __( 'Change photo', 'olivia-studio' ) : __( 'Upload a profile photo', 'olivia-studio' ) ) . '</span></label>'
			. ( OYS_Customers::avatar_id( $user_id ) ? '<label class="oys-check"><input type="checkbox" name="oys_avatar_remove" value="1"> <span>' . esc_html__( 'Remove photo', 'olivia-studio' ) . '</span></label>' : '' )
			. '<p class="oys-small">' . esc_html__( 'JPG, PNG or WebP, at most 5 MB. Optional; Olivia sees it next to your name.', 'olivia-studio' ) . '</p></div></div>'
			. self::name_row( $u->first_name, $u->last_name, 'oys-p' )
			. '<div class="form__row"><label class="field"><span>' . esc_html__( 'Email', 'olivia-studio' ) . '</span><input type="email" id="oys-p-email" value="' . esc_attr( $u->user_email ) . '" disabled></label>'
			. '<label class="field"><span>' . esc_html__( 'Phone number', 'olivia-studio' ) . '</span><input type="tel" name="oys_phone" id="oys-p-phone" value="' . $m( 'oys_phone' ) . '" autocomplete="tel" required></label></div>'
			. '<label class="field"><span>' . esc_html__( 'Town or city', 'olivia-studio' ) . '</span><input type="text" name="oys_area" id="oys-p-area" value="' . $m( 'oys_area' ) . '" autocomplete="address-level2" required></label>'
			. '<div class="form__row"><label class="field"><span>' . esc_html__( 'Who to tell in an emergency (optional)', 'olivia-studio' ) . '</span><input type="text" name="oys_emergency_name" id="oys-p-ename" value="' . $m( 'oys_emergency_name' ) . '"></label>'
			. '<label class="field"><span>' . esc_html__( 'Their phone number', 'olivia-studio' ) . '</span><input type="tel" name="oys_emergency_phone" id="oys-p-ephone" value="' . $m( 'oys_emergency_phone' ) . '"></label></div>'
			. '<label class="field"><span>' . esc_html__( 'Injuries, pregnancy or health notes (optional, only Olivia sees this)', 'olivia-studio' ) . '</span><textarea name="oys_health_notes" id="oys-p-health" rows="4">' . esc_textarea( get_user_meta( $user_id, 'oys_health_notes', true ) ) . '</textarea></label>'
			. self::birthday_field( $user_id )
			. '<label class="oys-check"><input type="checkbox" name="oys_marketing" value="1"' . checked( '1', get_user_meta( $user_id, 'oys_marketing', true ), false ) . '> <span>' . esc_html__( 'Email me the newsletter: new classes and events', 'olivia-studio' ) . '</span></label>'
			. oys_fb_group_link( __( 'And join our Facebook group', 'olivia-studio' ) )
			. '<label class="field"><span>' . esc_html__( 'New password (leave empty to keep the current one)', 'olivia-studio' ) . '</span><input type="password" name="new_password" id="oys-p-pass" minlength="8" autocomplete="new-password"></label>'
			. '<button class="btn btn--primary" type="submit">' . esc_html__( 'Save', 'olivia-studio' ) . '</button></form>';
		$at   = get_user_meta( $user_id, 'oys_waiver_at', true );
		$out .= '<div class="oys-card"><h3>' . esc_html__( 'Participation agreement', 'olivia-studio' ) . '</h3>';
		if ( OYS_Customers::has_waiver( $user_id ) ) {
			$out .= '<p>' . sprintf( esc_html__( 'Accepted on %s.', 'olivia-studio' ), esc_html( oys_date( $at, get_option( 'date_format' ) ) ) ) . '</p><details class="oys-waiver"><summary>' . esc_html__( 'Read it again', 'olivia-studio' ) . '</summary><p>' . esc_html( OYS_Settings::get( 'waiver_text' ) ) . '</p></details>';
		} else {
			$out .= self::form_open( 'oys_waiver' ) . '<input type="hidden" name="redirect_to" value="' . esc_attr( oys_account_url( 'profile' ) ) . '">' . self::waiver_field() . '<button class="btn btn--primary" type="submit">' . esc_html__( 'Accept', 'olivia-studio' ) . '</button></form>';
		}
		return $out . '</div>';
	}

	/* ======================================================================
	   Gift cards and private request (standalone shortcodes)
	   ====================================================================== */

	/**
	 * The gift cards by what they are for, softer and alike (Olívia, 14 November: „ezek nagyon erősek … legyen lágyabb,
	 * egységesebb és ne ömlesztve legyen hanem kategorizálva”): group yoga, then each one-to-one service.
	 */
	public static function gift_groups( array $gifts ) {
		$groups = array();
		foreach ( $gifts as $p ) {
			$service = ! empty( $p['service'] ) ? OYS_Services::get( $p['service'] ) : null;
			if ( 'online_pack' === ( $p['kind'] ?? '' ) || 'class_pack' === ( $p['kind'] ?? '' ) ) {
				$key   = 'group';
				$label = __( 'Group yoga', 'olivia-studio' );
			} elseif ( $service ) {
				$key   = $service['key'];
				$label = oys_t( $service['label'] );
			} else {
				$key   = 'other';
				$label = __( 'More gifts', 'olivia-studio' );
			}
			$groups[ $key ]['label']   = $label;
			$groups[ $key ]['items'][] = $p;
		}
		if ( isset( $groups['other'] ) ) { // the ones without a group last
			$other = $groups['other'];
			unset( $groups['other'] );
			$groups['other'] = $other;
		}
		return $groups;
	}

	private static function gift_grid( array $gifts, $choose ) {
		$tones = array( 'lilac', 'pink', 'sage', 'sun' );
		$out   = '<div class="oys-gift-groups">';
		$n     = 0;
		$first = true;
		foreach ( self::gift_groups( $gifts ) as $g ) {
			$out .= '<section class="oys-gift-group oys-gift-group--' . $tones[ $n++ % 4 ] . '"><h3 class="oys-gift-group__title">' . esc_html( $g['label'] ) . '</h3><div class="oys-gifts' . ( $choose ? '' : ' oys-gifts--preview' ) . '">';
			foreach ( $g['items'] as $p ) {
				$card = '<span class="oys-gift__card"><span class="oys-gift__name">' . esc_html( $p['name'] ) . '</span><span class="oys-gift__price">' . esc_html( oys_money( $p['price_cents'] ) ) . '</span>'
					. ( $choose ? '<span class="oys-gift__tick" aria-hidden="true">' . oys_icon( 'check' ) . '</span>' : '' ) . '</span>';
				$out .= $choose
					? '<label class="oys-gift"><input type="radio" name="product" value="' . esc_attr( $p['id'] ) . '" data-name="' . esc_attr( $p['name'] ) . '" data-price="' . esc_attr( oys_money( $p['price_cents'] ) ) . '" data-people="' . max( 1, (int) ( $p['people'] ?? 1 ) ) . '"' . checked( $first, true, false ) . '>' . $card . '</label>'
					: '<div class="oys-gift">' . $card . '</div>';
				$first = false;
			}
			$out .= '</div></section>';
		}
		return $out . '</div>';
	}

	public static function sc_gift_cards() {
		$flash = oys_render_flash();
		$gifts = array_values( OYS_Products::giftable() );
		if ( ! $gifts ) {
			return $flash;
		}
		if ( ! is_user_logged_in() ) {
			return $flash . self::gift_grid( $gifts, false )
				. self::auth_block( oys_page_url( 'gifts' ), __( 'Log in or create an account to buy a gift card. Your receipt and the gift code are kept there.', 'olivia-studio' ) );
		}
		if ( ! OYS_Settings::payments_ready() ) {
			return $flash . self::gift_grid( $gifts, false ) . '<p class="oys-notice">' . esc_html__( 'Online gift cards are coming soon. Send a message to order one now.', 'olivia-studio' ) . '</p>';
		}
		// „ha rányomok, hogy melyiket választottam, utána jelenjen meg itt, hogy lássa”: the chosen one above the form
		$chosen = '<div class="oys-gift-chosen" data-oys-gift-chosen aria-live="polite">' . oys_icon( 'gift' ) . '<span><span class="oys-gift-chosen__label">' . esc_html__( 'Your gift:', 'olivia-studio' ) . '</span> <b data-gift-name>' . esc_html( $gifts[0]['name'] ) . '</b> <span class="oys-gift-chosen__price" data-gift-price>' . esc_html( oys_money( $gifts[0]['price_cents'] ) ) . '</span></span></div>';
		return $flash . self::form_open( 'oys_gift_buy', 'class="oys-form" data-oys-gift-form' ) . '<fieldset><legend class="kicker">' . esc_html__( 'Choose a gift', 'olivia-studio' ) . '</legend>' . self::gift_grid( $gifts, true ) . '</fieldset>'
			. '<div class="oys-card">' . $chosen . '<div class="form__row"><label class="field"><span>' . esc_html__( 'Recipient\'s name', 'olivia-studio' ) . '</span><input type="text" name="recipient_name" id="oys-g-name" required></label>'
			. '<label class="field"><span>' . esc_html__( 'Recipient\'s email', 'olivia-studio' ) . '</span><input type="email" name="recipient_email" id="oys-g-email" required></label></div>'
			// a gift for two (Olívia, 14 November: „mivel lehet páros ajándékutalványt venni, ide lehessen 2 email címet írni”)
			. '<div class="oys-gift-second" data-oys-gift-second' . ( (int) ( $gifts[0]['people'] ?? 1 ) > 1 ? '' : ' hidden' ) . '><p class="oys-small">' . esc_html__( 'A gift for two: we can email it to both of them. One of them redeems the code in their account, and they book together.', 'olivia-studio' ) . '</p>'
			. '<div class="form__row"><label class="field"><span>' . esc_html__( 'The other person\'s name', 'olivia-studio' ) . '</span><input type="text" name="recipient_name2" id="oys-g-name2"></label>'
			. '<label class="field"><span>' . esc_html__( 'The other person\'s email (optional)', 'olivia-studio' ) . '</span><input type="email" name="recipient_email2" id="oys-g-email2"></label></div></div>'
			. '<label class="field"><span>' . esc_html__( 'Personal message (optional)', 'olivia-studio' ) . '</span><textarea name="message" id="oys-g-msg" rows="3"></textarea></label>'
			. '<button class="btn btn--primary" type="submit">' . esc_html__( 'Continue to payment', 'olivia-studio' ) . '</button>' . self::terms_note()
			. '<p class="oys-small">' . esc_html__( 'The gift card is emailed to the recipient right after payment. You get the receipt.', 'olivia-studio' ) . '</p></div></form>';
	}

	public static function sc_private_request() {
		$flash = oys_render_flash();
		if ( ! is_user_logged_in() ) {
			$here = get_permalink() ?: oys_account_url( 'private' );
			return $flash . self::auth_block( $here, __( 'Create a free account to request a private session. You\'ll get a suggested time and price, and confirm with one click.', 'olivia-studio' ) );
		}
		return $flash . self::private_form();
	}
}
