<?php
/**
 * Pages: coloured page head with the featured image, content, and a side column on some pages.
 */
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	$slug   = oy_page_key( get_post_field( 'post_name' ) );
	$studio = oy_is_studio_page();
	$aside  = $studio ? '' : oy_page_aside( $slug );
	$photo  = $studio && 'gifts' !== $studio ? '' : oy_post_photo( get_the_ID(), '', '(min-width: 960px) 36vw, 90vw', true );
	// after paying (?oys_order=…): no big „Foglalás” head over the confirmation – the confirmation itself is the page
	// (Áron, 16 November: „Nem tetszik” – a coloured band, then the card)
	$return = oy_online_only() && 'book' === $studio && ! empty( $_GET['oys_order'] ); // phpcs:ignore WordPress.Security.NonceVerification
	// the account, signed in: the greeting card is the head (Áron, 16 November: „Ez így csúnya nagyon … illeszkedjen mindenhez”)
	$return = $return || ( oy_online_only() && 'account' === $studio && is_user_logged_in() && empty( $_GET['live'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	// the live page of a class (waiting room, room, after class) has its own title: no „Fiókom” banner over it (Áron, 16 November)
	$return = $return || ( oy_online_only() && 'account' === $studio && ! empty( $_GET['live'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! $return ) {
		echo oy_page_head( get_the_title(), has_excerpt() ? get_the_excerpt() : '', array( array( get_the_title(), get_permalink() ) ), $slug, '', $photo ); // phpcs:ignore
	}
	?>
	<div class="container">
		<div class="layout<?php echo $aside ? ' layout--aside' : ''; ?><?php echo $studio ? ' layout--studio' : ''; ?><?php echo $return ? ' layout--return' : ''; ?>">
			<?php
			if ( 'schedule-pricing' === $slug && ! $studio ) {
				oy_main_transform_set( 'pricing' ); // the facts and the one-to-one boxes, after Olívia's own edits (oy_main_transform)
			}
			?>
			<div class="main-col entry"><?php the_content(); ?></div>
			<?php if ( $aside ) : ?><aside class="aside-sticky"><?php echo $aside; // phpcs:ignore ?></aside><?php endif; ?>
		</div>
	</div>
	<?php
endwhile;
get_footer();
