<?php
/**
 * Home page of the online edition (Olivia Jóga – Online): live online classes from home.
 * Olivia, 11.13: the hero in the style of oliviajoga.hu (the breathing lilac block, the soft pink wave, green buttons,
 * room for the accent of JÓGA), her title and specialities on the name card, five separate service boxes, no
 * „magyarul” anywhere, „Bejelentkezés és árak” instead of „Órarend és árak”.
 * The intro copy comes from the Home page's content in the editor.
 */

defined( 'ABSPATH' ) || exit;

$studio = fn( $sc ) => shortcode_exists( $sc ) ? do_shortcode( '[' . $sc . ']' ) : '';
$ways   = array(
	array( __( 'Group online flow yoga', 'olivia-yoga' ), __( 'Every Wednesday, 18:30 to 20:00, live. Beginners welcome.', 'olivia-yoga' ), oy_class_url( 'hatha-flow' ), 'group', 'lilac' ),
	array( __( 'Individual online yoga', 'olivia-yoga' ), __( 'One-to-one on video: for a sore back, for stress, or to learn yoga from the basics.', 'olivia-yoga' ), oy_class_url( 'egyeni-online-joga' ), 'home', 'pink' ),
	array( __( 'Prenatal fitness online', 'olivia-yoga' ), __( 'One-to-one or with a friend: breathing, pelvic floor, circulation, cardio, strength, spine, mobility, yoga and relaxation, combined for your trimester.', 'olivia-yoga' ), oy_class_url( oy_prenatal_slug() ), 'prenatal', 'sage' ),
	array( __( 'Stretching & mobility', 'olivia-yoga' ), __( 'One-to-one stretching and mobility work for a stiff hip, shoulder and spine, at your own pace.', 'olivia-yoga' ), oy_class_url( 'stretching' ), 'mobility', 'sun' ),
	array( __( 'Relaxation & breathing', 'olivia-yoga' ), __( 'Half an hour of breathing and guided relaxation for an overloaded nervous system, even at the end of a long day.', 'olivia-yoga' ), oy_class_url( 'relaxacio-legzes' ), 'lotus', 'lilac' ),
);
$why    = array(
	array( 'home', __( 'No courage needed for the first class', 'olivia-yoga' ), __( 'Nervous about your first yoga class? Try it at home, on your own mat. Nobody is watching, and your camera can stay off if you like.', 'olivia-yoga' ), 'lilac' ),
	array( 'clock', __( 'No travel', 'olivia-yoga' ), __( 'No traffic, no parking, no queue in the changing room. At home you can get ready in peace and set the mood: light a candle, or whatever helps you arrive.', 'olivia-yoga' ), 'pink' ),
	array( 'group', __( 'The power of the group', 'olivia-yoga' ), __( 'You are at home, but the motivation stays: the class is live, you need to be there on time, and the others are waiting for you.', 'olivia-yoga' ), 'sage' ),
	array( 'user', __( 'A real teacher, present', 'olivia-yoga' ), __( 'You are not following a video: you get live cues, you can ask questions and get feedback, and the teacher can respond to what the group needs.', 'olivia-yoga' ), 'sun' ),
);
$needs  = array(
	array( 'home', __( 'A quiet corner', 'olivia-yoga' ), __( 'Room for a mat, and a door you can close for an hour.', 'olivia-yoga' ), 'lilac' ),
	array( 'lotus', __( 'A mat, a cushion and a blanket', 'olivia-yoga' ), __( 'The cushion and blanket are for the long relaxation at the end.', 'olivia-yoga' ), 'pink' ),
	array( 'online', __( 'A phone, tablet or laptop', 'olivia-yoga' ), __( 'Any device with a camera and a browser, no app to install. A bigger screen is easier to follow.', 'olivia-yoga' ), 'sage' ),
	array( 'group', __( 'Camera on, if you like', 'olivia-yoga' ), __( 'If I can see you, I can help you with the poses. Only I see your picture.', 'olivia-yoga' ), 'sun' ),
);
$steps  = array(
	array( __( 'Choose a class', 'olivia-yoga' ), __( 'Book from the timetable with a drop-in or a class pass.', 'olivia-yoga' ) ),
	array( __( 'Get the link', 'olivia-yoga' ), __( 'Your own link comes by email and is waiting in your account. It opens in the browser.', 'olivia-yoga' ) ),
	array( __( 'Roll out your mat', 'olivia-yoga' ), __( 'Join a few minutes early so we can say hello before we start.', 'olivia-yoga' ) ),
	array( __( 'Practice together, live', 'olivia-yoga' ), __( 'I guide you in real time. Afterwards the class chat stays open, and you can watch the class again for a week.', 'olivia-yoga' ) ),
);
?>
<section class="hero oj-hero" aria-labelledby="hero-title">
	<div class="container hero__grid">
		<div class="hero__text">
			<?php echo oy_kicker( __( 'Online yoga | Olivia Kovacs', 'olivia-yoga' ) ); // phpcs:ignore ?>
			<h1 class="hero__title" id="hero-title"><span class="hero__l1"><?php echo esc_html_x( 'Online', 'online hero title, line 1', 'olivia-yoga' ); ?></span> <span class="hero__l2"><mark class="oj-breath"><?php echo esc_html_x( 'yoga', 'online hero title, line 2', 'olivia-yoga' ); ?></mark></span> <span class="hero__l3"><?php echo esc_html_x( 'live, from home', 'online hero title, line 3', 'olivia-yoga' ); ?></span></h1>
			<p class="hero__lead"><?php esc_html_e( 'Live group online yoga every Wednesday, and individual online yoga, prenatal fitness, stretching, relaxation and breathing tailored to you, from your living room. Beginners very welcome.', 'olivia-yoga' ); ?></p>
			<p class="btn-row oj-twins"><?php echo oy_btn( oy_book_url(), __( 'Book a class', 'olivia-yoga' ), 'forest', 'btn--lg' ) . oy_btn( oy_page_link( 'schedule-pricing' ), oy_schedule_label(), 'forest', 'btn--lg' ); // phpcs:ignore ?></p>
		</div>
		<div class="hero__visual">
			<?php echo oy_soft_blob( 'pink', 'right' ); // phpcs:ignore ?>
			<div class="frame hero__photo"><?php echo oy_photo( 'online-yoga-living-room', '(min-width: 960px) 52vw, 92vw', true ); // phpcs:ignore ?></div>
			<?php echo oy_name_card( 'hero__card' ); // phpcs:ignore ?>
		</div>
	</div>
</section>

<section class="section section--tight" aria-label="<?php esc_attr_e( 'Ways to practice', 'olivia-yoga' ); ?>"><div class="container"><div class="ways ways--five" data-reveal>
	<?php foreach ( $ways as $w ) : ?>
		<a class="way way--<?php echo esc_attr( $w[4] ); ?>" href="<?php echo esc_url( $w[2] ); ?>"><?php echo oy_icon( $w[3], 'way__icon' ); // phpcs:ignore ?><h3><?php echo esc_html( $w[0] ); ?></h3><p><?php echo esc_html( $w[1] ); ?></p><span class="way__go" aria-hidden="true"><?php echo oy_icon( 'arrow' ); // phpcs:ignore ?></span></a>
	<?php endforeach; ?>
</div></div></section>

<section class="section section--pale" id="why-online" aria-labelledby="why-title"><div class="container">
	<?php echo oy_section_head( __( 'Why practise online?', 'olivia-yoga' ), __( 'Four reasons people choose live online yoga, and stay.', 'olivia-yoga' ), __( 'Why online', 'olivia-yoga' ), 'why-title' ); // phpcs:ignore ?>
	<ul class="places places--why" data-reveal><?php foreach ( $why as $n ) : ?><li><?php echo oy_pictogram( $n[0], $n[3] ); // phpcs:ignore ?><div><h3><?php echo esc_html( $n[1] ); ?></h3><p><?php echo esc_html( $n[2] ); ?></p></div></li><?php endforeach; ?></ul>
</div></section>

<section class="section" id="intro" aria-labelledby="intro-title"><div class="container">
	<div class="intro__grid">
		<div class="intro__visual" data-reveal><div class="oj-waved"><?php echo oy_brush_blob( 'lilac', 'left' ); // phpcs:ignore ?><div class="frame"><?php echo oy_photo( 'olivia-golden-hour-arms', '(min-width: 960px) 36vw, 92vw' ); // phpcs:ignore ?></div></div></div>
		<div class="prose" data-reveal>
			<?php
			while ( have_posts() ) {
				the_post();
				echo preg_replace( '/<h2>/', '<h2 id="intro-title">', apply_filters( 'the_content', get_the_content() ), 1 ); // phpcs:ignore
			}
			?>
			<p class="btn-row oj-inline"><?php echo oy_btn( oy_page_link( 'about' ), __( 'Meet Olivia', 'olivia-yoga' ), 'ghost' ); // phpcs:ignore ?><a class="text-link" href="<?php echo esc_url( oy_page_link( 'yoga-classes' ) ); ?>"><?php esc_html_e( 'See all classes', 'olivia-yoga' ); ?></a></p>
		</div>
	</div>
</div></section>

<section class="section section--pale section--tight oj-contrast" aria-label="<?php esc_attr_e( 'Awareness and control', 'olivia-yoga' ); ?>"><div class="container">
	<figure class="contrast" data-reveal>
		<div><p class="contrast__word"><?php esc_html_e( 'Awareness', 'olivia-yoga' ); ?></p><p>= <?php esc_html_e( 'I notice, I see, I observe, I allow, then I respond', 'olivia-yoga' ); ?></p></div>
		<div class="contrast__col--muted"><p class="contrast__word"><?php esc_html_e( 'Control', 'olivia-yoga' ); ?></p><p>= <?php esc_html_e( 'I want to steer it, I grip it, I regulate it, I push it down', 'olivia-yoga' ); ?></p></div>
		<figcaption><?php esc_html_e( 'To me, this is the most important difference yoga has taught me so far.', 'olivia-yoga' ); ?></figcaption>
	</figure>
</div></section>

<section class="section section--tight" id="classes" aria-labelledby="classes-title"><div class="container">
	<?php echo oy_section_head( __( 'Online classes', 'olivia-yoga' ), __( 'Breathwork, strength, stretching, balance, a real flow state and a long relaxation, live. Join the group on Wednesdays, or ask for a one-to-one session.', 'olivia-yoga' ), __( 'Classes', 'olivia-yoga' ), 'classes-title' ); // phpcs:ignore ?>
	<?php echo oy_classes_list(); // phpcs:ignore ?>
</div></section>

<section class="section section--pale" id="how" aria-labelledby="how-title"><div class="container private__grid">
	<div data-reveal>
		<?php echo oy_kicker( __( 'How online classes work', 'olivia-yoga' ) ); // phpcs:ignore ?>
		<h2 id="how-title"><?php esc_html_e( 'A real class, just in your living room', 'olivia-yoga' ); ?></h2>
		<p class="lead"><?php esc_html_e( 'This is not a video to follow. We practice together, at the same time: I watch, guide and adjust, and you can ask anything before and after class.', 'olivia-yoga' ); ?></p>
		<ul class="places"><?php foreach ( $needs as $n ) : ?><li><?php echo oy_pictogram( $n[0], $n[3] ); // phpcs:ignore ?><div><h3><?php echo esc_html( $n[1] ); ?></h3><p><?php echo esc_html( $n[2] ); ?></p></div></li><?php endforeach; ?></ul>
	</div>
	<div class="private__side" data-reveal>
		<div class="frame"><?php echo oy_photo( 'olivia-dancer-home', '(min-width: 960px) 34vw, 92vw' ); // phpcs:ignore ?></div>
		<ol class="steps"><?php foreach ( $steps as $s ) : ?><li><div><b><?php echo esc_html( $s[0] ); ?></b><span><?php echo esc_html( $s[1] ); ?></span></div></li><?php endforeach; ?></ol>
		<p class="btn-row"><?php echo oy_btn( oy_book_url(), __( 'Book a class', 'olivia-yoga' ), 'orchid' ) . oy_btn( oy_page_link( 'faq' ), __( 'Questions about online classes', 'olivia-yoga' ), 'ghost' ); // phpcs:ignore ?></p>
	</div>
</div></section>

<section class="section section--tight" id="schedule" aria-labelledby="schedule-title"><div class="container">
	<header class="section__head section__head--row" data-reveal><div><?php echo oy_kicker( __( 'This week', 'olivia-yoga' ) ); // phpcs:ignore ?><h2 id="schedule-title"><?php esc_html_e( 'Weekly live classes', 'olivia-yoga' ); ?></h2><p class="lead"><?php esc_html_e( 'Times are in Hungarian time. Book in a minute; beginners are welcome in every class.', 'olivia-yoga' ); ?></p></div><?php echo oy_btn( oy_page_link( 'schedule-pricing' ), oy_schedule_label(), 'ghost' ); // phpcs:ignore ?></header>
	<?php echo shortcode_exists( 'oys_schedule' ) ? do_shortcode( '[oys_schedule days="7"]' ) : ''; // phpcs:ignore ?>
</div></section>

<section class="section section--moss hatha" aria-labelledby="hatha-title"><div class="container hatha__grid">
	<div data-reveal><div class="hatha__pair"><div class="hatha__orb hatha__orb--sun"><span>Ha</span></div><div class="hatha__orb hatha__orb--moon"><span>Tha</span></div></div><div class="hatha__caption"><span><?php esc_html_e( 'sun: effort, heat, strength', 'olivia-yoga' ); ?></span><span><?php esc_html_e( 'moon: ease, cool, surrender', 'olivia-yoga' ); ?></span></div></div>
	<div data-reveal>
		<?php echo oy_kicker( __( 'What hatha means', 'olivia-yoga' ) ); // phpcs:ignore ?>
		<h2 id="hatha-title"><?php esc_html_e( 'Ha is the sun. Tha is the moon.', 'olivia-yoga' ); ?></h2>
		<p class="lead"><?php esc_html_e( 'Hatha yoga balances the active and the receptive in us: effort and ease, strength and surrender. When that balance tips, we feel it first as tension or restlessness.', 'olivia-yoga' ); ?></p>
		<p><?php esc_html_e( 'On the mat we use the body to find the balance again. The poses are a doorway to meditation, a more dynamic doorway, and only one of the eight limbs of yoga.', 'olivia-yoga' ); ?></p>
		<p class="btn-row"><?php echo oy_btn( oy_page_link( 'faq' ), __( 'Read more about hatha yoga', 'olivia-yoga' ), 'line-light' ); // phpcs:ignore ?></p>
	</div>
</div></section>

<section class="section section--forest section--breath" aria-label="<?php esc_attr_e( 'Breathing exercise', 'olivia-yoga' ); ?>"><div class="container"><?php echo oy_breath(); // phpcs:ignore ?></div></section>

<section class="section section--tight" id="pricing" aria-labelledby="pricing-title"><div class="container">
	<?php echo oy_section_head( __( 'Simple pricing', 'olivia-yoga' ), __( 'Pay per class, save with a 5-class pass, or give someone a gift card.', 'olivia-yoga' ), __( 'Prices in forints', 'olivia-yoga' ), 'pricing-title' ); // phpcs:ignore ?>
	<?php echo $studio( 'oys_pricing' ); // phpcs:ignore ?>
</div></section>

<section class="section" id="faq" aria-labelledby="faq-title"><div class="container faq-grid">
	<header class="section__head" data-reveal><?php echo oy_kicker( __( 'FAQ', 'olivia-yoga' ) ); // phpcs:ignore ?><h2 id="faq-title"><?php esc_html_e( 'Can yoga really work online?', 'olivia-yoga' ); ?></h2><p class="lead"><?php esc_html_e( 'The question everyone asks first, and a few others.', 'olivia-yoga' ); ?></p><p><a class="text-link" href="<?php echo esc_url( oy_page_link( 'faq' ) ); ?>"><?php esc_html_e( 'All questions', 'olivia-yoga' ); ?></a></p></header>
	<?php echo oy_faq_list( true ); // phpcs:ignore ?>
</div></section>

<?php $journal = get_posts( array( 'numberposts' => 3 ) ); ?>
<?php if ( $journal ) : ?>
<section class="section section--pale" aria-labelledby="journal-title"><div class="container">
	<header class="section__head section__head--row" data-reveal><div><?php echo oy_kicker( __( 'About yoga', 'olivia-yoga' ) ); // phpcs:ignore ?><h2 id="journal-title"><?php esc_html_e( 'Read more about yoga', 'olivia-yoga' ); ?></h2></div><?php echo oy_btn( oy_page_link( 'journal' ), __( 'All articles', 'olivia-yoga' ), 'ghost' ); // phpcs:ignore ?></header>
	<?php get_template_part( 'template-parts/cards', null, array( 'posts' => $journal ) ); ?>
</div></section>
<?php endif; ?>

<section class="section cta oj-cta--peach" aria-labelledby="cta-title"><div class="container"><div class="cta__inner" data-reveal>
	<h2 id="cta-title"><?php esc_html_e( 'Your mat is waiting', 'olivia-yoga' ); ?></h2>
	<p class="lead"><?php esc_html_e( 'Join a live online class, ask for a one-to-one session, or just send a question. Beginners very welcome.', 'olivia-yoga' ); ?></p>
	<p class="btn-row"><?php echo oy_btn( oy_book_url(), __( 'Book a class', 'olivia-yoga' ), 'orchid', 'btn--lg' ) . oy_btn( oy_contact_url(), __( 'Send a message', 'olivia-yoga' ), 'ghost' ); // phpcs:ignore ?></p>
</div></div></section>
