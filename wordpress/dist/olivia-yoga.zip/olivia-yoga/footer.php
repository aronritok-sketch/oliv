<?php defined( 'ABSPATH' ) || exit; ?>
</main>
<?php
$link = fn( $slug, $label ) => '<li><a href="' . esc_url( oy_page_link( $slug ) ) . '">' . esc_html( $label ) . '</a></li>';
$gift = function_exists( 'oys_page_url' ) ? oys_page_url( 'gifts' ) : oy_contact_url( 'gift' );
?>
<footer class="site-footer">
	<div class="container">
		<div class="footer__grid">
			<div class="footer__brand">
				<?php if ( oy_online_only() ) : ?><a class="oj-foot-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( oy_site_name() ); ?>"><?php echo oy_online_logo(); // phpcs:ignore ?></a><?php endif; ?>
				<p class="footer__motto"><?php echo esc_html( oy_is_demo() ? __( 'Book, pay and practice in one place.', 'olivia-yoga' ) : __( 'Dynamic yet gentle. Just enough of everything.', 'olivia-yoga' ) ); ?></p>
				<p><?php echo esc_html( oy_title_line() ); ?></p>
				<?php echo oy_specialities_line( 'specialities specialities--footer' ); // phpcs:ignore ?>
				<p class="btn-row"><?php echo oy_btn( oy_book_url(), __( 'Book a class', 'olivia-yoga' ), 'orchid' ); // phpcs:ignore ?></p>
			</div>
			<nav aria-label="<?php esc_attr_e( 'Practice', 'olivia-yoga' ); ?>"><h2><?php esc_html_e( 'Practice', 'olivia-yoga' ); ?></h2><ul>
				<?php echo oy_is_demo() ? $link( 'yoga-classes', __( 'Classes', 'olivia-yoga' ) ) . $link( 'schedule-pricing', __( 'Schedule & pricing', 'olivia-yoga' ) ) . $link( 'private-yoga', __( 'Private sessions', 'olivia-yoga' ) ) : ( oy_online_only() ? $link( 'yoga-classes', __( 'Online classes', 'olivia-yoga' ) ) . $link( 'schedule-pricing', __( 'Schedule & pricing', 'olivia-yoga' ) ) . '<li><a href="' . esc_url( oy_page_link( 'yoga-classes', 'egyeni-orak' ) ) . '">' . esc_html__( 'Individual online sessions', 'olivia-yoga' ) . '</a></li>' : $link( 'yoga-classes', __( 'Classes', 'olivia-yoga' ) ) . $link( 'private-yoga', __( 'Private yoga', 'olivia-yoga' ) ) . $link( 'schedule-pricing', __( 'Schedule & pricing', 'olivia-yoga' ) ) . $link( 'corporate-yoga', __( 'Teams & athletes', 'olivia-yoga' ) ) . $link( 'events', __( 'Events', 'olivia-yoga' ) ) ); // phpcs:ignore ?>
			</ul></nav>
			<nav aria-label="<?php esc_attr_e( 'More', 'olivia-yoga' ); ?>"><h2><?php esc_html_e( 'More', 'olivia-yoga' ); ?></h2><ul>
				<?php echo $link( 'about', oy_brand( 'about' ) ) . $link( 'faq', __( 'FAQ', 'olivia-yoga' ) ) . $link( 'journal', oy_online_only() ? __( 'About yoga', 'olivia-yoga' ) : __( 'Journal', 'olivia-yoga' ) ) . $link( 'contact', __( 'Contact', 'olivia-yoga' ) ); // phpcs:ignore ?>
				<li><a href="<?php echo esc_url( $gift ); ?>"><?php esc_html_e( 'Gift cards', 'olivia-yoga' ); ?></a></li>
				<li><a href="<?php echo esc_url( oy_account_url() ); ?>"><?php esc_html_e( 'My account', 'olivia-yoga' ); ?></a></li>
			</ul></nav>
			<div><h2><?php esc_html_e( 'Say hello', 'olivia-yoga' ); ?></h2>
				<ul class="footer__contact"><li><?php echo oy_icon( 'mail' ); // phpcs:ignore ?><a href="mailto:<?php echo esc_attr( OY_EMAIL ); ?>"><?php echo esc_html( OY_EMAIL ); ?></a></li><li><?php echo oy_icon( oy_online_only() ? 'globe' : 'pin' ); // phpcs:ignore ?><span><?php echo esc_html( oy_brand( 'place' ) ); ?></span></li><?php if ( function_exists( 'oys_fb_group_url' ) && oys_fb_group_url() ) : ?><li><?php echo oy_icon( 'facebook' ); // phpcs:ignore ?><a href="<?php echo esc_url( oys_fb_group_url() ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Join our Facebook group', 'olivia-yoga' ); ?></a></li><?php endif; ?></ul>
				<?php if ( OY_INSTAGRAM || OY_FACEBOOK ) : ?><p class="social"><a href="<?php echo esc_url( OY_INSTAGRAM ); ?>" rel="noopener" target="_blank"><?php echo oy_icon( 'instagram' ); // phpcs:ignore ?><span class="sr-only">Instagram</span></a><a href="<?php echo esc_url( OY_FACEBOOK ); ?>" rel="noopener" target="_blank"><?php echo oy_icon( 'facebook' ); // phpcs:ignore ?><span class="sr-only">Facebook</span></a></p><?php endif; ?>
				<?php echo oy_lang_switcher( 'langs langs--footer' ); // phpcs:ignore ?>
			</div>
		</div>
		<?php if ( ! oy_online_only() ) : // Olívia, 14 November: the big name in the footer „szedjük ki mindenhonnan” ?>
		<p class="footer__word" aria-hidden="true"><?php echo preg_replace( '/ (.+)$/', ' <span>$1</span>', esc_html( oy_teacher_name() ) ); // phpcs:ignore ?></p>
		<?php endif; ?>
		<div class="footer__bottom">
			<p>&copy; <?php echo esc_html( wp_date( 'Y' ) . ' ' . oy_site_name() ); ?><?php foreach ( oy_legal_pages() as $oy_l ) : ?> · <a href="<?php echo esc_url( $oy_l[1] ); ?>"><?php echo esc_html( 'Általános szerződési feltételek' === $oy_l[0] ? 'ÁSZF' : $oy_l[0] ); ?></a><?php endforeach; ?> · <a href="<?php echo esc_url( get_privacy_policy_url() ?: oy_page_link( 'privacy-policy' ) ); ?>"><?php esc_html_e( 'Privacy', 'olivia-yoga' ); ?></a><?php if ( oy_online_only() ) : // Olívia, 14 November: „Footerbe írd, hogy ki készítette az oldalt, ahogy szokás és Áron oldala kerüljön belinkelve” ?> · <span class="footer__credit"><?php esc_html_e( 'Made by', 'olivia-yoga' ); ?> <a href="https://helloprovision.com/">HelloProVision</a></span><?php endif; ?></p>
			<p><?php esc_html_e( 'Yoga is not a substitute for medical care. If you have a health condition or are pregnant, talk to your doctor before starting a new practice.', 'olivia-yoga' ); ?></p>
		</div>
	</div>
</footer>
<nav class="action-bar" aria-label="<?php esc_attr_e( 'Quick actions', 'olivia-yoga' ); ?>" data-action-bar>
	<a href="<?php echo esc_url( oy_book_url() ); ?>"><?php echo oy_icon( 'calendar' ); // phpcs:ignore ?><?php esc_html_e( 'Book', 'olivia-yoga' ); ?></a>
	<a href="<?php echo esc_url( oy_private_url() ); ?>"><?php echo oy_icon( 'home', 'icon' ); // phpcs:ignore ?><?php echo esc_html( oy_online_only() ? __( 'Individual', 'olivia-yoga' ) : __( 'Private', 'olivia-yoga' ) ); ?></a>
	<a href="<?php echo esc_url( oy_account_url() ); ?>"><?php echo oy_icon( 'user' ); // phpcs:ignore ?><?php esc_html_e( 'Account', 'olivia-yoga' ); ?></a>
</nav>
<?php if ( ! in_array( oy_is_studio_page(), array( 'book', 'account' ), true ) ) : ?><a class="book-fab" href="<?php echo esc_url( oy_book_url() ); ?>" data-book-fab><?php echo oy_icon( 'calendar' ); // phpcs:ignore ?><?php esc_html_e( 'Book a class', 'olivia-yoga' ); ?></a><?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>
